/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.dao.impl;

import local.brand.dao.PhieuGiamGiaDAO;

/**
 *
 * @author ASUS
 */
public class PhieuGiamGiaDAOImpl extends PhieuGiamGiaDAO {
    
    public PhieuGiamGiaDAOImpl() {
    }
}
