/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package local.brand.dao;

import java.util.List;
import local.brand.entity.HoaDon;

/**
 *
 * @author ASUS
 */
public interface HoaDonDAO {
    void insert(HoaDon entity);
    List<HoaDon> selectAll();
    HoaDon selectById(String maHD);
    List<HoaDon> selectByKeyword(String keyword);
    void delete(String maHD);
    List<HoaDon> selectByFilter(String keyword, String startDate, String endDate, Integer trangThai);
    Integer getIdByMa(String maHd);
}
