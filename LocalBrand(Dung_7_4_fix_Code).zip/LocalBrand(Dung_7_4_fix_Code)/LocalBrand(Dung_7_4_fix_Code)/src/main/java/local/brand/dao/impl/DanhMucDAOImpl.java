/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.dao.impl;

import java.util.List;
import local.brand.dao.DanhMucDAO;
import local.brand.entity.DanhMuc;
import local.brand.ulti.XJdbc;

/**
 *
 * @author ASUS
 */
public class DanhMucDAOImpl implements DanhMucDAO {
    private static final String SELECT_ALL = """
        SELECT 
            id AS id,
            ma_danh_muc AS maDanhMuc,
            ten_danh_muc AS tenDanhMuc,
            trang_thai AS trangThai
        FROM danh_muc
        ORDER BY ten_danh_muc
        """;

    private static final String SELECT_BY_ID = """
        SELECT 
            id AS id,
            ma_danh_muc AS maDanhMuc,
            ten_danh_muc AS tenDanhMuc,
            trang_thai AS trangThai
        FROM danh_muc
        WHERE id = ?
        """;
    @Override
    public List<DanhMuc> selectAll() {
        return XJdbc.getBeanList(DanhMuc.class, SELECT_ALL);
    }

    @Override
    public DanhMuc selectById(Integer id) {
        return XJdbc.getSingleBean(DanhMuc.class, SELECT_BY_ID, id);
    }
    
}
