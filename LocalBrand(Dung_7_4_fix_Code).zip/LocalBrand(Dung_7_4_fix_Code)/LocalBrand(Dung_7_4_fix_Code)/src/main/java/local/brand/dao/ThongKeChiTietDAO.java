/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package local.brand.dao;

import java.util.Date;
import java.util.List;

/**
 *
 * @author CAU DIEN
 */
public interface ThongKeChiTietDAO {

    
    List<Object[]> getThongKeChiTiet(Date tuNgay, Date denNgay);

    /**
     * Thống kê các ngày trong một tháng của biến date
     * Thường dùng cho: Theo tháng
     * @return [Ngày, Số đơn, Tiền mặt, Chuyển khoản]
     */
    List<Object[]> getThongKeTheoThang(Date date);

    /**
     * Thống kê tổng hợp 12 tháng trong một năm của biến date
     * Thường dùng cho: Theo năm
     * @return [Tháng, Số đơn, Tiền mặt, Chuyển khoản]
     */
    List<Object[]> getThongKeTheoNam(Date date);

    // --- Các hàm dự phòng hoặc dùng cho Chart (Nếu ông có dùng) ---
    
    List<Object[]> getDoanhThuTheoNam(int nam);

    List<Object[]> getDoanhThuTheoKhoangNgay(java.util.Date tuNgay, java.util.Date denNgay);

    List<Object[]> getDoanhThuCacNgayTrongThang(int thang, int nam);
}
