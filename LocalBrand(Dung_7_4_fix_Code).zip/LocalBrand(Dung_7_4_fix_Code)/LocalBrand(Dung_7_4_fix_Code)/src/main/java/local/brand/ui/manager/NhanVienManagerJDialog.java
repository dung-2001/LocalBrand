/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package local.brand.ui.manager;

import local.brand.dao.NhanVienDAO;
import local.brand.entity.NhanVien;
import javax.swing.table.DefaultTableModel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ASUS
 */
public class NhanVienManagerJDialog extends javax.swing.JDialog {

    NhanVienDAO dao = new NhanVienDAO();
    DefaultTableModel model;

    /**
     * Creates new form NhanVienManagerJDialog
     */
    public NhanVienManagerJDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        model = (DefaultTableModel) tblQuanLyNV.getModel();
        txtTimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                loadTableSearch();
            }
        });
        loadTable();
    }

    void loadTable() {
        model.setRowCount(0);
        ArrayList<NhanVien> list = dao.getAll();

        for (NhanVien nv : list) {
            model.addRow(new Object[]{
                nv.getId(),
                nv.getIdChucVu(),
                nv.getMaNV(),
                nv.getTenNV(),
                nv.getNgaySinh(),
                nv.getGioiTinh(),
                nv.getDiaChi(),
                nv.getEmail(),
                nv.getSdt(),
                nv.getTenDangNhap(),
                nv.getMatKhau(),
                nv.getTrangThai() == 1 ? "Đang làm" : "Ngừng"
            });
        }

    }

    boolean validateForm() {

        // Mã NV
        String ma = txtMaNV.getText().trim();
        if (ma.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Không được để trống mã NV");
            txtMaNV.requestFocus();
            return false;
        } else if (dao.checkTrungMa(ma)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Mã NV đã tồn tại");
            txtMaNV.requestFocus();
            return false;
        }

        // Tên NV
        if (txtTenNV.getText().trim().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Không được để trống tên NV");
            txtTenNV.requestFocus();
        }

        // Ngày sinh
        String ns = txtNgaySinh.getText().trim();
        if (ns.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Không được để trống ngày sinh");
            txtNgaySinh.requestFocus();
            return false;
        } else {
            try {
                new java.text.SimpleDateFormat("yyyy-MM-dd").parse(ns);
            } catch (Exception e) {
                javax.swing.JOptionPane.showMessageDialog(this, "Ngày sinh phải dạng yyyy-MM-dd");
                txtNgaySinh.requestFocus();
                return false;
            }
        }

        // Giới tính
        if (txtGioiTinh.getText().trim().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Không được để trống giới tính");
            txtGioiTinh.requestFocus();
            return false;
        }

        // Địa chỉ
        if (txtDiaChi.getText().trim().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Không được để trống địa chỉ");
            txtDiaChi.requestFocus();
            return false;
        }

        // Email
        String email = txtEmail.getText().trim();
        if (email.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Không được để trống email");
            txtEmail.requestFocus();
            return false;
        } else if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            javax.swing.JOptionPane.showMessageDialog(this, "Email không đúng định dạng");
            txtEmail.requestFocus();
            return false;
        }

        // SĐT
        String sdt = txtSdt.getText().trim();
        if (sdt.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Không được để trống SĐT");
            txtSdt.requestFocus();
            return false;
        } else if (!sdt.matches("\\d{10}")) {
            javax.swing.JOptionPane.showMessageDialog(this, "SĐT phải 10 số");
            txtSdt.requestFocus();
            return false;
        }

        // Tên đăng nhập
        if (txtTenDN.getText().trim().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Không được để trống tên đăng nhập");
            txtTenDN.requestFocus();
            return false;
        }

        // Mật khẩu
        if (txtMatKhau.getText().trim().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Không được để trống mật khẩu");
            txtMatKhau.requestFocus();
            return false;
        }

        // Chức vụ
        String cv = txtChucVu.getText().trim();
        if (cv.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Không được để trống chức vụ");
            txtChucVu.requestFocus();
            return false;
        } else {
            try {
                Integer.parseInt(cv);
            } catch (Exception e) {
                javax.swing.JOptionPane.showMessageDialog(this, "Chức vụ phải là số");
                txtChucVu.requestFocus();
                return false;
            }
        }

        // Trạng thái
        if (rdoDang.isSelected() && rdoNgung.isSelected()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Chỉ được chọn 1 trạng thái");
            return false;
        }
        if (!rdoDang.isSelected() && !rdoNgung.isSelected()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Chọn trạng thái");
            return false;
        }

        return true;
    }

    void loadTableSearch() {
        String key = txtTimKiem.getText().trim();

        List<NhanVien> list = dao.search(key);

        DefaultTableModel model = (DefaultTableModel) tblQuanLyNV.getModel();
        model.setRowCount(0);

        for (NhanVien nv : list) {
            model.addRow(new Object[]{
                nv.getId(),
                nv.getIdChucVu(),
                nv.getMaNV(),
                nv.getTenNV(),
                nv.getNgaySinh(),
                nv.getGioiTinh(),
                nv.getDiaChi(),
                nv.getEmail(),
                nv.getSdt(),
                nv.getTenDangNhap(),
                nv.getMatKhau(),
                nv.getTrangThai() == 1 ? "Đang làm" : "Ngừng"
            });
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        rdoDang = new javax.swing.JRadioButton();
        rdoNgung = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblQuanLyNV = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        txtMaNV = new javax.swing.JTextField();
        txtTenNV = new javax.swing.JTextField();
        txtSdt = new javax.swing.JTextField();
        txtChucVu = new javax.swing.JTextField();
        txtNgaySinh = new javax.swing.JTextField();
        txtGioiTinh = new javax.swing.JTextField();
        txtTenDN = new javax.swing.JTextField();
        txtDiaChi = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtMatKhau = new javax.swing.JTextField();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        btnLamMoi = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("QUÁN LÝ NHÂN VIÊN");

        jLabel2.setText("Mã NV:");

        jLabel3.setText("Tên NV:");

        jLabel4.setText("Ngày sinh:");

        jLabel5.setText("Giới tính:");

        jLabel6.setText("Địa chỉ:");

        jLabel7.setText("Email:");

        jLabel8.setText("SĐT:");

        jLabel9.setText("Tên đăng nhập:");

        jLabel10.setText("Mật khẩu:");

        jLabel11.setText("Trạng thái:");

        rdoDang.setText("Đang làm việc");

        rdoNgung.setText("Ngừng làm việc");

        tblQuanLyNV.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "ID chức vụ", "Mã NV", "Tên NV", "Ngày sinh", "Giới tính", "Địa chỉ", "Email", "SĐT", "Tên ĐN", "MK đăng nhập", "Trạng thái"
            }
        ));
        tblQuanLyNV.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblQuanLyNVMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblQuanLyNV);

        jLabel12.setText("ID chức vụ:");

        btnThem.setText("THÊM");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setText("SỬA");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnXoa.setText("XOÁ");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        btnLamMoi.setText("LÀM MỚI");
        btnLamMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiActionPerformed(evt);
            }
        });

        jLabel14.setText("Tìm kiếm:");

        txtTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(89, 89, 89)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rdoDang)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rdoNgung)
                        .addGap(21, 21, 21))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(jLabel13)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(132, 132, 132)
                                        .addComponent(jLabel1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel14)
                                        .addGap(11, 11, 11)))
                                .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(86, 86, 86))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel3))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtTenNV, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtSdt, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(94, 94, 94)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtNgaySinh, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtGioiTinh, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtTenDN, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(34, 34, 34)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtEmail))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtMatKhau, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtDiaChi)))))
                        .addGap(46, 46, 46))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addComponent(btnThem)
                                .addGap(42, 42, 42)
                                .addComponent(btnSua)
                                .addGap(63, 63, 63)
                                .addComponent(btnXoa)
                                .addGap(49, 49, 49)
                                .addComponent(btnLamMoi))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtChucVu, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel13)
                        .addComponent(jLabel14)
                        .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4)
                    .addComponent(jLabel6)
                    .addComponent(txtMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNgaySinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5)
                    .addComponent(jLabel7)
                    .addComponent(txtTenNV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtGioiTinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(txtSdt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTenDN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMatKhau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(txtChucVu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(1, 1, 1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rdoNgung)
                    .addComponent(rdoDang)
                    .addComponent(jLabel11))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThem)
                    .addComponent(btnSua)
                    .addComponent(btnXoa)
                    .addComponent(btnLamMoi))
                .addGap(27, 27, 27)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(50, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblQuanLyNVMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblQuanLyNVMouseClicked
        // TODO add your handling code here:
        int row = tblQuanLyNV.getSelectedRow();
        if (row < 0) {
            return;
        }

        try {
            txtMaNV.setText(tblQuanLyNV.getValueAt(row, 2).toString());
            txtTenNV.setText(tblQuanLyNV.getValueAt(row, 3).toString());

            Object ngaySinh = tblQuanLyNV.getValueAt(row, 4);
            txtNgaySinh.setText(ngaySinh == null ? "" : ngaySinh.toString());

            txtGioiTinh.setText(tblQuanLyNV.getValueAt(row, 5).toString());
            txtDiaChi.setText(tblQuanLyNV.getValueAt(row, 6).toString());
            txtEmail.setText(tblQuanLyNV.getValueAt(row, 7).toString());
            txtSdt.setText(tblQuanLyNV.getValueAt(row, 8).toString());
            txtTenDN.setText(tblQuanLyNV.getValueAt(row, 9).toString());
            txtMatKhau.setText(tblQuanLyNV.getValueAt(row, 10).toString());
            txtChucVu.setText(tblQuanLyNV.getValueAt(row, 1).toString());

            String tt = tblQuanLyNV.getValueAt(row, 11).toString();
            if (tt.equals("Đang làm")) {
                rdoDang.setSelected(true);
            } else {
                rdoNgung.setSelected(true);
            }

        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Lỗi đổ dữ liệu!");
            e.printStackTrace();
        }

    }//GEN-LAST:event_tblQuanLyNVMouseClicked

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        // TODO add your handling code here:
        if (!validateForm()) {
            return;
        }

        try {
            NhanVien nv = new NhanVien();

            nv.setMaNV(txtMaNV.getText());
            nv.setTenNV(txtTenNV.getText());
            nv.setNgaySinh(new java.text.SimpleDateFormat("yyyy-MM-dd")
                    .parse(txtNgaySinh.getText()));
            nv.setGioiTinh(txtGioiTinh.getText());
            nv.setDiaChi(txtDiaChi.getText());
            nv.setEmail(txtEmail.getText());
            nv.setSdt(txtSdt.getText());
            nv.setTenDangNhap(txtTenDN.getText());
            nv.setMatKhau(txtMatKhau.getText());
            nv.setIdChucVu(Integer.parseInt(txtChucVu.getText()));
            nv.setTrangThai(rdoDang.isSelected() ? 1 : 0);

            dao.insert(nv);
            loadTable();
            javax.swing.JOptionPane.showMessageDialog(this, "Thêm thành công");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        // TODO add your handling code here:
        if (!validateForm()) {
            return;
        }

        try {
            NhanVien nv = new NhanVien();

            nv.setMaNV(txtMaNV.getText());
            nv.setTenNV(txtTenNV.getText());
            nv.setNgaySinh(new java.text.SimpleDateFormat("yyyy-MM-dd")
                    .parse(txtNgaySinh.getText()));
            nv.setGioiTinh(txtGioiTinh.getText());
            nv.setDiaChi(txtDiaChi.getText());
            nv.setEmail(txtEmail.getText());
            nv.setSdt(txtSdt.getText());
            nv.setTenDangNhap(txtTenDN.getText());
            nv.setMatKhau(txtMatKhau.getText());
            nv.setIdChucVu(Integer.parseInt(txtChucVu.getText()));
            nv.setTrangThai(rdoDang.isSelected() ? 1 : 0);

            dao.update(nv);
            loadTable();
            javax.swing.JOptionPane.showMessageDialog(this, "Sửa thành công");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        // TODO add your handling code here:
        String ma = txtMaNV.getText();

        if (dao.delete(ma)) {
            loadTable();
            javax.swing.JOptionPane.showMessageDialog(this, "Xoá thành công");
        }
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnLamMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiActionPerformed
        // TODO add your handling code here:
        txtMaNV.setText("");
        txtTenNV.setText("");
        txtNgaySinh.setText("");
        txtGioiTinh.setText("");
        txtDiaChi.setText("");
        txtEmail.setText("");
        txtSdt.setText("");
        txtTenDN.setText("");
        txtMatKhau.setText("");
        txtChucVu.setText("");

        rdoDang.setSelected(true);
    }//GEN-LAST:event_btnLamMoiActionPerformed

    private void txtTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimKiemActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NhanVienManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NhanVienManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NhanVienManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NhanVienManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                NhanVienManagerJDialog dialog = new NhanVienManagerJDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLamMoi;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnXoa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rdoDang;
    private javax.swing.JRadioButton rdoNgung;
    private javax.swing.JTable tblQuanLyNV;
    private javax.swing.JTextField txtChucVu;
    private javax.swing.JTextField txtDiaChi;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtGioiTinh;
    private javax.swing.JTextField txtMaNV;
    private javax.swing.JTextField txtMatKhau;
    private javax.swing.JTextField txtNgaySinh;
    private javax.swing.JTextField txtSdt;
    private javax.swing.JTextField txtTenDN;
    private javax.swing.JTextField txtTenNV;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables
}
