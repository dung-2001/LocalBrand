/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.ulti;

import java.sql.ResultSet;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import local.brand.entity.DanhMuc;

public class Test {

    private static final Logger LOGGER = Logger.getLogger(Test.class.getName());

    public static void main(String[] args) {
        // insertDanhMuc(); // chạy 1 lần thôi
        selectDanhMuc();
        selectDanhMucByBeanList();
        selectSingleDanhMuc();
        selectMaxDanhMucId();
    }

    public static void insertDanhMuc() {
        String sql = "INSERT INTO danh_muc (ma_danh_muc, ten_danh_muc, trang_thai) VALUES (?, ?, ?)";

        XJdbc.executeUpdate(sql, "DM01", "Áo thun", 1);
        XJdbc.executeUpdate(sql, "DM02", "Hoodie", 1);

        System.out.println("Thêm danh mục thành công.");
    }

    public static void selectDanhMuc() {
        String sql = "SELECT * FROM danh_muc WHERE ten_danh_muc LIKE ?";

        try {
            ResultSet rs = XJdbc.executeQuery(sql, "%Áo%");
            while (rs.next()) {
                int id = rs.getInt("id");
                String maDanhMuc = rs.getString("ma_danh_muc");
                String tenDanhMuc = rs.getString("ten_danh_muc");
                int trangThai = rs.getInt("trang_thai");

                System.out.println(
                    "Id = " + id +
                    ", Ma = " + maDanhMuc +
                    ", Tên = " + tenDanhMuc +
                    ", Trạng thái = " + trangThai
                );
            }
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Lỗi khi truy vấn danh_muc", ex);
        }
    }

    public static void selectDanhMucByBeanList() {
        String sql = """
            SELECT 
                id AS id,
                ma_danh_muc AS maDanhMuc,
                ten_danh_muc AS tenDanhMuc,
                trang_thai AS trangThai
            FROM danh_muc
            WHERE ten_danh_muc LIKE ?
        """;

        List<DanhMuc> list = XJdbc.getBeanList(DanhMuc.class, sql, "%Áo%");

        for (DanhMuc dm : list) {
            System.out.println(
                "Id = " + dm.getId() +
                ", Ma = " + dm.getMaDanhMuc() +
                ", Tên = " + dm.getTenDanhMuc() +
                ", Trạng thái = " + dm.getTrangThai()
            );
        }
    }

    public static void selectSingleDanhMuc() {
        String sql = """
            SELECT 
                id AS id,
                ma_danh_muc AS maDanhMuc,
                ten_danh_muc AS tenDanhMuc,
                trang_thai AS trangThai
            FROM danh_muc
            WHERE id = ?
        """;

        DanhMuc dm = XJdbc.getSingleBean(DanhMuc.class, sql, 1);

        if (dm != null) {
            System.out.println(
                "Id = " + dm.getId() +
                ", Ma = " + dm.getMaDanhMuc() +
                ", Tên = " + dm.getTenDanhMuc() +
                ", Trạng thái = " + dm.getTrangThai()
            );
        } else {
            System.out.println("Không tìm thấy danh mục có id = 1");
        }
    }

    public static void selectMaxDanhMucId() {
        String sql = "SELECT MAX(id) FROM danh_muc";
        Integer maxId = XJdbc.getValue(sql);
        System.out.println("Max Id = " + maxId);
    }
}
