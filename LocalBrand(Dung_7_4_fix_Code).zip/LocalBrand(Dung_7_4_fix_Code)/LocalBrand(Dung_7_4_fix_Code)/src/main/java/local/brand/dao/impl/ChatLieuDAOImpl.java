/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.dao.impl;

import java.util.List;
import local.brand.dao.ChatLieuDAO;
import local.brand.entity.ChatLieu;
import local.brand.ulti.XJdbc;

/**
 *
 * @author ASUS
 */
public class ChatLieuDAOImpl implements ChatLieuDAO {
    private static final String SELECT_ALL = """
        SELECT 
            id AS id,
            ma_chat_lieu AS maChatLieu,
            ten_chat_lieu AS tenChatLieu,
            trang_thai AS trangThai
        FROM chat_lieu
        ORDER BY ten_chat_lieu
        """;

    private static final String SELECT_BY_ID = """
        SELECT 
            id AS id,
            ma_chat_lieu AS maChatLieu,
            ten_chat_lieu AS tenChatLieu,
            trang_thai AS trangThai
        FROM chat_lieu
        WHERE id = ?
        """;
    @Override
    public List<ChatLieu> selectAll() {
        return XJdbc.getBeanList(ChatLieu.class, SELECT_ALL);
    }

    @Override
    public ChatLieu selectById(Integer id) {
        return XJdbc.getSingleBean(ChatLieu.class, SELECT_BY_ID, id);
    }

   
    
}
