/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package local.brand.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import local.brand.entity.DotGiamGia;
import local.brand.ulti.XJdbc;

/**
 *
 * @author ASUS
 */
public interface DotGiamGiaDAO {
    void insert(DotGiamGia entity);
    void update(DotGiamGia entity);
    void delete(Integer id);
    DotGiamGia selectById(Integer id);
    DotGiamGia selectByMa(String ma);
    List<DotGiamGia> selectAll();
    List<DotGiamGia> selectByKeyword(String keyword);
    boolean existsByMa(String ma);
    List<DotGiamGia> filterByDate(String keyword);
}
