/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.entity;

import java.util.Date;

/**
 *
 * @author ASUS
 */
public class DotGiamGia {
    private Integer id;
    private String maDotGiam;
    private String tenDotGiam;
    private Date ngayBatDau;
    private Date ngayKetThuc;
    private Integer trangThai;

    public DotGiamGia() {
    }

    public DotGiamGia(Integer id, String maDotGiam, String tenDotGiam,
                      Date ngayBatDau, Date ngayKetThuc, Integer trangThai) {
        this.id = id;
        this.maDotGiam = maDotGiam;
        this.tenDotGiam = tenDotGiam;
        this.ngayBatDau = ngayBatDau;
        this.ngayKetThuc = ngayKetThuc;
        this.trangThai = trangThai;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMaDotGiam() {
        return maDotGiam;
    }

    public void setMaDotGiam(String maDotGiam) {
        this.maDotGiam = maDotGiam;
    }

    public String getTenDotGiam() {
        return tenDotGiam;
    }

    public void setTenDotGiam(String tenDotGiam) {
        this.tenDotGiam = tenDotGiam;
    }

    public Date getNgayBatDau() {
        return ngayBatDau;
    }

    public void setNgayBatDau(Date ngayBatDau) {
        this.ngayBatDau = ngayBatDau;
    }

    public Date getNgayKetThuc() {
        return ngayKetThuc;
    }

    public void setNgayKetThuc(Date ngayKetThuc) {
        this.ngayKetThuc = ngayKetThuc;
    }

    public Integer getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(Integer trangThai) {
        this.trangThai = trangThai;
    }
}
