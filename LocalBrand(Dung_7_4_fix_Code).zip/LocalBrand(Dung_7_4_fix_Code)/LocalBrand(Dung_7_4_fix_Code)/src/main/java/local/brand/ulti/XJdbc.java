package local.brand.ulti;

import java.beans.PropertyDescriptor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class XJdbc {

    private static Connection connection;
    private static final String DEFAULT_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private static final String DEFAULT_URL = "jdbc:sqlserver://localhost:1433;databaseName=ShopLocalBrandmoi;encrypt=true;trustServerCertificate=true;";
    private static final String DEFAULT_USERNAME = "sa";
    private static final String DEFAULT_PASSWORD = "1234";

    public static Connection openConnection() {
        String driver = getConfig("localbrand.db.driver", "LOCALBRAND_DB_DRIVER", DEFAULT_DRIVER);
        String dburl = getConfig("localbrand.db.url", "LOCALBRAND_DB_URL", DEFAULT_URL);
        String username = getConfig("localbrand.db.username", "LOCALBRAND_DB_USERNAME", DEFAULT_USERNAME);
        String password = getConfig("localbrand.db.password", "LOCALBRAND_DB_PASSWORD", DEFAULT_PASSWORD);

        try {
            if (!isReady()) {
                Class.forName(driver);
                connection = DriverManager.getConnection(dburl, username, password);
            }
        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException("Khong the ket noi SQL Server voi url=" + dburl
                    + ", user=" + username + ". Hay kiem tra lai mat khau, SQL Server Authentication va ten database.", e);
        }
        return connection;
    }

    private static String getConfig(String systemProperty, String envKey, String defaultValue) {
        String value = System.getProperty(systemProperty);
        if (value != null && !value.trim().isEmpty()) {
            return value.trim();
        }

        value = System.getenv(envKey);
        if (value != null && !value.trim().isEmpty()) {
            return value.trim();
        }

        return defaultValue;
    }

    public static void closeConnection() {
        try {
            if (isReady()) {
                connection.close();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean isReady() {
        try {
            return connection != null && !connection.isClosed();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static int executeUpdate(String sql, Object... values) {
        try {
            PreparedStatement stmt = getStmt(sql, values);
            int result = stmt.executeUpdate();
            stmt.close();
            return result;
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static ResultSet executeQuery(String sql, Object... values) {
        try {
            PreparedStatement stmt = getStmt(sql, values);
            return stmt.executeQuery();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static <T> T getValue(String sql, Object... values) {
        try {
            ResultSet resultSet = executeQuery(sql, values);
            if (resultSet.next()) {
                return (T) resultSet.getObject(1);
            }
            return null;
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static <T> List<T> getBeanList(Class<T> type, String sql, Object... values) {
        try {
            List<T> list = new ArrayList<>();
            ResultSet rs = executeQuery(sql, values);
            ResultSetMetaData meta = rs.getMetaData();
            int columnCount = meta.getColumnCount();

            while (rs.next()) {
                T bean = type.getDeclaredConstructor().newInstance();
                for (int i = 1; i <= columnCount; i++) {
                    String colName = meta.getColumnLabel(i);
                    Object value = rs.getObject(i);
                    try {
                        PropertyDescriptor pd = new PropertyDescriptor(colName, type);
                        pd.getWriteMethod().invoke(bean, value);
                    } catch (Exception ignore) {
                    }
                }
                list.add(bean);
            }
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static <T> T getSingleBean(Class<T> type, String sql, Object... values) {
        List<T> list = getBeanList(type, sql, values);
        return list.isEmpty() ? null : list.get(0);
    }

    private static PreparedStatement getStmt(String sql, Object... values) throws SQLException {
        Connection conn = openConnection();
        PreparedStatement stmt = sql.trim().startsWith("{")
                ? conn.prepareCall(sql)
                : conn.prepareStatement(sql);

        for (int i = 0; i < values.length; i++) {
            stmt.setObject(i + 1, values[i]);
        }
        return stmt;
    }

    public static ResultSet query(String sql, Object... args) {
        try {
            Connection conn = openConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);

            for (int i = 0; i < args.length; i++) {
                stmt.setObject(i + 1, args[i]);
            }

            return stmt.executeQuery();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
