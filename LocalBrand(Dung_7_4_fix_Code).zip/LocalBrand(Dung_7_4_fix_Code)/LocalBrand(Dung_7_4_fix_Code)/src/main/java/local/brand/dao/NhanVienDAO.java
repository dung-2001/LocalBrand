/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package local.brand.dao;

import java.sql.*;
import java.util.ArrayList;
import local.brand.entity.NhanVien;
import java.util.List;
import local.brand.ulti.XJdbc;

/**
 *
 * @author ASUSclass
 */
public class NhanVienDAO {

    // 1. Lấy tất cả
    public ArrayList<NhanVien> getAll() {
        ArrayList<NhanVien> list = new ArrayList<>();
        String sql = "SELECT * FROM nhan_vien";

        try (Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                NhanVien nv = new NhanVien();
                nv.setId(rs.getInt("id"));
                nv.setIdChucVu(rs.getInt("id_chuc_vu"));
                nv.setMaNV(rs.getString("ma_nv"));
                nv.setTenNV(rs.getString("ten_nv"));
                nv.setNgaySinh(rs.getDate("ngay_sinh"));
                nv.setGioiTinh(rs.getString("gioi_tinh"));
                nv.setDiaChi(rs.getString("dia_chi"));
                nv.setEmail(rs.getString("email"));
                nv.setSdt(rs.getString("sdt"));
                nv.setTenDangNhap(rs.getString("ten_dang_nhap"));
                nv.setMatKhau(rs.getString("mat_khau"));
                nv.setTrangThai(rs.getInt("trang_thai"));

                list.add(nv);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // 2. Thêm
    public boolean insert(NhanVien nv) {
        String sql = "INSERT INTO nhan_vien(id_chuc_vu, ma_nv, ten_nv, ngay_sinh, gioi_tinh, dia_chi, email, sdt, ten_dang_nhap, mat_khau, trang_thai) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, nv.getIdChucVu());
            ps.setString(2, nv.getMaNV());
            ps.setString(3, nv.getTenNV());
            ps.setDate(4, new java.sql.Date(nv.getNgaySinh().getTime()));
            ps.setString(5, nv.getGioiTinh());
            ps.setString(6, nv.getDiaChi());
            ps.setString(7, nv.getEmail());
            ps.setString(8, nv.getSdt());
            ps.setString(9, nv.getTenDangNhap());
            ps.setString(10, nv.getMatKhau());
            ps.setInt(11, nv.getTrangThai());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // 3. Update
    public boolean update(NhanVien nv) {
        String sql = "UPDATE nhan_vien SET id_chuc_vu=?, ten_nv=?, ngay_sinh=?, gioi_tinh=?, dia_chi=?, email=?, sdt=?, ten_dang_nhap=?, mat_khau=?, trang_thai=? WHERE ma_nv=?";

        try (Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, nv.getIdChucVu());
            ps.setString(2, nv.getTenNV());
            ps.setDate(3, new java.sql.Date(nv.getNgaySinh().getTime()));
            ps.setString(4, nv.getGioiTinh());
            ps.setString(5, nv.getDiaChi());
            ps.setString(6, nv.getEmail());
            ps.setString(7, nv.getSdt());
            ps.setString(8, nv.getTenDangNhap());
            ps.setString(9, nv.getMatKhau());
            ps.setInt(10, nv.getTrangThai());
            ps.setString(11, nv.getMaNV());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // 4. Xóa (xóa mềm)
    public boolean delete(String maNV) {
        String sql = "UPDATE nhan_vien SET trang_thai = 0 WHERE ma_nv=?";

        try (Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, maNV);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // 5. Tìm theo mã
    public NhanVien findByMa(String maNV) {
        String sql = "SELECT * FROM nhan_vien WHERE ma_nv=?";

        try (Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, maNV);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                NhanVien nv = new NhanVien();
                nv.setId(rs.getInt("id"));
                nv.setIdChucVu(rs.getInt("id_chuc_vu"));
                nv.setMaNV(rs.getString("ma_nv"));
                nv.setTenNV(rs.getString("ten_nv"));
                nv.setNgaySinh(rs.getDate("ngay_sinh"));
                nv.setGioiTinh(rs.getString("gioi_tinh"));
                nv.setDiaChi(rs.getString("dia_chi"));
                nv.setEmail(rs.getString("email"));
                nv.setSdt(rs.getString("sdt"));
                nv.setTenDangNhap(rs.getString("ten_dang_nhap"));
                nv.setMatKhau(rs.getString("mat_khau"));
                nv.setTrangThai(rs.getInt("trang_thai"));

                return nv;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean checkTrungMa(String maNV) {
        String sql = "SELECT COUNT(*) FROM nhan_vien WHERE ma_nv = ?";

        try (
                Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maNV);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0; // >0 là bị trùng
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public List<NhanVien> search(String keyword) {
        List<NhanVien> list = new ArrayList<>();

        String sql = """
        SELECT * FROM nhan_vien
        WHERE ma_nv LIKE ? OR ten_nv LIKE ? OR sdt LIKE ?
    """;

        try (
                Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            String key = "%" + keyword + "%";

            ps.setString(1, key);
            ps.setString(2, key);
            ps.setString(3, key);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                NhanVien nv = new NhanVien();

                nv.setId(rs.getInt("id"));
                nv.setIdChucVu(rs.getInt("id_chuc_vu"));
                nv.setMaNV(rs.getString("ma_nv"));
                nv.setTenNV(rs.getString("ten_nv"));
                nv.setNgaySinh(rs.getDate("ngay_sinh"));
                nv.setGioiTinh(rs.getString("gioi_tinh"));
                nv.setDiaChi(rs.getString("dia_chi"));
                nv.setEmail(rs.getString("email"));
                nv.setSdt(rs.getString("sdt"));
                nv.setTenDangNhap(rs.getString("ten_dang_nhap"));
                nv.setMatKhau(rs.getString("mat_khau"));
                nv.setTrangThai(rs.getInt("trang_thai"));

                list.add(nv);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public NhanVien login(String tenDangNhap, String matKhau) {
        String sql = """
        SELECT nv.*, cv.ten_chuc_vu
        FROM nhan_vien nv
        JOIN chuc_vu cv ON nv.id_chuc_vu = cv.id
        WHERE nv.ten_dang_nhap = ?
          AND nv.mat_khau = ?
          AND nv.trang_thai = 1
    """;

        try (
                Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, tenDangNhap);
            ps.setString(2, matKhau);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                NhanVien nv = new NhanVien();
                nv.setId(rs.getInt("id"));
                nv.setIdChucVu(rs.getInt("id_chuc_vu"));
                nv.setMaNV(rs.getString("ma_nv"));
                nv.setTenNV(rs.getString("ten_nv"));
                nv.setNgaySinh(rs.getDate("ngay_sinh"));
                nv.setGioiTinh(rs.getString("gioi_tinh"));
                nv.setDiaChi(rs.getString("dia_chi"));
                nv.setEmail(rs.getString("email"));
                nv.setSdt(rs.getString("sdt"));
                nv.setTenDangNhap(rs.getString("ten_dang_nhap"));
                nv.setMatKhau(rs.getString("mat_khau"));
                nv.setTrangThai(rs.getInt("trang_thai"));
                nv.setTenChucVu(rs.getString("ten_chuc_vu"));
                return nv;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public NhanVien selectByUsernameAndPassword(String username, String password) {
    String sql = """
        SELECT nv.*, cv.ten_chuc_vu
        FROM nhan_vien nv
        JOIN chuc_vu cv ON nv.id_chuc_vu = cv.id
        WHERE nv.ten_dang_nhap = ?
          AND nv.mat_khau = ?
          AND nv.trang_thai = 1
    """;

    try (
        Connection con = XJdbc.openConnection();
        PreparedStatement ps = con.prepareStatement(sql)
    ) {
        ps.setString(1, username);
        ps.setString(2, password);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            NhanVien nv = new NhanVien();
            nv.setId(rs.getInt("id"));
            nv.setIdChucVu(rs.getInt("id_chuc_vu"));
            nv.setMaNV(rs.getString("ma_nv"));
            nv.setTenNV(rs.getString("ten_nv"));
            nv.setNgaySinh(rs.getDate("ngay_sinh"));
            nv.setGioiTinh(rs.getString("gioi_tinh"));
            nv.setDiaChi(rs.getString("dia_chi"));
            nv.setEmail(rs.getString("email"));
            nv.setSdt(rs.getString("sdt"));
            nv.setTenDangNhap(rs.getString("ten_dang_nhap"));
            nv.setMatKhau(rs.getString("mat_khau"));
            nv.setTrangThai(rs.getInt("trang_thai"));
            nv.setTenChucVu(rs.getString("ten_chuc_vu"));
            return nv;
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return null;
}
}
