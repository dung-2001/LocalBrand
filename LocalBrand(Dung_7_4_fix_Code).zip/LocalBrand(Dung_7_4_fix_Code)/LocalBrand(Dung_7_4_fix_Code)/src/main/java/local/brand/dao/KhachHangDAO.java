/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package local.brand.dao;

import java.util.List;
import local.brand.entity.KhachHang;

/**
 *
 * @author ASUS
 */
public interface KhachHangDAO {
    List<KhachHang> selectAll();
    KhachHang selectById(int id);
    void insert(KhachHang kh);
    void update(KhachHang kh);
    void delete(String maKH);
    List<KhachHang> search(String keyword);
    boolean hasInvoice(String maKH);
    void softDelete(String maKH);
    String getNextMaKH();
}
