package local.brand.dao.impl;

import java.util.List;
import local.brand.dao.KichThuocDAO;
import local.brand.entity.KichThuoc;
import local.brand.ulti.XJdbc;

public class KichThuocDAOImpl implements KichThuocDAO {

    @Override
    public List<KichThuoc> selectAll() {
        String sql = "SELECT id, ma_kich_thuoc AS maKichThuoc, ten_kich_thuoc AS tenKichThuoc, trang_thai AS trangThai FROM kich_thuoc";
        return XJdbc.getBeanList(KichThuoc.class, sql);
    }

    @Override
    public KichThuoc selectById(int id) {
        String sql = "SELECT id, ma_kich_thuoc AS maKichThuoc, ten_kich_thuoc AS tenKichThuoc, trang_thai AS trangThai FROM kich_thuoc WHERE id = ?";
        return XJdbc.getSingleBean(KichThuoc.class, sql, id);
    }

    @Override
    public void insert(KichThuoc kt) {
        String sql = "INSERT INTO kich_thuoc (ma_kich_thuoc, ten_kich_thuoc, trang_thai) VALUES (?, ?, ?)";
        XJdbc.executeUpdate(sql, kt.getMaKichThuoc(), kt.getTenKichThuoc(), kt.getTrangThai());
    }

    @Override
    public void update(KichThuoc kt) {
        String sql = "UPDATE kich_thuoc SET ma_kich_thuoc = ?, ten_kich_thuoc = ?, trang_thai = ? WHERE id = ?";
        XJdbc.executeUpdate(sql, kt.getMaKichThuoc(), kt.getTenKichThuoc(), kt.getTrangThai(), kt.getId());
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM kich_thuoc WHERE id = ?";
        XJdbc.executeUpdate(sql, id);
    }
}