/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.entity;

/**
 *
 * @author ASUS
 */
public class SanPham {

    private Integer id;
    private Integer idDanhMuc;
    private Integer idChatLieu;
    private Integer idKieuDang;
    private String maSanPham;
    private String tenSanPham;
    private Integer trangThai;

    public SanPham() {
    }

    public SanPham(Integer id, Integer idDanhMuc, Integer idChatLieu, Integer idKieuDang,
            String maSanPham, String tenSanPham, Integer trangThai) {
        this.id = id;
        this.idDanhMuc = idDanhMuc;
        this.idChatLieu = idChatLieu;
        this.idKieuDang = idKieuDang;
        this.maSanPham = maSanPham;
        this.tenSanPham = tenSanPham;
        this.trangThai = trangThai;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdDanhMuc() {
        return idDanhMuc;
    }

    public void setIdDanhMuc(Integer idDanhMuc) {
        this.idDanhMuc = idDanhMuc;
    }

    public Integer getIdChatLieu() {
        return idChatLieu;
    }

    public void setIdChatLieu(Integer idChatLieu) {
        this.idChatLieu = idChatLieu;
    }

    public Integer getIdKieuDang() {
        return idKieuDang;
    }

    public void setIdKieuDang(Integer idKieuDang) {
        this.idKieuDang = idKieuDang;
    }

    public String getMaSanPham() {
        return maSanPham;
    }

    public void setMaSanPham(String maSanPham) {
        this.maSanPham = maSanPham;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public Integer getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(Integer trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public String toString() {
        return this.tenSanPham; // Giả sử thuộc tính lưu tên SP là tenSanPham
    }
}
