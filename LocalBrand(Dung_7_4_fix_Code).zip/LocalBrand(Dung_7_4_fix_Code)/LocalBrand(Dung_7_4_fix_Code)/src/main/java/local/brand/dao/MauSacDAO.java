/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package local.brand.dao;

import java.util.List;
import local.brand.entity.MauSac;

/**
 *
 * @author CAU DIEN
 */
public interface MauSacDAO {
    List<MauSac> selectAll();
    MauSac selectById(int id);
    void insert(MauSac ms);
    void update(MauSac ms);
    void delete(int id);
}
