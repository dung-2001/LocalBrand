package local.brand.ui.manager;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Frame;
import java.math.BigDecimal;
import java.sql.ResultSet;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import local.brand.dao.SanPhamGiamGiaDAO;
import local.brand.dao.impl.SanPhamGiamGiaDAOImpl;
import local.brand.entity.DotGiamGia;
import local.brand.entity.SanPhamGiamGia;
import local.brand.ulti.XJdbc;

public class SanPhamApDungDotGiamGiaJDialog extends JDialog {

    private final DotGiamGia dotGiamGia;
    private final SanPhamGiamGiaDAO sanPhamGiamGiaDAO = new SanPhamGiamGiaDAOImpl();

    private final DefaultTableModel modelBienThe = new DefaultTableModel(
            new Object[]{"ID", "Mã SPCT", "Tên sản phẩm", "Màu", "Size", "Giá gốc", "Tồn kho"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final DefaultTableModel modelDaApDung = new DefaultTableModel(
            new Object[]{"ID SPCT", "Mã SPCT", "Tên sản phẩm", "Màu", "Size", "Giá gốc", "Giá sau giảm"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable tblBienThe = new JTable(modelBienThe);
    private final JTable tblDaApDung = new JTable(modelDaApDung);
    private final JTextField txtTim = new JTextField(20);
    private final JTextField txtGiaSauGiam = new JTextField(12);

    public SanPhamApDungDotGiamGiaJDialog(Frame parent, boolean modal, DotGiamGia dotGiamGia) {
        super(parent, modal);
        this.dotGiamGia = dotGiamGia;
        init();
    }

    public SanPhamApDungDotGiamGiaJDialog(Dialog parent, boolean modal, DotGiamGia dotGiamGia) {
        super(parent, modal);
        this.dotGiamGia = dotGiamGia;
        init();
    }

    private void init() {
        setTitle("Sản phẩm áp dụng - " + dotGiamGia.getTenDotGiam());
        setLayout(new BorderLayout(10, 10));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel pnlTop = new JPanel();
        JButton btnTim = new JButton("Tìm");
        JButton btnThem = new JButton("Thêm/Cập nhật");
        JButton btnXoa = new JButton("Xóa khỏi đợt");

        pnlTop.add(new JLabel("Tìm sản phẩm:"));
        pnlTop.add(txtTim);
        pnlTop.add(btnTim);
        pnlTop.add(new JLabel("Giá sau giảm:"));
        pnlTop.add(txtGiaSauGiam);
        pnlTop.add(btnThem);
        pnlTop.add(btnXoa);

        JPanel pnlCenter = new JPanel(new java.awt.GridLayout(2, 1, 0, 10));
        pnlCenter.add(new JScrollPane(tblBienThe));
        pnlCenter.add(new JScrollPane(tblDaApDung));

        add(pnlTop, BorderLayout.NORTH);
        add(pnlCenter, BorderLayout.CENTER);

        tblBienThe.getSelectionModel().addListSelectionListener(e -> fillGiaSauGiamMacDinh());
        btnTim.addActionListener(e -> loadBienTheTable());
        btnThem.addActionListener(e -> themHoacCapNhatSanPhamGiamGia());
        btnXoa.addActionListener(e -> xoaSanPhamKhoiDot());

        setSize(1200, 700);
        setLocationRelativeTo(getParent());

        loadBienTheTable();
        loadDaApDungTable();
    }

    private void loadBienTheTable() {
        modelBienThe.setRowCount(0);

        String keyword = txtTim.getText().trim();
        String sql = """
            SELECT
                spct.id,
                spct.ma_sp_chi_tiet,
                sp.ten_san_pham,
                ms.ten_mau,
                kt.ten_kich_thuoc,
                spct.don_gia,
                spct.so_luong
            FROM san_pham_chi_tiet spct
            JOIN san_pham sp ON sp.id = spct.id_san_pham
            JOIN mau_sac ms ON ms.id = spct.id_mau_sac
            JOIN kich_thuoc kt ON kt.id = spct.id_kich_thuoc
            WHERE spct.trang_thai = 1
              AND sp.trang_thai = 1
              AND (? = '' OR sp.ten_san_pham LIKE ? OR spct.ma_sp_chi_tiet LIKE ?)
            ORDER BY spct.id DESC
            """;

        try (ResultSet rs = XJdbc.query(sql, keyword, "%" + keyword + "%", "%" + keyword + "%")) {
            while (rs.next()) {
                modelBienThe.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("ma_sp_chi_tiet"),
                    rs.getString("ten_san_pham"),
                    rs.getString("ten_mau"),
                    rs.getString("ten_kich_thuoc"),
                    rs.getBigDecimal("don_gia"),
                    rs.getInt("so_luong")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi tải sản phẩm: " + e.getMessage());
        }
    }

    private void loadDaApDungTable() {
        modelDaApDung.setRowCount(0);
        for (SanPhamGiamGia item : sanPhamGiamGiaDAO.selectByDotGiamGiaId(dotGiamGia.getId())) {
            modelDaApDung.addRow(new Object[]{
                item.getIdSanPhamChiTiet(),
                item.getMaSpChiTiet(),
                item.getTenSanPham(),
                item.getTenMau(),
                item.getTenKichThuoc(),
                item.getDonGiaGoc(),
                item.getGiaSauGiam()
            });
        }
    }

    private void fillGiaSauGiamMacDinh() {
        int row = tblBienThe.getSelectedRow();
        if (row >= 0) {
            Object giaGoc = modelBienThe.getValueAt(row, 5);
            txtGiaSauGiam.setText(giaGoc == null ? "" : giaGoc.toString());
        }
    }

    private void themHoacCapNhatSanPhamGiamGia() {
        int row = tblBienThe.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm chi tiết.");
            return;
        }

        BigDecimal giaSauGiam;
        try {
            giaSauGiam = new BigDecimal(txtGiaSauGiam.getText().trim());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Giá sau giảm không hợp lệ.");
            txtGiaSauGiam.requestFocus();
            return;
        }

        if (giaSauGiam.compareTo(BigDecimal.ZERO) < 0) {
            JOptionPane.showMessageDialog(this, "Giá sau giảm phải lớn hơn hoặc bằng 0.");
            return;
        }

        int idSpct = Integer.parseInt(modelBienThe.getValueAt(row, 0).toString());
        BigDecimal giaGoc = new BigDecimal(modelBienThe.getValueAt(row, 5).toString());
        if (giaSauGiam.compareTo(giaGoc) > 0) {
            JOptionPane.showMessageDialog(this, "Giá sau giảm không được lớn hơn giá gốc.");
            return;
        }

        try {
            SanPhamGiamGia tonTai = sanPhamGiamGiaDAO.selectByDotAndSanPhamChiTiet(dotGiamGia.getId(), idSpct);
            if (tonTai == null) {
                SanPhamGiamGia entity = new SanPhamGiamGia();
                entity.setIdDotGiamGia(dotGiamGia.getId());
                entity.setIdSanPhamChiTiet(idSpct);
                entity.setGiaSauGiam(giaSauGiam);
                entity.setTrangThai(1);
                sanPhamGiamGiaDAO.insert(entity);
            } else {
                tonTai.setGiaSauGiam(giaSauGiam);
                tonTai.setTrangThai(1);
                sanPhamGiamGiaDAO.update(tonTai);
            }

            loadDaApDungTable();
            JOptionPane.showMessageDialog(this, "Lưu sản phẩm áp dụng thành công.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lưu thất bại: " + e.getMessage());
        }
    }

    private void xoaSanPhamKhoiDot() {
        int row = tblDaApDung.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm cần xóa khỏi đợt.");
            return;
        }

        int idSpct = Integer.parseInt(modelDaApDung.getValueAt(row, 0).toString());
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Xóa sản phẩm này khỏi đợt giảm giá?",
                "Xác nhận",
                JOptionPane.YES_NO_OPTION
        );
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            sanPhamGiamGiaDAO.deleteByDotAndSanPhamChiTiet(dotGiamGia.getId(), idSpct);
            loadDaApDungTable();
            JOptionPane.showMessageDialog(this, "Đã xóa sản phẩm khỏi đợt giảm giá.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Xóa thất bại: " + e.getMessage());
        }
    }
}
