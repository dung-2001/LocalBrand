/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package local.brand.dao;

import java.util.List;
import local.brand.entity.SanPhamGiamGia;

/**
 *
 * @author ASUS
 */
public interface SanPhamGiamGiaDAO {
    void insert(SanPhamGiamGia entity);

    void update(SanPhamGiamGia entity);

    void deleteByDotAndSanPhamChiTiet(int idDotGiamGia, int idSanPhamChiTiet);

    SanPhamGiamGia selectByDotAndSanPhamChiTiet(int idDotGiamGia, int idSanPhamChiTiet);

    List<SanPhamGiamGia> selectByDotGiamGiaId(int idDotGiamGia);
}
