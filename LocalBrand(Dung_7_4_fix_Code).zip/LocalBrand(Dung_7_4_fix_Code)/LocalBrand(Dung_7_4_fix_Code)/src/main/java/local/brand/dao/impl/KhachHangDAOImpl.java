/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.dao.impl;

/**
 *
 * @author ASUS
 */
import java.util.List;
import local.brand.dao.KhachHangDAO;
import local.brand.entity.KhachHang;
import local.brand.ulti.XJdbc;

public class KhachHangDAOImpl implements KhachHangDAO {

    String selectAllSql = """
        SELECT 
            id AS id,
            ma_kh AS maKH,
            ten_kh AS tenKH,
            sdt AS sdt,
            email AS email,
            gioi_tinh AS gioiTinh,
            trang_thai AS trangThai
        FROM khach_hang
        ORDER BY id DESC
    """;

    String selectByIdSql = """
        SELECT 
            id AS id,
            ma_kh AS maKH,
            ten_kh AS tenKH,
            sdt AS sdt,
            email AS email,
            gioi_tinh AS gioiTinh,
            trang_thai AS trangThai
        FROM khach_hang
        WHERE id = ?
    """;

    String insertSql = """
        INSERT INTO khach_hang(ma_kh, ten_kh, sdt, email, gioi_tinh, trang_thai)
        VALUES (?, ?, ?, ?, ?, ?)
    """;

    String updateSql = """
        UPDATE khach_hang
        SET ten_kh = ?, sdt = ?, email = ?, gioi_tinh = ?, trang_thai = ?
        WHERE ma_kh = ?
    """;

    String deleteSql = "DELETE FROM khach_hang WHERE ma_kh = ?";

    String searchSql = """
        SELECT 
            id AS id,
            ma_kh AS maKH,
            ten_kh AS tenKH,
            sdt AS sdt,
            email AS email,
            gioi_tinh AS gioiTinh,
            trang_thai AS trangThai
        FROM khach_hang
        WHERE ma_kh LIKE ? OR ten_kh LIKE ? OR sdt LIKE ?
        ORDER BY id DESC
    """;

    String getNextMaSql = "SELECT TOP 1 ma_kh FROM khach_hang ORDER BY id DESC";
    public boolean hasInvoice(String maKH) {
    String sql = """
        SELECT COUNT(*)
        FROM hoa_don hd
        JOIN khach_hang kh ON hd.id_khach = kh.id
        WHERE kh.ma_kh = ?
    """;

    Object value = XJdbc.getValue(sql, maKH);
    int count = value == null ? 0 : ((Number) value).intValue();
    return count > 0;
}

public void softDelete(String maKH) {
    String sql = "UPDATE khach_hang SET trang_thai = 0 WHERE ma_kh = ?";
    XJdbc.executeUpdate(sql, maKH);
}

    @Override
    public List<KhachHang> selectAll() {
        return XJdbc.getBeanList(KhachHang.class, selectAllSql);
    }

    @Override
    public KhachHang selectById(int id) {
        return XJdbc.getSingleBean(KhachHang.class, selectByIdSql, id);
    }

    @Override
    public void insert(KhachHang kh) {
        XJdbc.executeUpdate(insertSql,
                kh.getMaKH(),
                kh.getTenKH(),
                kh.getSdt(),
                kh.getEmail(),
                kh.getGioiTinh(),
                kh.getTrangThai()
        );
    }

    @Override
    public void update(KhachHang kh) {
        XJdbc.executeUpdate(updateSql,
                kh.getTenKH(),
                kh.getSdt(),
                kh.getEmail(),
                kh.getGioiTinh(),
                kh.getTrangThai(),
                kh.getMaKH()
        );
    }

    @Override
    public void delete(String maKH) {
        XJdbc.executeUpdate(deleteSql, maKH);
    }

    @Override
    public List<KhachHang> search(String keyword) {
        String key = "%" + keyword + "%";
        return XJdbc.getBeanList(KhachHang.class, searchSql, key, key, key);
    }

    @Override
    public String getNextMaKH() {
        String maCu = XJdbc.getValue(getNextMaSql);
        if (maCu == null) {
            return "KH01";
        }
        int so = Integer.parseInt(maCu.substring(2));
        return String.format("KH%02d", so + 1);
    }
}
