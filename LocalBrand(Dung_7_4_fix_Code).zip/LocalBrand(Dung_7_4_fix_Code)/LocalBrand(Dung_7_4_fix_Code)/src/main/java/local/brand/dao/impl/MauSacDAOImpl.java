package local.brand.dao.impl;

import java.util.List;
import local.brand.dao.MauSacDAO;
import local.brand.entity.MauSac;
import local.brand.ulti.XJdbc;

public class MauSacDAOImpl implements MauSacDAO {

    @Override
    public List<MauSac> selectAll() {
        String sql = "SELECT id, ma_mau_sac AS maMauSac, ten_mau AS tenMau, trang_thai AS trangThai FROM mau_sac";
        return XJdbc.getBeanList(MauSac.class, sql);
    }

    @Override
    public MauSac selectById(int id) {
        String sql = "SELECT id, ma_mau_sac AS maMauSac, ten_mau AS tenMau, trang_thai AS trangThai FROM mau_sac WHERE id = ?";
        return XJdbc.getSingleBean(MauSac.class, sql, id);
    }

    @Override
    public void insert(MauSac ms) {
        String sql = "INSERT INTO mau_sac (ma_mau_sac, ten_mau, trang_thai) VALUES (?, ?, ?)";
        XJdbc.executeUpdate(sql, ms.getMaMauSac(), ms.getTenMau(), ms.getTrangThai());
    }

    @Override
    public void update(MauSac ms) {
        String sql = "UPDATE mau_sac SET ma_mau_sac = ?, ten_mau = ?, trang_thai = ? WHERE id = ?";
        XJdbc.executeUpdate(sql, ms.getMaMauSac(), ms.getTenMau(), ms.getTrangThai(), ms.getId());
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM mau_sac WHERE id = ?";
        XJdbc.executeUpdate(sql, id);
    }
}