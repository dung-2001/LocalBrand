/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.dao.impl;

import java.util.ArrayList;
import java.util.List;
import local.brand.dao.HoaDonChiTietDAO;
import local.brand.entity.HoaDonChiTiet;
import local.brand.ulti.XJdbc;

/**
 *
 * @author ASUS
 */
public class HoaDonChiTietDAOImpl implements HoaDonChiTietDAO {

    public List<HoaDonChiTiet> selectByMaHD(String maHD) {
        String sql = "SELECT "
                + "hdct.id AS id, "
                + "hd.ma_hoa_don AS maHD, "
                + "sp.ma_san_pham AS maSP, "
                + "sp.ten_san_pham AS tenSP, "
                + "ms.ten_mau AS mauSac, "
                + "kt.ten_kich_thuoc AS kichThuoc, "
                + "hdct.so_luong AS soLuong, "
                + "hdct.don_gia AS donGia, "
                + "(hdct.so_luong * hdct.don_gia) AS thanhTien " // Hết phần SELECT
                + "FROM hoa_don_chi_tiet hdct " // Bắt đầu phần FROM (phải có dấu cách ở đầu)
                + "JOIN hoa_don hd ON hdct.id_hoa_don = hd.id "
                + "JOIN san_pham_chi_tiet spct ON hdct.id_san_pham_chi_tiet = spct.id "
                + "JOIN san_pham sp ON spct.id_san_pham = sp.id "
                + "JOIN mau_sac ms ON spct.id_mau_sac = ms.id "
                + "JOIN kich_thuoc kt ON spct.id_kich_thuoc = kt.id "
                + "WHERE hd.ma_hoa_don = ?"; // Dấu ? này cực kỳ quan trọng

        // Gọi XJdbc để lấy danh sách
        return XJdbc.getBeanList(HoaDonChiTiet.class, sql, maHD);
    }
}
