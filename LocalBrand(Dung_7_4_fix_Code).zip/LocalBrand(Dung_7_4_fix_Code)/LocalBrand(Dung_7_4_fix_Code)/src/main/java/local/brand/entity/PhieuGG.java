/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.entity;

import java.util.Date;

/**
 *
 * @author ASUS
 */
public class PhieuGG {
    private String ma;
    private String ten;
    private String loai;
    private double dieuKien;        // Điều kiện áp dụng
    private double giaTriGiam;      // Giá trị giảm
    private double giamGiaToiDa;    // Giảm tối đa
    private int soLuong;
    private int soLuongDaDung;
    private Date ngayBatDau;
    private Date ngayKetThuc;
    private boolean trangThai;      // true = hoạt động
    
    public PhieuGG() {
    }

    public PhieuGG(String ma, String ten, String loai, double dieuKien, double giaTriGiam,
            double giamGiaToiDa, int soLuong, int soLuongDaDung,
            Date ngayBatDau, Date ngayKetThuc, boolean trangThai) {
        this.ma = ma;
        this.ten = ten;
        this.loai = loai;
        this.dieuKien = dieuKien;
        this.giaTriGiam = giaTriGiam;
        this.giamGiaToiDa = giamGiaToiDa;
        this.soLuong = soLuong;
        this.soLuongDaDung = soLuongDaDung;
        this.ngayBatDau = ngayBatDau;
        this.ngayKetThuc = ngayKetThuc;
        this.trangThai = trangThai;
    }

    // Getter - Setter
    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getLoai() {
        return loai;
    }

    public void setLoai(String loai) {
        this.loai = loai;
    }

    public double getDieuKien() {
        return dieuKien;
    }

    public void setDieuKien(double dieuKien) {
        this.dieuKien = dieuKien;
    }

    public double getGiaTriGiam() {
        return giaTriGiam;
    }

    public void setGiaTriGiam(double giaTriGiam) {
        this.giaTriGiam = giaTriGiam;
    }

    public double getGiamGiaToiDa() {
        return giamGiaToiDa;
    }

    public void setGiamGiaToiDa(double giamGiaToiDa) {
        this.giamGiaToiDa = giamGiaToiDa;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public int getSoLuongDaDung() {
        return soLuongDaDung;
    }

    public void setSoLuongDaDung(int soLuongDaDung) {
        this.soLuongDaDung = soLuongDaDung;
    }

    public Date getNgayBatDau() {
        return ngayBatDau;
    }

    public void setNgayBatDau(Date ngayBatDau) {
        this.ngayBatDau = ngayBatDau;
    }

    public Date getNgayKetThuc() {
        return ngayKetThuc;
    }

    public void setNgayKetThuc(Date ngayKetThuc) {
        this.ngayKetThuc = ngayKetThuc;
    }

    public boolean isTrangThai() {
        return trangThai;
    }

    public void setTrangThai(boolean trangThai) {
        this.trangThai = trangThai;
    }
    
}
