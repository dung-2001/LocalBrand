/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package local.brand.ui.manager;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import local.brand.entity.ChatLieu;
import local.brand.entity.DanhMuc;
import local.brand.entity.KieuDang;
import local.brand.entity.SanPham;
import local.brand.ulti.XJdbc;

/**
 *
 * @author ASUS
 */
public class SanPhamManagerJDialog extends javax.swing.JDialog {

    private final local.brand.dao.SanPhamDAO sanPhamDAO = new local.brand.dao.impl.SanPhamDAOImpl();
    private final local.brand.dao.DanhMucDAO danhMucDAO = new local.brand.dao.impl.DanhMucDAOImpl();
    private final local.brand.dao.ChatLieuDAO chatLieuDAO = new local.brand.dao.impl.ChatLieuDAOImpl();
    private final local.brand.dao.KieuDangDAO kieuDangDAO = new local.brand.dao.impl.KieuDangDAOImpl();

    DefaultTableModel model;
    private int selectedId = -1;

    public SanPhamManagerJDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        model = (DefaultTableModel) tblSanPham.getModel();
        initForm();
        btnGiamGia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGiamGiaActionPerformed(evt);
            }
        });

    }

    private void initForm() {
        setLocationRelativeTo(null);
        txtId.setEditable(false);
        txtMaSanPham.setEditable(true);
        txtSoLuong.setEditable(false);

        loadComboBox();
        loadTable();
        clearForm();
    }

    private void loadComboBox() {
        cboDanhMuc.removeAllItems();
        cboChatLieu.removeAllItems();
        cboKieuDang.removeAllItems();

        for (DanhMuc dm : danhMucDAO.selectAll()) {
            cboDanhMuc.addItem(dm.getTenDanhMuc());
        }

        for (ChatLieu cl : chatLieuDAO.selectAll()) {
            cboChatLieu.addItem(cl.getTenChatLieu());
        }

        for (KieuDang kd : kieuDangDAO.selectAll()) {
            cboKieuDang.addItem(kd.getTenKieuDang());
        }
    }

    private void loadTable() {
        model.setRowCount(0);
        List<SanPham> list = sanPhamDAO.selectAll();

        for (SanPham sp : list) {
            DanhMuc dm = danhMucDAO.selectById(sp.getIdDanhMuc());
            ChatLieu cl = chatLieuDAO.selectById(sp.getIdChatLieu());
            KieuDang kd = kieuDangDAO.selectById(sp.getIdKieuDang());

            int tongSoLuong = sanPhamDAO.getTongSoLuongBySanPhamId(sp.getId());
            String trangThaiHienThi = tongSoLuong > 0 ? "Còn hàng" : "Hết hàng";

            model.addRow(new Object[]{
                sp.getId(),
                sp.getMaSanPham(),
                sp.getTenSanPham(),
                dm != null ? dm.getTenDanhMuc() : "",
                cl != null ? cl.getTenChatLieu() : "",
                kd != null ? kd.getTenKieuDang() : "",
                trangThaiHienThi,
                tongSoLuong
            });
        }
    }

    private boolean validateForm() {
        String ma = txtMaSanPham.getText().trim();
        String ten = txtTenSanPham.getText().trim();

        if (ma.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mã sản phẩm không được để trống");
            txtMaSanPham.requestFocus();
            return false;
        }

        if (ten.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tên sản phẩm không được để trống");
            txtTenSanPham.requestFocus();
            return false;
        }

        if (ma.length() > 30) {
            JOptionPane.showMessageDialog(this, "Mã sản phẩm tối đa 30 ký tự");
            txtMaSanPham.requestFocus();
            return false;
        }

        if (ten.length() > 150) {
            JOptionPane.showMessageDialog(this, "Tên sản phẩm tối đa 150 ký tự");
            txtTenSanPham.requestFocus();
            return false;
        }

        if (cboDanhMuc.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn danh mục");
            return false;
        }

        if (cboChatLieu.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn chất liệu");
            return false;
        }

        if (cboKieuDang.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn kiểu dáng");
            return false;
        }

        SanPham spTonTai = sanPhamDAO.selectByMaSanPham(ma);

        if (txtId.getText().trim().isEmpty()) {
            if (spTonTai != null) {
                JOptionPane.showMessageDialog(this, "Mã sản phẩm đã tồn tại");
                txtMaSanPham.requestFocus();
                return false;
            }
        } else {
            int idDangSua = Integer.parseInt(txtId.getText().trim());
            if (spTonTai != null && spTonTai.getId() != idDangSua) {
                JOptionPane.showMessageDialog(this, "Mã sản phẩm đã tồn tại");
                txtMaSanPham.requestFocus();
                return false;
            }
        }

        return true;
    }

    private void clearForm() {
        txtId.setText("");
        txtMaSanPham.setText("");
        txtTenSanPham.setText("");
        txtSoLuong.setText("0");

        txtMaSanPham.setEditable(true);

        if (cboDanhMuc.getItemCount() > 0) {
            cboDanhMuc.setSelectedIndex(0);
        }

        if (cboChatLieu.getItemCount() > 0) {
            cboChatLieu.setSelectedIndex(0);
        }

        if (cboKieuDang.getItemCount() > 0) {
            cboKieuDang.setSelectedIndex(0);
        }

        rdoDangBan.setSelected(true);
        tblSanPham.clearSelection();
        selectedId = -1;
    }

    private SanPham getFormData() {
        String tenDanhMuc = cboDanhMuc.getSelectedItem().toString();
        String tenChatLieu = cboChatLieu.getSelectedItem().toString();
        String tenKieuDang = cboKieuDang.getSelectedItem().toString();

        DanhMuc dm = getDanhMucByTen(tenDanhMuc);
        ChatLieu cl = getChatLieuByTen(tenChatLieu);
        KieuDang kd = getKieuDangByTen(tenKieuDang);

        SanPham sp = new SanPham();
        sp.setMaSanPham(txtMaSanPham.getText().trim());
        sp.setTenSanPham(txtTenSanPham.getText().trim());
        sp.setIdDanhMuc(dm.getId());
        sp.setIdChatLieu(cl.getId());
        sp.setIdKieuDang(kd.getId());
        sp.setTrangThai(rdoDangBan.isSelected() ? 1 : 0);

        return sp;
    }

    private void setFormData(SanPham sp) {
        txtId.setText(String.valueOf(sp.getId()));
        txtMaSanPham.setText(sp.getMaSanPham());
        txtTenSanPham.setText(sp.getTenSanPham());
        txtMaSanPham.setEditable(false);

        DanhMuc dm = danhMucDAO.selectById(sp.getIdDanhMuc());
        ChatLieu cl = chatLieuDAO.selectById(sp.getIdChatLieu());
        KieuDang kd = kieuDangDAO.selectById(sp.getIdKieuDang());

        if (dm != null) {
            cboDanhMuc.setSelectedItem(dm.getTenDanhMuc());
        }

        if (cl != null) {
            cboChatLieu.setSelectedItem(cl.getTenChatLieu());
        }

        if (kd != null) {
            cboKieuDang.setSelectedItem(kd.getTenKieuDang());
        }

        if (sp.getTrangThai() == 1) {
            rdoDangBan.setSelected(true);
        } else {
            rdoNgungBan.setSelected(true);
        }

        int tongSoLuong = sanPhamDAO.getTongSoLuongBySanPhamId(sp.getId());
        txtSoLuong.setText(String.valueOf(tongSoLuong));
    }

    private void insertSanPham() {
        if (!validateForm()) {
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc muốn thêm sản phẩm này không?",
                "Xác nhận thêm",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            SanPham sp = getFormData();
            sanPhamDAO.insert(sp);
            JOptionPane.showMessageDialog(this, "Thêm sản phẩm thành công");
            loadTable();
            clearForm();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Thêm thất bại: " + e.getMessage());
        }
    }

    private void deleteSanPham() {
        if (txtId.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm cần xóa");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc muốn xóa sản phẩm này không?",
                "Xác nhận xóa",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            int id = Integer.parseInt(txtId.getText().trim());
            sanPhamDAO.delete(id);
            JOptionPane.showMessageDialog(this, "Xóa sản phẩm thành công");
            loadTable();
            clearForm();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Xóa thất bại: " + e.getMessage());
        }
    }

    private void updateSanPham() {
        if (txtId.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm cần sửa");
            return;
        }

        if (!validateForm()) {
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc muốn cập nhật sản phẩm này không?",
                "Xác nhận sửa",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            SanPham sp = getFormData();
            sp.setId(Integer.parseInt(txtId.getText()));
            sanPhamDAO.update(sp);
            JOptionPane.showMessageDialog(this, "Cập nhật sản phẩm thành công");
            loadTable();
            clearForm();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Cập nhật thất bại: " + e.getMessage());
        }
    }

    private void searchSanPham() {
        String keyword = txtTim.getText().trim();

        model.setRowCount(0);

        List<SanPham> list;
        if (keyword.isEmpty()) {
            list = sanPhamDAO.selectAll();
        } else {
            list = sanPhamDAO.selectByKeyword(keyword);
        }

        for (SanPham sp : list) {
            DanhMuc dm = danhMucDAO.selectById(sp.getIdDanhMuc());
            ChatLieu cl = chatLieuDAO.selectById(sp.getIdChatLieu());
            KieuDang kd = kieuDangDAO.selectById(sp.getIdKieuDang());
            int tongSoLuong = sanPhamDAO.getTongSoLuongBySanPhamId(sp.getId());

            model.addRow(new Object[]{
                sp.getId(),
                sp.getMaSanPham(),
                sp.getTenSanPham(),
                dm != null ? dm.getTenDanhMuc() : "",
                cl != null ? cl.getTenChatLieu() : "",
                kd != null ? kd.getTenKieuDang() : "",
                sp.getTrangThai() == 1 ? "Còn hàng" : "Ngừng bán",
                tongSoLuong
            });
        }
    }

    private void sortSanPham() {
        List<SanPham> list = new ArrayList<>(sanPhamDAO.selectAll());

        list.sort(Comparator.comparing(SanPham::getTenSanPham, String.CASE_INSENSITIVE_ORDER));

        model.setRowCount(0);
        for (SanPham sp : list) {
            DanhMuc dm = danhMucDAO.selectById(sp.getIdDanhMuc());
            ChatLieu cl = chatLieuDAO.selectById(sp.getIdChatLieu());
            KieuDang kd = kieuDangDAO.selectById(sp.getIdKieuDang());
            int tongSoLuong = sanPhamDAO.getTongSoLuongBySanPhamId(sp.getId());

            model.addRow(new Object[]{
                sp.getId(),
                sp.getMaSanPham(),
                sp.getTenSanPham(),
                dm != null ? dm.getTenDanhMuc() : "",
                cl != null ? cl.getTenChatLieu() : "",
                kd != null ? kd.getTenKieuDang() : "",
                sp.getTrangThai() == 1 ? "Còn hàng" : "Ngừng bán",
                tongSoLuong
            });
        }
    }

    private void openSanPhamChiTietForm(int idSanPham) {
        SanPhamChiTietManagerJDialog dialog = new SanPhamChiTietManagerJDialog(null, true, idSanPham);
        dialog.setVisible(true);

        loadTable();

        if (selectedId != -1) {
            SanPham sp = sanPhamDAO.selectById(selectedId);
            if (sp != null) {
                setFormData(sp);
            }
        }
    }

    private void tableClick() {
        int row = tblSanPham.getSelectedRow();
        if (row < 0) {
            return;
        }

        int id = Integer.parseInt(tblSanPham.getValueAt(row, 0).toString());
        SanPham sp = sanPhamDAO.selectById(id);

        if (sp != null) {
            setFormData(sp);
            selectedId = id;
        }
    }

    private DanhMuc getDanhMucByTen(String ten) {
        for (DanhMuc dm : danhMucDAO.selectAll()) {
            if (dm.getTenDanhMuc().equalsIgnoreCase(ten)) {
                return dm;
            }
        }
        return null;
    }

    private ChatLieu getChatLieuByTen(String ten) {
        for (ChatLieu cl : chatLieuDAO.selectAll()) {
            if (cl.getTenChatLieu().equalsIgnoreCase(ten)) {
                return cl;
            }
        }
        return null;
    }

    private KieuDang getKieuDangByTen(String ten) {
        for (KieuDang kd : kieuDangDAO.selectAll()) {
            if (kd.getTenKieuDang().equalsIgnoreCase(ten)) {
                return kd;
            }
        }
        return null;
    }

    private void openGiamGiaForm() {
        GiamGiaManagerJDialog dialog = new GiamGiaManagerJDialog(this, true);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    public void capNhatTrangThaiTheoTonKho(int idSanPham) {
        String sql = """
        UPDATE san_pham
        SET trang_thai = CASE
            WHEN (
                SELECT ISNULL(SUM(so_luong), 0)
                FROM san_pham_chi_tiet
                WHERE id_san_pham = ?
            ) > 0 THEN 1
            ELSE 0
        END
        WHERE id = ?
    """;
        XJdbc.executeUpdate(sql, idSanPham, idSanPham);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        txtTim = new javax.swing.JTextField();
        btnTim = new javax.swing.JButton();
        pnlMenu = new javax.swing.JPanel();
        btnSanPham = new javax.swing.JButton();
        btnBienThe = new javax.swing.JButton();
        btnGiamGia = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        txtMaSanPham = new javax.swing.JTextField();
        txtTenSanPham = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        cboDanhMuc = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        cboChatLieu = new javax.swing.JComboBox<>();
        cboKieuDang = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        rdoDangBan = new javax.swing.JRadioButton();
        rdoNgungBan = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSanPham = new javax.swing.JTable();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        btnSapxep = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        txtSoLuong = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel1.setText("QUẢN LÝ SẢN PHẨM");

        btnTim.setText("Tìm");
        btnTim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimActionPerformed(evt);
            }
        });

        pnlMenu.setBackground(new java.awt.Color(0, 0, 0));

        btnSanPham.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btnSanPham.setText("Sản Phẩm");
        btnSanPham.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSanPhamActionPerformed(evt);
            }
        });

        btnBienThe.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btnBienThe.setText("Biến thể");
        btnBienThe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBienTheActionPerformed(evt);
            }
        });

        btnGiamGia.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btnGiamGia.setText("Giam giá");
        btnGiamGia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGiamGiaActionPerformed(evt);
            }
        });

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/local/brand/icons/ChatGPT Image Mar 13, 2026, 12_50_16 PM (1).png"))); // NOI18N
        jLabel2.setText("jLabel1");

        javax.swing.GroupLayout pnlMenuLayout = new javax.swing.GroupLayout(pnlMenu);
        pnlMenu.setLayout(pnlMenuLayout);
        pnlMenuLayout.setHorizontalGroup(
            pnlMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMenuLayout.createSequentialGroup()
                .addGroup(pnlMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlMenuLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(pnlMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnBienThe)
                            .addComponent(btnSanPham)
                            .addComponent(btnGiamGia))
                        .addGap(0, 12, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pnlMenuLayout.setVerticalGroup(
            pnlMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSanPham)
                .addGap(53, 53, 53)
                .addComponent(btnBienThe)
                .addGap(45, 45, 45)
                .addComponent(btnGiamGia)
                .addContainerGap(82, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel3.setText("ID");

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel4.setText("TENSP");

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel5.setText("MASP");

        jLabel8.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel8.setText("DANHMUC");

        jLabel6.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel6.setText("CHATLIEU");

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel7.setText("KIEUDANG");

        jLabel9.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel9.setText("TRANGTHAI");

        buttonGroup1.add(rdoDangBan);
        rdoDangBan.setText("CON HANG");

        buttonGroup1.add(rdoNgungBan);
        rdoNgungBan.setText("NGUNG BAN");

        tblSanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "MASP", "TENSP", "DANHMUC", "CHATLIEU", "KIEUDANG", "TRANGTHAI", "SOLUONG"
            }
        ));
        tblSanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblSanPhamMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblSanPham);

        btnThem.setText("THEM");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setText("SUA");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnXoa.setText("XOA");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        btnSapxep.setText("SAPXEP");
        btnSapxep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSapxepActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel10.setText("SOLUONG");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cboChatLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtMaSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(71, 71, 71)
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(txtTenSanPham))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel8))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(71, 71, 71)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel10)
                                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(cboKieuDang, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cboDanhMuc, 0, 125, Short.MAX_VALUE)
                                    .addComponent(txtSoLuong))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(73, 73, 73))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtTim, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnTim))
                            .addComponent(jLabel9)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rdoDangBan)
                                .addGap(18, 18, 18)
                                .addComponent(rdoNgungBan)))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(btnThem)
                .addGap(71, 71, 71)
                .addComponent(btnSua)
                .addGap(64, 64, 64)
                .addComponent(btnXoa)
                .addGap(62, 62, 62)
                .addComponent(btnSapxep)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtTim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnTim))
                        .addGap(54, 54, 54)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(txtTenSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(45, 45, 45)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtMaSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8)
                            .addComponent(cboDanhMuc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(45, 45, 45)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(cboChatLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cboKieuDang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10)
                            .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rdoDangBan)
                            .addComponent(rdoNgungBan)))
                    .addComponent(pnlMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThem)
                    .addComponent(btnSua)
                    .addComponent(btnXoa)
                    .addComponent(btnSapxep))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        insertSanPham();
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        updateSanPham();
    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        deleteSanPham();
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnSapxepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSapxepActionPerformed
        sortSanPham();
    }//GEN-LAST:event_btnSapxepActionPerformed

    private void btnTimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimActionPerformed
        searchSanPham();
    }//GEN-LAST:event_btnTimActionPerformed

    private void tblSanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblSanPhamMouseClicked
        tableClick();
    }//GEN-LAST:event_tblSanPhamMouseClicked

    private void btnSanPhamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSanPhamActionPerformed

    }//GEN-LAST:event_btnSanPhamActionPerformed

    private void btnBienTheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBienTheActionPerformed
        int row = tblSanPham.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một sản phẩm trên bảng!");
            return;
        }

        int id = Integer.parseInt(tblSanPham.getValueAt(row, 0).toString());

        SanPhamChiTietManagerJDialog chiTiet = new SanPhamChiTietManagerJDialog(null, true, id);
        chiTiet.setVisible(true);

        loadTable();

        if (selectedId != -1) {
            SanPham sp = sanPhamDAO.selectById(selectedId);
            if (sp != null) {
                setFormData(sp);
            }
        }
    }//GEN-LAST:event_btnBienTheActionPerformed

    private void btnGiamGiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGiamGiaActionPerformed
        openGiamGiaForm();
    }//GEN-LAST:event_btnGiamGiaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SanPhamManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SanPhamManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SanPhamManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SanPhamManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                SanPhamManagerJDialog dialog = new SanPhamManagerJDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBienThe;
    private javax.swing.JButton btnGiamGia;
    private javax.swing.JButton btnSanPham;
    private javax.swing.JButton btnSapxep;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnTim;
    private javax.swing.JButton btnXoa;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cboChatLieu;
    private javax.swing.JComboBox<String> cboDanhMuc;
    private javax.swing.JComboBox<String> cboKieuDang;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel pnlMenu;
    private javax.swing.JRadioButton rdoDangBan;
    private javax.swing.JRadioButton rdoNgungBan;
    private javax.swing.JTable tblSanPham;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtMaSanPham;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtTenSanPham;
    private javax.swing.JTextField txtTim;
    // End of variables declaration//GEN-END:variables

}
