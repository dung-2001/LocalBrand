/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package local.brand.dao;

import java.math.BigDecimal;
import java.util.List;
import local.brand.entity.SanPhamChiTiet;

/**
 *
 * @author ASUS
 */
public interface SanPhamChiTietDAO {
    List<SanPhamChiTiet> selectAll();
    SanPhamChiTiet selectById(int id);
    List<SanPhamChiTiet> selectByIdSanPham(int idSanPham);
    void insert(SanPhamChiTiet entity);
    void update(SanPhamChiTiet entity);
    void delete(int id);
    boolean checkTonTai(int idSanPham, int idMauSac, int idKichThuoc);
    boolean checkTonTaiSua(int idSanPham, int idMauSac, int idKichThuoc, int idDangSua);
    String generateNextMa();
    boolean isMaExists(String ma);
    void congSoLuongBienThe(int idSanPham, int idMauSac, int idKichThuoc,
                            int soLuongCong, BigDecimal donGia, int trangThai);
}
