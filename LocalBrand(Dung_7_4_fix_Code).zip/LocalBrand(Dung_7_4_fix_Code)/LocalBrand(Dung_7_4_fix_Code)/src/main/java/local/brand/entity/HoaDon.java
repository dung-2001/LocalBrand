/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author ASUS
 */
public class HoaDon {
    private int id;
    private int idNhanVien;
    private Integer idKhach; 
    private int idHinhThuc;  
    private String tenHinhThuc;
    private Integer phieuGiam; 
    private String maHoaDon;
    private Date thoiGianMua;
    private BigDecimal tongTien;
    private int trangThai;
    private BigDecimal tienGiam;
    private BigDecimal thanhTien;
    private String tenKh; 
    private String sdtKh; 

    public HoaDon() {
        this.tongTien = BigDecimal.ZERO;
        this.tienGiam = BigDecimal.ZERO;
        this.thanhTien = BigDecimal.ZERO;
    }

    // --- GETTER & SETTER ---
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdNhanVien() { return idNhanVien; }
    public void setIdNhanVien(int idNhanVien) { this.idNhanVien = idNhanVien; }

    public Integer getIdKhach() { return idKhach; }
    public void setIdKhach(Integer idKhach) { this.idKhach = idKhach; }

    public int getIdHinhThuc() { return idHinhThuc; }
    public void setIdHinhThuc(int idHinhThuc) { this.idHinhThuc = idHinhThuc; }

    public Integer getPhieuGiam() { return phieuGiam; }
    public void setPhieuGiam(Integer phieuGiam) { this.phieuGiam = phieuGiam; }

    public String getMaHoaDon() { return maHoaDon; }
    public void setMaHoaDon(String maHoaDon) { this.maHoaDon = maHoaDon; }

    public Date getThoiGianMua() { return thoiGianMua; }
    public void setThoiGianMua(Date thoiGianMua) { this.thoiGianMua = thoiGianMua; }

    public BigDecimal getTongTien() { return tongTien; }
    public void setTongTien(BigDecimal tongTien) { this.tongTien = tongTien; }

    public int getTrangThai() { return trangThai; }
    public void setTrangThai(int trangThai) { this.trangThai = trangThai; }

    public BigDecimal getTienGiam() { return tienGiam; }
    public void setTienGiam(BigDecimal tienGiam) { this.tienGiam = tienGiam; }

    public BigDecimal getThanhTien() { return thanhTien; }
    public void setThanhTien(BigDecimal thanhTien) { this.thanhTien = thanhTien; }

    public String getTenKh() { return tenKh; }
    public void setTenKh(String tenKh) { this.tenKh = tenKh; }

    public String getSdtKh() { return sdtKh; }
    public void setSdtKh(String sdtKh) { 
        this.sdtKh = sdtKh; 
    }
    public String getTenHinhThuc() { 
        return tenHinhThuc; 
    }
    public void setTenHinhThuc(String tenHinhThuc) { 
        this.tenHinhThuc = tenHinhThuc; 
    }
    /**
     * Hàm hiển thị text cho JTable
     * Giúp chuyển đổi số trạng thái từ database sang chữ tiếng Việt
     */
    public String getTrangThaiHienThi() {
        switch (this.trangThai) {
            case 1:
                return "Đã thanh toán";
            case 0:
                return "Chờ thanh toán";
            case -1:
                return "Đã hủy";
            default:
                return "Không xác định";
        }
    }
}
