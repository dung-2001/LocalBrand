/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.dao.impl;

import java.sql.ResultSet;
import java.util.List;
import local.brand.dao.SanPhamDAO;
import local.brand.entity.SanPham;
import local.brand.ulti.XJdbc;

/**
 *
 * @author ASUS
 */
public class SanPhamDAOImpl implements SanPhamDAO {

    private static final String INSERT_SQL = """
        INSERT INTO san_pham (
            id_danh_muc, id_chat_lieu, id_kieu_dang,
            ma_san_pham, ten_san_pham, trang_thai
        )
        VALUES (?, ?, ?, ?, ?, ?)
        """;

    private static final String UPDATE_SQL = """
        UPDATE san_pham
        SET id_danh_muc = ?,
            id_chat_lieu = ?,
            id_kieu_dang = ?,
            ma_san_pham = ?,
            ten_san_pham = ?,
            trang_thai = ?
        WHERE id = ?
        """;

    private static final String DELETE_SQL = """
        DELETE FROM san_pham
        WHERE id = ?
        """;

    private static final String SELECT_BY_ID = """
        SELECT
            id AS id,
            id_danh_muc AS idDanhMuc,
            id_chat_lieu AS idChatLieu,
            id_kieu_dang AS idKieuDang,
            ma_san_pham AS maSanPham,
            ten_san_pham AS tenSanPham,
            trang_thai AS trangThai
        FROM san_pham
        WHERE id = ?
        """;

    private static final String SELECT_ALL = """
        SELECT
            id AS id,
            id_danh_muc AS idDanhMuc,
            id_chat_lieu AS idChatLieu,
            id_kieu_dang AS idKieuDang,
            ma_san_pham AS maSanPham,
            ten_san_pham AS tenSanPham,
            trang_thai AS trangThai
        FROM san_pham
        ORDER BY id DESC
        """;

    private static final String SELECT_BY_KEYWORD = """
        SELECT
            id AS id,
            id_danh_muc AS idDanhMuc,
            id_chat_lieu AS idChatLieu,
            id_kieu_dang AS idKieuDang,
            ma_san_pham AS maSanPham,
            ten_san_pham AS tenSanPham,
            trang_thai AS trangThai
        FROM san_pham
        WHERE ma_san_pham LIKE ? OR ten_san_pham LIKE ?
        ORDER BY id DESC
        """;
    
    private static final String GET_TONG_SO_LUONG = """
    SELECT ISNULL(SUM(so_luong), 0)
    FROM san_pham_chi_tiet
    WHERE id_san_pham = ?
    """;
    
    private static final String SELECT_BY_MA_SAN_PHAM = """
    SELECT
        id AS id,
        id_danh_muc AS idDanhMuc,
        id_chat_lieu AS idChatLieu,
        id_kieu_dang AS idKieuDang,
        ma_san_pham AS maSanPham,
        ten_san_pham AS tenSanPham,
        trang_thai AS trangThai
    FROM san_pham
    WHERE ma_san_pham = ?
    """;
    
    @Override
    public void insert(SanPham entity) {
        XJdbc.executeUpdate(
                INSERT_SQL,
                entity.getIdDanhMuc(),
                entity.getIdChatLieu(),
                entity.getIdKieuDang(),
                entity.getMaSanPham(),
                entity.getTenSanPham(),
                entity.getTrangThai()
        );
    }

    @Override
    public void update(SanPham entity) {
        XJdbc.executeUpdate(
                UPDATE_SQL,
                entity.getIdDanhMuc(),
                entity.getIdChatLieu(),
                entity.getIdKieuDang(),
                entity.getMaSanPham(),
                entity.getTenSanPham(),
                entity.getTrangThai(),
                entity.getId()
        );
    }

    @Override
    public void delete(Integer id) {
        XJdbc.executeUpdate(DELETE_SQL, id);
    }

    @Override
    public SanPham selectById(Integer id) {
        return XJdbc.getSingleBean(SanPham.class, SELECT_BY_ID, id);
    }

    @Override
    public List<SanPham> selectAll() {
        return XJdbc.getBeanList(SanPham.class, SELECT_ALL);
    }

    @Override
    public List<SanPham> selectByKeyword(String keyword) {
        String value = "%" + keyword + "%";
        return XJdbc.getBeanList(SanPham.class, SELECT_BY_KEYWORD, value, value);
    }

    @Override
    public int getTongSoLuongBySanPhamId(Integer id) {
        try (ResultSet rs = XJdbc.executeQuery(GET_TONG_SO_LUONG, id)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public boolean existsByMaSanPham(String maSanPham) {
       return selectByMaSanPham(maSanPham) != null;
    }

    @Override
    public SanPham selectByMaSanPham(String maSanPham) {
        return XJdbc.getSingleBean(SanPham.class, SELECT_BY_MA_SAN_PHAM, maSanPham);
    }
}
