/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.entity;

/**
 *
 * @author ASUS
 */
public class MauSac {
    private int id;
    private String maMauSac;
    private String tenMau;
    private int trangThai;

    public MauSac() {
    }

    public MauSac(int id, String maMauSac, String tenMau, int trangThai) {
        this.id = id;
        this.maMauSac = maMauSac;
        this.tenMau = tenMau;
        this.trangThai = trangThai;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMaMauSac() {
        return maMauSac;
    }

    public void setMaMauSac(String maMauSac) {
        this.maMauSac = maMauSac;
    }

    public String getTenMau() {
        return tenMau;
    }

    public void setTenMau(String tenMau) {
        this.tenMau = tenMau;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }
    
    @Override
    public String toString() {
        return this.tenMau; // Giả sử thuộc tính lưu tên màu là tenMauSac
    }
}
