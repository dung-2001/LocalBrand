/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package local.brand.dao;

import java.util.Date;
import java.util.List;

/**
 *
 * @author CAU DIEN
 */
public interface ThongKeDAO {

    
    // Lấy doanh thu theo từng tháng của một năm cụ thể
    // Trả về List các mảng Object: [Tháng, Doanh Thu]
    List<Object[]> getDoanhThuTheoNam(int nam);

    List<Object[]> getDoanhThuTheoKhoangNgay(java.util.Date tuNgay, java.util.Date denNgay);

    List<Object[]> getDoanhThuCacNgayTrongThang(int thang, int nam);
    List<Object[]> getDoanhThuTheoThang(int thang, int nam);
    Object[] getSummaryData(Integer nam, java.util.Date tuNgay, java.util.Date denNgay);
   
    public Object[] getSummaryByMonth(int i, int nam);
    List<Object[]> getDoanhThuTheo24Gio(Date ngay);
    Object[] getPaymentMethodSummary(Date tuNgay, Date denNgay);
    List<Object[]> getTopSellingProducts(Date tuNgay, Date denNgay, int limit);
}
