
package local.brand.ui.manager;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import local.brand.dao.HoaDonChiTietDAO;
import local.brand.dao.HoaDonDAO;
import local.brand.dao.impl.HoaDonChiTietDAOImpl;
import local.brand.dao.impl.HoaDonDAOImpl;
import local.brand.entity.HoaDon;
import local.brand.entity.HoaDonChiTiet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author ASUS
 */
public class HoaDonManagerJDialog extends javax.swing.JDialog {

    private final HoaDonDAO hoaDonDAO = new HoaDonDAOImpl();
    private final HoaDonChiTietDAO hoaDonChiTietDAO = new HoaDonChiTietDAOImpl();
    private final SimpleDateFormat userFormat = new SimpleDateFormat("dd/MM/yyyy");
    private final SimpleDateFormat sqlFormat = new SimpleDateFormat("yyyy-MM-dd");
    private final SimpleDateFormat hienThiNgayGio = new SimpleDateFormat("dd/MM/yyyy HH:mm");
    private final DecimalFormat tienFormat = new DecimalFormat("#,###");

    public HoaDonManagerJDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        fillComboBox();
        fillToTable();
        btnXuatExcel.addActionListener(evt -> btnXuatExcelActionPerformed(evt));
        btnInPDF.addActionListener(evt -> btnInPDFActionPerformed(evt));
    }

    private void fillComboBox() {
        javax.swing.DefaultComboBoxModel<String> model = (javax.swing.DefaultComboBoxModel<String>) jcbTrangThai.getModel();
        model.removeAllElements();
        model.addElement("Tất cả");
        model.addElement("Đã thanh toán");
        model.addElement("Chờ thanh toán");
        model.addElement("Đã hủy");
    }

    private Integer getTrangThaiFilter() {
        String statusFilter = (String) jcbTrangThai.getSelectedItem();
        if (statusFilter == null || statusFilter.equals("Tất cả")) {
            return null;
        }
        if (statusFilter.equals("Đã thanh toán")) {
            return 1;
        }
        if (statusFilter.equals("Chờ thanh toán")) {
            return 0;
        }
        return -1;
    }

    private String chuyenNgaySangSql(java.util.Date date) {
        if (date == null) {
            return "";
        }
        return sqlFormat.format(date);
    }

    private String formatTien(BigDecimal value) {
        BigDecimal v = value == null ? BigDecimal.ZERO : value;
        return tienFormat.format(v) + " VNĐ";
    }

    private HoaDon getSelectedHoaDon() {
        int row = tblHoaDon.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một hóa đơn!");
            return null;
        }
        String maHD = String.valueOf(tblHoaDon.getValueAt(row, 0));
        HoaDon hd = hoaDonDAO.selectById(maHD);
        if (hd == null) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy dữ liệu hóa đơn!");
        }
        return hd;
    }

    private void fillToTable() {
        DefaultTableModel model = (DefaultTableModel) tblHoaDon.getModel();
        model.setRowCount(0);

        try {
            String keyword = txtTimKiem.getText().trim();

            // Lấy Date trực tiếp từ JDateChooser
            java.util.Date dateStart = jdTuNgay.getDate();
            java.util.Date dateEnd = jdDenNgay.getDate();

            // Kiểm tra logic ngày bắt đầu <= ngày kết thúc
            if (dateStart != null && dateEnd != null && dateStart.after(dateEnd)) {
                JOptionPane.showMessageDialog(this, "Ngày bắt đầu không được lớn hơn ngày kết thúc!");
                return;
            }

            // Chuyển đổi sang chuỗi định dạng SQL (yyyy-MM-dd)
            String start = chuyenNgaySangSql(dateStart);
            String end = chuyenNgaySangSql(dateEnd);

            List<HoaDon> list = hoaDonDAO.selectByFilter(keyword, start, end, getTrangThaiFilter());

            for (HoaDon hd : list) {
                model.addRow(new Object[]{
                    hd.getMaHoaDon(),
                    hd.getThoiGianMua() != null ? hienThiNgayGio.format(hd.getThoiGianMua()) : "",
                    "NV" + hd.getIdNhanVien(),
                    (hd.getTenKh() == null || hd.getTenKh().trim().isEmpty()) ? "Khách lẻ" : hd.getTenKh(),
                    hd.getSdtKh() == null ? "" : hd.getSdtKh(),
                    formatTien(hd.getTongTien()),
                    hd.getTrangThaiHienThi(),
                    hd.getPhieuGiam() == null ? "Không có" : String.valueOf(hd.getPhieuGiam()),
                    formatTien(hd.getTienGiam()),
                    formatTien(hd.getThanhTien()),
                    hd.getTenHinhThuc() == null ? "Tiền mặt" : hd.getTenHinhThuc()
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi truy vấn dữ liệu!");
        }
    }

    private void xuatExcel() {
        try {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Chọn nơi lưu file Excel");
            chooser.setFileFilter(new FileNameExtensionFilter("Excel Files", "xlsx"));

            int result = chooser.showSaveDialog(this);
            if (result != JFileChooser.APPROVE_OPTION) {
                return;
            }

            File file = chooser.getSelectedFile();
            if (!file.getName().toLowerCase().endsWith(".xlsx")) {
                file = new File(file.getAbsolutePath() + ".xlsx");
            }

            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("HoaDon");

            Row header = sheet.createRow(0);
            for (int i = 0; i < tblHoaDon.getColumnCount(); i++) {
                header.createCell(i).setCellValue(tblHoaDon.getColumnName(i));
            }

            for (int i = 0; i < tblHoaDon.getRowCount(); i++) {
                Row row = sheet.createRow(i + 1);
                for (int j = 0; j < tblHoaDon.getColumnCount(); j++) {
                    Object value = tblHoaDon.getValueAt(i, j);
                    row.createCell(j).setCellValue(value == null ? "" : value.toString());
                }
            }

            for (int i = 0; i < tblHoaDon.getColumnCount(); i++) {
                sheet.autoSizeColumn(i);
            }

            try (FileOutputStream fos = new FileOutputStream(file)) {
                workbook.write(fos);
            }
            workbook.close();

            JOptionPane.showMessageDialog(this, "Xuất Excel thành công!");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Xuất Excel thất bại!");
        }
    }

    private void inHoaDonPdf() {
        HoaDon hd = getSelectedHoaDon();
        if (hd == null) {
            return;
        }

        try {
            List<HoaDonChiTiet> chiTietList = hoaDonChiTietDAO.selectByMaHD(hd.getMaHoaDon());

            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Chọn nơi lưu hóa đơn PDF");
            chooser.setSelectedFile(new File(hd.getMaHoaDon() + ".pdf"));
            chooser.setFileFilter(new FileNameExtensionFilter("PDF Files", "pdf"));

            int result = chooser.showSaveDialog(this);
            if (result != JFileChooser.APPROVE_OPTION) {
                return;
            }

            File file = chooser.getSelectedFile();
            if (!file.getName().toLowerCase().endsWith(".pdf")) {
                file = new File(file.getAbsolutePath() + ".pdf");
            }

            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(file));
            document.open();

            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
            Font boldFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 11);
            Font normalFont = FontFactory.getFont(FontFactory.HELVETICA, 11);

            Paragraph title = new Paragraph("HOA DON THANH TOAN", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            Paragraph shop = new Paragraph("LOCAL BRAND STORE", boldFont);
            shop.setAlignment(Element.ALIGN_CENTER);
            document.add(shop);
            document.add(new Paragraph("--------------------------------------------", normalFont));

            document.add(new Paragraph("Ma hoa don: " + hd.getMaHoaDon(), normalFont));
            document.add(new Paragraph("Thoi gian: " + (hd.getThoiGianMua() != null ? hienThiNgayGio.format(hd.getThoiGianMua()) : ""), normalFont));
            document.add(new Paragraph("Nhan vien: NV" + hd.getIdNhanVien(), normalFont));
            document.add(new Paragraph("Khach hang: " + (hd.getTenKh() == null || hd.getTenKh().trim().isEmpty() ? "Khach le" : hd.getTenKh()), normalFont));
            document.add(new Paragraph("So dien thoai: " + (hd.getSdtKh() == null ? "" : hd.getSdtKh()), normalFont));
            document.add(new Paragraph("Hinh thuc thanh toan: " + (hd.getTenHinhThuc() == null ? "Tien mat" : hd.getTenHinhThuc()), normalFont));
            document.add(new Paragraph("Trang thai: " + hd.getTrangThaiHienThi(), normalFont));
            document.add(new Paragraph("--------------------------------------------", normalFont));

            PdfPTable table = new PdfPTable(5);
            table.setWidthPercentage(100);
            table.setWidths(new float[]{3.5f, 1.5f, 1.5f, 1.6f, 1.8f});
            themHeader(table, "San pham", boldFont);
            themHeader(table, "Mau", boldFont);
            themHeader(table, "Size", boldFont);
            themHeader(table, "SL", boldFont);
            themHeader(table, "Thanh tien", boldFont);

            if (chiTietList != null && !chiTietList.isEmpty()) {
                for (HoaDonChiTiet ct : chiTietList) {
                    table.addCell(new Phrase(ct.getTenSP() == null ? "" : ct.getTenSP(), normalFont));
                    table.addCell(new Phrase(ct.getMauSac() == null ? "" : ct.getMauSac(), normalFont));
                    table.addCell(new Phrase(ct.getKichThuoc() == null ? "" : ct.getKichThuoc(), normalFont));
                    table.addCell(new Phrase(String.valueOf(ct.getSoLuong()), normalFont));
                    table.addCell(new Phrase(formatTien(ct.getThanhTien()), normalFont));
                }
            } else {
                PdfPCell empty = new PdfPCell(new Phrase("Khong co chi tiet san pham", normalFont));
                empty.setColspan(5);
                empty.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(empty);
            }
            document.add(table);
            document.add(new Paragraph("--------------------------------------------", normalFont));
            document.add(new Paragraph("Tong tien: " + formatTien(hd.getTongTien()), boldFont));
            document.add(new Paragraph("Tien giam: " + formatTien(hd.getTienGiam()), normalFont));
            document.add(new Paragraph("Thanh tien: " + formatTien(hd.getThanhTien()), boldFont));
            document.add(new Paragraph("Phieu giam: " + (hd.getPhieuGiam() == null ? "Khong co" : String.valueOf(hd.getPhieuGiam())), normalFont));
            document.add(new Paragraph(" ", normalFont));
            Paragraph thanks = new Paragraph("Cam on quy khach va hen gap lai!", boldFont);
            thanks.setAlignment(Element.ALIGN_CENTER);
            document.add(thanks);

            document.close();
            JOptionPane.showMessageDialog(this, "In PDF hóa đơn thành công!");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "In PDF hóa đơn thất bại!");
        }
    }

    private void themHeader(PdfPTable table, String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(cell);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jcbTrangThai = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        btnTimKiem = new javax.swing.JButton();
        btnLoc = new javax.swing.JButton();
        btnLamMoi = new javax.swing.JButton();
        btnChiTiet = new javax.swing.JButton();
        btnXuatExcel = new javax.swing.JButton();
        btnInPDF = new javax.swing.JButton();
        jdTuNgay = new com.toedter.calendar.JDateChooser();
        jdDenNgay = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblHoaDon = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));

        jLabel2.setText("Tìm kiếm");

        jLabel3.setText("Từ");

        jLabel4.setText("Đến");

        jcbTrangThai.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel5.setText("Trạng thái");

        btnTimKiem.setBackground(new java.awt.Color(255, 255, 0));
        btnTimKiem.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnTimKiem.setText("Tìm");
        btnTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemActionPerformed(evt);
            }
        });

        btnLoc.setBackground(new java.awt.Color(255, 255, 0));
        btnLoc.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLoc.setText("Lọc");
        btnLoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLocActionPerformed(evt);
            }
        });

        btnLamMoi.setBackground(new java.awt.Color(255, 255, 0));
        btnLamMoi.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLamMoi.setText("Làm mới");
        btnLamMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiActionPerformed(evt);
            }
        });

        btnChiTiet.setBackground(new java.awt.Color(255, 255, 0));
        btnChiTiet.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnChiTiet.setText("Xem chi tiết hóa đơn");
        btnChiTiet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChiTietActionPerformed(evt);
            }
        });

        btnXuatExcel.setBackground(new java.awt.Color(255, 255, 102));
        btnXuatExcel.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btnXuatExcel.setText("Xuất Excel");

        btnInPDF.setBackground(new java.awt.Color(255, 255, 102));
        btnInPDF.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btnInPDF.setText("In");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 59, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jcbTrangThai, 0, 126, Short.MAX_VALUE)
                    .addComponent(txtTimKiem))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnTimKiem)
                    .addComponent(btnLoc))
                .addGap(46, 46, 46)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jdTuNgay, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnChiTiet))
                .addGap(18, 18, 18)
                .addComponent(btnLamMoi)
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnXuatExcel)
                        .addGap(18, 18, 18)
                        .addComponent(btnInPDF))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jdDenNgay, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(105, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jdTuNgay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(btnTimKiem))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addComponent(jdDenNgay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jcbTrangThai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(btnLoc)
                    .addComponent(btnLamMoi)
                    .addComponent(btnChiTiet)
                    .addComponent(btnXuatExcel)
                    .addComponent(btnInPDF))
                .addGap(27, 27, 27))
        );

        tblHoaDon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "MÃ HĐ", "Thời gian mua", "Nhân viên", "Khách hàng", "Số ĐT KH", "Tổng tiền", "Trạng thái", "Phiếu giảm giá", "Tiền giảm", "Thành tiền", "Hình thức thanh toán"
            }
        ));
        jScrollPane1.setViewportView(tblHoaDon);

        jPanel2.setBackground(new java.awt.Color(255, 153, 153));

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        jLabel1.setText("QUẢN LÝ HÓA ĐƠN");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(295, 295, 295)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addContainerGap(11, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemActionPerformed
        fillToTable();
    }//GEN-LAST:event_btnTimKiemActionPerformed

    private void btnLocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLocActionPerformed
        fillToTable();
    }//GEN-LAST:event_btnLocActionPerformed

    private void btnLamMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiActionPerformed
        txtTimKiem.setText("");
        jdTuNgay.setDate(null); // Reset JDateChooser
        jdDenNgay.setDate(null); // Reset JDateChooser
        jcbTrangThai.setSelectedIndex(0);
        fillToTable();
    }//GEN-LAST:event_btnLamMoiActionPerformed

    private void btnChiTietActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChiTietActionPerformed
        HoaDon hd = getSelectedHoaDon();
        if (hd == null) {
            return;
        }
        HoaDonChiTietJDialog chiTietDlg = new HoaDonChiTietJDialog(new javax.swing.JFrame(), true, hd.getMaHoaDon());
        chiTietDlg.setVisible(true);
    }//GEN-LAST:event_btnChiTietActionPerformed

    private void btnXuatExcelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXuatExcelActionPerformed
        xuatExcel();
    }//GEN-LAST:event_btnXuatExcelActionPerformed

    private void btnInPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInPDFActionPerformed
        inHoaDonPdf();
    }//GEN-LAST:event_btnInPDFActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HoaDonManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HoaDonManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HoaDonManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HoaDonManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                HoaDonManagerJDialog dialog = new HoaDonManagerJDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnChiTiet;
    private javax.swing.JButton btnInPDF;
    private javax.swing.JButton btnLamMoi;
    private javax.swing.JButton btnLoc;
    private javax.swing.JButton btnTimKiem;
    private javax.swing.JButton btnXuatExcel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> jcbTrangThai;
    private com.toedter.calendar.JDateChooser jdDenNgay;
    private com.toedter.calendar.JDateChooser jdTuNgay;
    private javax.swing.JTable tblHoaDon;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables
}
