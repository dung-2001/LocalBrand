/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.entity;

import java.math.BigDecimal;

/**
 *
 * @author ASUS
 */
public class SanPhamGiamGia {
    private Integer id;
    private Integer idDotGiamGia;
    private Integer idSanPhamChiTiet;
    private BigDecimal giaSauGiam;
    private Integer trangThai;
    private String maSpChiTiet;
    private String tenSanPham;
    private String tenMau;
    private String tenKichThuoc;
    private BigDecimal donGiaGoc;
    private Integer soLuongTon;

    public SanPhamGiamGia() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdDotGiamGia() {
        return idDotGiamGia;
    }

    public void setIdDotGiamGia(Integer idDotGiamGia) {
        this.idDotGiamGia = idDotGiamGia;
    }

    public Integer getIdSanPhamChiTiet() {
        return idSanPhamChiTiet;
    }

    public void setIdSanPhamChiTiet(Integer idSanPhamChiTiet) {
        this.idSanPhamChiTiet = idSanPhamChiTiet;
    }

    public BigDecimal getGiaSauGiam() {
        return giaSauGiam;
    }

    public void setGiaSauGiam(BigDecimal giaSauGiam) {
        this.giaSauGiam = giaSauGiam;
    }

    public Integer getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(Integer trangThai) {
        this.trangThai = trangThai;
    }

    public String getMaSpChiTiet() {
        return maSpChiTiet;
    }

    public void setMaSpChiTiet(String maSpChiTiet) {
        this.maSpChiTiet = maSpChiTiet;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public String getTenMau() {
        return tenMau;
    }

    public void setTenMau(String tenMau) {
        this.tenMau = tenMau;
    }

    public String getTenKichThuoc() {
        return tenKichThuoc;
    }

    public void setTenKichThuoc(String tenKichThuoc) {
        this.tenKichThuoc = tenKichThuoc;
    }

    public BigDecimal getDonGiaGoc() {
        return donGiaGoc;
    }

    public void setDonGiaGoc(BigDecimal donGiaGoc) {
        this.donGiaGoc = donGiaGoc;
    }

    public Integer getSoLuongTon() {
        return soLuongTon;
    }

    public void setSoLuongTon(Integer soLuongTon) {
        this.soLuongTon = soLuongTon;
    }
}
