package local.brand.dao.impl;

import java.math.BigDecimal;
import java.util.List;
import local.brand.dao.SanPhamChiTietDAO;
import local.brand.entity.SanPhamChiTiet;
import local.brand.ulti.XJdbc;

public class SanPhamChiTietDAOImpl implements SanPhamChiTietDAO {

    private final String SELECT_SQL = "SELECT id, id_san_pham AS idSanPham, id_mau_sac AS idMauSac, "
            + "id_kich_thuoc AS idKichThuoc, ma_sp_chi_tiet AS maSpChiTiet, "
            + "so_luong AS soLuong, don_gia AS donGia, trang_thai AS trangThai "
            + "FROM san_pham_chi_tiet";

    @Override
    public List<SanPhamChiTiet> selectAll() {
        return XJdbc.getBeanList(SanPhamChiTiet.class, SELECT_SQL);
    }

    @Override
    public List<SanPhamChiTiet> selectByIdSanPham(int idSanPham) {
        String sql = SELECT_SQL + " WHERE id_san_pham = ?";
        return XJdbc.getBeanList(SanPhamChiTiet.class, sql, idSanPham);
    }

    @Override
    public SanPhamChiTiet selectById(int id) {
        String sql = SELECT_SQL + " WHERE id = ?";
        return XJdbc.getSingleBean(SanPhamChiTiet.class, sql, id);
    }

    @Override
    public void insert(SanPhamChiTiet spct) {
        String sql = "INSERT INTO san_pham_chi_tiet (id_san_pham, id_mau_sac, id_kich_thuoc, ma_sp_chi_tiet, so_luong, don_gia, trang_thai) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        XJdbc.executeUpdate(sql,
                spct.getIdSanPham(), spct.getIdMauSac(), spct.getIdKichThuoc(),
                spct.getMaSpChiTiet(), spct.getSoLuong(), spct.getDonGia(), spct.getTrangThai());
    }

    @Override
    public void update(SanPhamChiTiet spct) {
        // Đảm bảo các tên cột trùng khớp hoàn toàn với Database bạn vừa tạo
        String sql = "UPDATE san_pham_chi_tiet SET id_san_pham = ?, id_mau_sac = ?, id_kich_thuoc = ?, "
                + "ma_sp_chi_tiet = ?, so_luong = ?, don_gia = ?, trang_thai = ? WHERE id = ?";

        XJdbc.executeUpdate(sql,
                spct.getIdSanPham(),
                spct.getIdMauSac(),
                spct.getIdKichThuoc(),
                spct.getMaSpChiTiet(),
                spct.getSoLuong(),
                spct.getDonGia(),
                spct.getTrangThai(),
                spct.getId()); // ID này cực kỳ quan trọng
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM san_pham_chi_tiet WHERE id = ?";
        XJdbc.executeUpdate(sql, id);
    }

    @Override
    public boolean checkTonTai(int idSP, int idMS, int idKT) {
        String sql = "SELECT count(*) FROM san_pham_chi_tiet WHERE id_san_pham = ? AND id_mau_sac = ? AND id_kich_thuoc = ?";

        // Sử dụng getValue của bạn. 
        // SQL Server thường trả về Integer cho COUNT, nên mình ép kiểu về Number cho chắc ăn.
        Object result = XJdbc.getValue(sql, idSP, idMS, idKT);

        if (result != null) {
            int count = Integer.parseInt(result.toString());
            return count > 0;
        }
        return false;
    }

    @Override
    public boolean isMaExists(String ma) {
        String sql = "SELECT COUNT(*) FROM san_pham_chi_tiet WHERE ma_sp_chi_tiet = ?";
        Object res = XJdbc.getValue(sql, ma);
        return res != null && Integer.parseInt(res.toString()) > 0;
    }

    @Override
    public String generateNextMa() {
        // Lấy ID lớn nhất hiện tại
        String sql = "SELECT MAX(id) FROM san_pham_chi_tiet";
        Object result = XJdbc.getValue(sql);
        int nextId = (result == null) ? 1 : (int) result + 1;

        // Trả về định dạng SPCT + số (ví dụ: SPCT01, SPCT10)
        return String.format("SPCT%02d", nextId);
    }

    @Override
    public boolean checkTonTaiSua(int idSP, int idMau, int idKichThuoc, int idHienTai) {
        String sql = "SELECT COUNT(*) FROM san_pham_chi_tiet WHERE id_san_pham = ? AND id_mau_sac = ? AND id_kich_thuoc = ? AND id != ?";
        // Ép kiểu an toàn qua String để tránh lỗi ClassCastException giữa Integer/Long
        Object result = XJdbc.getValue(sql, idSP, idMau, idKichThuoc, idHienTai);

        return result != null && Integer.parseInt(result.toString()) > 0;
    }

    @Override
    public void congSoLuongBienThe(int idSanPham, int idMauSac, int idKichThuoc, int soLuongCong, BigDecimal donGia, int trangThai) {
        String sql = """
        UPDATE san_pham_chi_tiet
        SET so_luong = so_luong + ?, don_gia = ?, trang_thai = ?
        WHERE id_san_pham = ? AND id_mau_sac = ? AND id_kich_thuoc = ?
    """;
        XJdbc.executeUpdate(sql, soLuongCong, donGia, trangThai, idSanPham, idMauSac, idKichThuoc);
    }
}
