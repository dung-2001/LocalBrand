package local.brand.entity;

import java.math.BigDecimal;

/**
 * @author ASUS
 */
public class HoaDonChiTiet {

    private int id;
    private String maHD;
    private String maSP;
    private String tenSP;
    private String mauSac;
    private String kichThuoc;
    private int soLuong;
    private BigDecimal donGia;    // Đổi sang BigDecimal
    private BigDecimal thanhTien; // Đổi sang BigDecimal

    public HoaDonChiTiet() {
    }

    // Constructor đầy đủ tham số (đã cập nhật kiểu dữ liệu)
    public HoaDonChiTiet(int id, String maHD, String maSP, String tenSP, String mauSac, String kichThuoc, int soLuong, BigDecimal donGia, BigDecimal thanhTien) {
        this.id = id;
        this.maHD = maHD;
        this.maSP = maSP;
        this.tenSP = tenSP;
        this.mauSac = mauSac;
        this.kichThuoc = kichThuoc;
        this.soLuong = soLuong;
        this.donGia = donGia;
        this.thanhTien = thanhTien;
    }

    // --- GETTER & SETTER ---

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) {
        this.maHD = maHD;
    }

    public String getMaSP() {
        return maSP;
    }

    public void setMaSP(String maSP) {
        this.maSP = maSP;
    }

    public String getTenSP() {
        return tenSP;
    }

    public void setTenSP(String tenSP) {
        this.tenSP = tenSP;
    }

    public String getMauSac() {
        return mauSac;
    }

    public void setMauSac(String mauSac) {
        this.mauSac = mauSac;
    }

    public String getKichThuoc() {
        return kichThuoc;
    }

    public void setKichThuoc(String kichThuoc) {
        this.kichThuoc = kichThuoc;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public BigDecimal getDonGia() {
        return donGia;
    }

    public void setDonGia(BigDecimal donGia) {
        this.donGia = donGia;
    }

    public BigDecimal getThanhTien() {
        return thanhTien;
    }

    public void setThanhTien(BigDecimal thanhTien) {
        this.thanhTien = thanhTien;
    }
}