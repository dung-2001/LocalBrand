/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package local.brand.dao;
import java.sql.PreparedStatement;
import java.sql.*;
import java.util.ArrayList;
import local.brand.entity.PhieuGG;
import local.brand.ulti.XJdbc;


public class PhieuGiamGiaDAO {
    public ArrayList<PhieuGG> getAll() {
        ArrayList<PhieuGG> list = new ArrayList<>();
        String sql = "SELECT * FROM phieu_giam_gia";

        try (Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                PhieuGG p = new PhieuGG();
                p.setMa(rs.getString("ma_phieu"));
                p.setTen(rs.getString("ten_phieu"));
                p.setLoai(rs.getString("loai"));
                p.setNgayBatDau(rs.getDate("ngay_bat_dau"));
                p.setNgayKetThuc(rs.getDate("ngay_ket_thuc"));
                p.setDieuKien(rs.getDouble("dieu_kien"));
                p.setGiaTriGiam(rs.getDouble("gia_tri_giam"));
                p.setGiamGiaToiDa(rs.getDouble("giam_gia_toi_da"));
                p.setSoLuong(rs.getInt("so_luong_ma_giam_gia"));
                p.setSoLuongDaDung(rs.getInt("so_luong_dung_ma_giam"));
                p.setTrangThai(rs.getInt("trang_thai") == 1);

                list.add(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // Thêm
    public int insert(PhieuGG p) {
        String sql = "INSERT INTO phieu_giam_gia (ma_phieu, ten_phieu, loai, ngay_bat_dau, ngay_ket_thuc, dieu_kien, gia_tri_giam, trang_thai, giam_gia_toi_da, so_luong_ma_giam_gia, so_luong_dung_ma_giam) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.getMa());
            ps.setString(2, p.getTen());
            ps.setString(3, p.getLoai());
            ps.setDate(4, new java.sql.Date(p.getNgayBatDau().getTime()));
            ps.setDate(5, new java.sql.Date(p.getNgayKetThuc().getTime()));
            ps.setDouble(6, p.getDieuKien());
            ps.setDouble(7, p.getGiaTriGiam());
            ps.setInt(8, p.isTrangThai() ? 1 : 0);
            ps.setDouble(9, p.getGiamGiaToiDa());
            ps.setInt(10, p.getSoLuong());
            ps.setInt(11, p.getSoLuongDaDung());

            return ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Sửa
    public int update(PhieuGG p) {
        String sql = "UPDATE phieu_giam_gia SET ten_phieu=?, loai=?, ngay_bat_dau=?, ngay_ket_thuc=?, dieu_kien=?, gia_tri_giam=?, trang_thai=?, giam_gia_toi_da=?, so_luong_ma_giam_gia=?, so_luong_dung_ma_giam=? WHERE ma_phieu=?";

        try (Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.getTen());
            ps.setString(2, p.getLoai());
            ps.setDate(3, new java.sql.Date(p.getNgayBatDau().getTime()));
            ps.setDate(4, new java.sql.Date(p.getNgayKetThuc().getTime()));
            ps.setDouble(5, p.getDieuKien());
            ps.setDouble(6, p.getGiaTriGiam());
            ps.setInt(7, p.isTrangThai() ? 1 : 0);
            ps.setDouble(8, p.getGiamGiaToiDa());
            ps.setInt(9, p.getSoLuong());
            ps.setInt(10, p.getSoLuongDaDung());
            ps.setString(11, p.getMa());
            return ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Xoá
    public int delete(String ma) {
        String sql = "DELETE FROM phieu_giam_gia WHERE ma_phieu=?";
        try (Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, ma);
            return ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Tìm theo mã
    public PhieuGG findById(String ma) {
        String sql = "SELECT * FROM phieu_giam_gia WHERE ma_phieu=?";
        try (Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, ma);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                PhieuGG p = new PhieuGG();
                p.setMa(rs.getString("ma_phieu"));
                p.setTen(rs.getString("ten_phieu"));
                p.setLoai(rs.getString("loai"));
                p.setDieuKien(rs.getDouble("dieu_kien"));
                p.setGiaTriGiam(rs.getDouble("gia_tri_giam"));
                p.setGiamGiaToiDa(rs.getDouble("giam_gia_toi_da"));
                p.setSoLuong(rs.getInt("so_luong_ma_giam_gia"));
                p.setSoLuongDaDung(rs.getInt("so_luong_dung_ma_giam"));
                p.setNgayBatDau(rs.getDate("ngay_bat_dau"));
                p.setNgayKetThuc(rs.getDate("ngay_ket_thuc"));
                p.setTrangThai(rs.getBoolean("trang_thai"));

                return p;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public boolean checkTrungMa(String ma) {
        String sql = "SELECT COUNT(*) FROM phieu_giam_gia WHERE ma_phieu = ?";
        try (Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, ma);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean checkTrungTen(String ten) {
        String sql = "SELECT COUNT(*) FROM phieu_giam_gia WHERE ten_phieu = ?";
        try (Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, ten);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public ArrayList<PhieuGG> search(String keyword) {
        ArrayList<PhieuGG> list = new ArrayList<>();
        String sql = "SELECT * FROM phieu_giam_gia WHERE ma_phieu LIKE ? OR ten_phieu LIKE ? OR loai LIKE ?";
        try (Connection con = XJdbc.openConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            String key = "%" + keyword + "%";
            ps.setString(1, key);
            ps.setString(2, key);
            ps.setString(3, key);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                PhieuGG p = new PhieuGG();
                p.setMa(rs.getString("ma_phieu"));
                p.setTen(rs.getString("ten_phieu"));
                p.setLoai(rs.getString("loai"));
                p.setDieuKien(rs.getDouble("dieu_kien"));
                p.setGiaTriGiam(rs.getDouble("gia_tri_giam"));
                p.setGiamGiaToiDa(rs.getDouble("giam_gia_toi_da"));
                p.setSoLuong(rs.getInt("so_luong_ma_giam_gia"));
                p.setSoLuongDaDung(rs.getInt("so_luong_dung_ma_giam"));
                p.setNgayBatDau(rs.getDate("ngay_bat_dau"));
                p.setNgayKetThuc(rs.getDate("ngay_ket_thuc"));
                p.setTrangThai(rs.getBoolean("trang_thai"));

                list.add(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
