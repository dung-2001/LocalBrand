/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package local.brand.ui;

import javax.swing.JOptionPane;
import local.brand.ui.manager.GiamGiaManagerJDialog;
import local.brand.ui.manager.KhachHangManagerJDialog;
import local.brand.ui.manager.SanPhamManagerJDialog;
import local.brand.ui.LoginJDialog;
import local.brand.ui.ChangePasswordJDialog;
import local.brand.ui.manager.BanHangJDialog;
import local.brand.ui.manager.HoaDonManagerJDialog;
import local.brand.ui.manager.NhanVienManagerJDialog;
import local.brand.ui.manager.PhieuGiamGia;
import local.brand.ui.manager.ThongKeJDialog;
import local.brand.ulti.XAuth;

/**
 *
 * @author ASUS
 */
public class MainJFrame extends javax.swing.JFrame {

    public MainJFrame() {
        initComponents();
        initAuth();
    }

    private void initAuth() {
        if (!XAuth.isLogin()) {
            JOptionPane.showMessageDialog(this, "Vui lòng đăng nhập!");
            this.dispose();
            new LoginJDialog(null, true).setVisible(true);
            return;
        }
        phanQuyen();
    }

    private void phanQuyen() {
        boolean admin = XAuth.isAdmin();

        btnNhanVienMenu.setEnabled(admin);
        btnGiamGiaMenu.setEnabled(admin);
        btnThongKeMenu.setEnabled(admin);

        btnNhanVienCard.setEnabled(admin);
        btnGiamGiaCard.setEnabled(admin);

        // nếu có nút card thống kê thì mở dòng này
        btnThongKeCard.setEnabled(admin);
    }

    private void dangXuat() {
        int chon = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc muốn đăng xuất không?",
                "Xác nhận",
                JOptionPane.YES_NO_OPTION
        );

        if (chon == JOptionPane.YES_OPTION) {
            XAuth.clear();
            this.dispose();
            new LoginJDialog(null, true).setVisible(true);
        }
    }

    private void openSanPhamManager() {
        SanPhamManagerJDialog dialog = new SanPhamManagerJDialog(this, true);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void openPhieuGiamGia() {
        try {
            PhieuGiamGia dialog = new PhieuGiamGia(this, true);
            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Lỗi mở form phiếu giảm giá: " + e.getMessage());
        }
    }

    private void openKhachHangManager() {
        KhachHangManagerJDialog dialog = new KhachHangManagerJDialog(this, true);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void openNhanVienManager() {
        NhanVienManagerJDialog dialog = new NhanVienManagerJDialog(this, true);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void openBanHang() {
        BanHangJDialog dialog = new BanHangJDialog(this, true);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }
    
    
    private void openHoaDonManager() {
        HoaDonManagerJDialog dialog = new HoaDonManagerJDialog(this, true);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlMain = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnBanHangMenu = new javax.swing.JButton();
        btnHoaDonMenu = new javax.swing.JButton();
        btnKhachHangMenu = new javax.swing.JButton();
        btnNhanVienMenu = new javax.swing.JButton();
        btnSanPhamMenu = new javax.swing.JButton();
        btnGiamGiaMenu = new javax.swing.JButton();
        btnThongKeMenu = new javax.swing.JButton();
        btnDoiMatKhauMenu = new javax.swing.JButton();
        btnDangXuatMenu = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        btnBanHangCard = new javax.swing.JButton();
        btnSanPhamCard = new javax.swing.JButton();
        btnBienTheSanPhamCard = new javax.swing.JButton();
        btnNhanVienCard = new javax.swing.JButton();
        btnHoaDonCard = new javax.swing.JButton();
        btnGiamGiaCard = new javax.swing.JButton();
        btnKhachHangCard = new javax.swing.JButton();
        btnThongKeCard = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlMain.setBackground(new java.awt.Color(0, 0, 0));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/local/brand/icons/ChatGPT Image Mar 13, 2026, 12_50_16 PM (1).png"))); // NOI18N
        jLabel1.setText("jLabel1");

        btnBanHangMenu.setBackground(new java.awt.Color(0, 0, 0));
        btnBanHangMenu.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btnBanHangMenu.setForeground(new java.awt.Color(255, 255, 255));
        btnBanHangMenu.setText("Bán hàng");
        btnBanHangMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBanHangMenuActionPerformed(evt);
            }
        });

        btnHoaDonMenu.setBackground(new java.awt.Color(0, 0, 0));
        btnHoaDonMenu.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btnHoaDonMenu.setForeground(new java.awt.Color(255, 255, 255));
        btnHoaDonMenu.setText("Hóa Đơn");
        btnHoaDonMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHoaDonMenuActionPerformed(evt);
            }
        });

        btnKhachHangMenu.setBackground(new java.awt.Color(0, 0, 0));
        btnKhachHangMenu.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btnKhachHangMenu.setForeground(new java.awt.Color(255, 255, 255));
        btnKhachHangMenu.setText("Khách hàng");
        btnKhachHangMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKhachHangMenuActionPerformed(evt);
            }
        });

        btnNhanVienMenu.setBackground(new java.awt.Color(0, 0, 0));
        btnNhanVienMenu.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btnNhanVienMenu.setForeground(new java.awt.Color(255, 255, 255));
        btnNhanVienMenu.setText("Nhân viên");
        btnNhanVienMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNhanVienMenuActionPerformed(evt);
            }
        });

        btnSanPhamMenu.setBackground(new java.awt.Color(0, 0, 0));
        btnSanPhamMenu.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btnSanPhamMenu.setForeground(new java.awt.Color(255, 255, 255));
        btnSanPhamMenu.setText("Sản Phẩm");
        btnSanPhamMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSanPhamMenuActionPerformed(evt);
            }
        });

        btnGiamGiaMenu.setBackground(new java.awt.Color(0, 0, 0));
        btnGiamGiaMenu.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btnGiamGiaMenu.setForeground(new java.awt.Color(255, 255, 255));
        btnGiamGiaMenu.setText("Giảm giá");
        btnGiamGiaMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGiamGiaMenuActionPerformed(evt);
            }
        });

        btnThongKeMenu.setBackground(new java.awt.Color(0, 0, 0));
        btnThongKeMenu.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btnThongKeMenu.setForeground(new java.awt.Color(255, 255, 255));
        btnThongKeMenu.setText("Thống kê");
        btnThongKeMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThongKeMenuActionPerformed(evt);
            }
        });

        btnDoiMatKhauMenu.setBackground(new java.awt.Color(0, 0, 0));
        btnDoiMatKhauMenu.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btnDoiMatKhauMenu.setForeground(new java.awt.Color(255, 255, 255));
        btnDoiMatKhauMenu.setText("Đổi Mk");
        btnDoiMatKhauMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDoiMatKhauMenuActionPerformed(evt);
            }
        });

        btnDangXuatMenu.setBackground(new java.awt.Color(0, 0, 0));
        btnDangXuatMenu.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btnDangXuatMenu.setForeground(new java.awt.Color(255, 255, 255));
        btnDangXuatMenu.setText("Đăng xuất");
        btnDangXuatMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDangXuatMenuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlMainLayout = new javax.swing.GroupLayout(pnlMain);
        pnlMain.setLayout(pnlMainLayout);
        pnlMainLayout.setHorizontalGroup(
            pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMainLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(pnlMainLayout.createSequentialGroup()
                        .addGroup(pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnNhanVienMenu)
                            .addComponent(btnThongKeMenu)
                            .addComponent(btnGiamGiaMenu)
                            .addComponent(btnBanHangMenu)
                            .addComponent(btnHoaDonMenu)
                            .addComponent(btnSanPhamMenu)
                            .addComponent(btnKhachHangMenu)
                            .addComponent(btnDoiMatKhauMenu)
                            .addComponent(btnDangXuatMenu))
                        .addGap(0, 25, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pnlMainLayout.setVerticalGroup(
            pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMainLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBanHangMenu)
                .addGap(31, 31, 31)
                .addComponent(btnHoaDonMenu)
                .addGap(34, 34, 34)
                .addComponent(btnSanPhamMenu)
                .addGap(34, 34, 34)
                .addComponent(btnKhachHangMenu)
                .addGap(34, 34, 34)
                .addComponent(btnNhanVienMenu)
                .addGap(32, 32, 32)
                .addComponent(btnGiamGiaMenu)
                .addGap(27, 27, 27)
                .addComponent(btnThongKeMenu)
                .addGap(27, 27, 27)
                .addComponent(btnDoiMatKhauMenu)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addComponent(btnDangXuatMenu)
                .addGap(21, 21, 21))
        );

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/local/brand/icons/localbrand_banner_vua_khung.png"))); // NOI18N
        jLabel2.setMaximumSize(new java.awt.Dimension(857, 857));
        jLabel2.setMinimumSize(new java.awt.Dimension(313, 313));

        btnBanHangCard.setText("BÁN HÀNG");
        btnBanHangCard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBanHangCardActionPerformed(evt);
            }
        });

        btnSanPhamCard.setText("SẢN PHẨM");
        btnSanPhamCard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSanPhamCardActionPerformed(evt);
            }
        });

        btnBienTheSanPhamCard.setText("BIẾN THỂ SẢN PHẨM");

        btnNhanVienCard.setText("NHÂN VIÊN");
        btnNhanVienCard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNhanVienCardActionPerformed(evt);
            }
        });

        btnHoaDonCard.setText("HÓA ĐƠN");
        btnHoaDonCard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHoaDonCardActionPerformed(evt);
            }
        });

        btnGiamGiaCard.setText("GIẢM GIÁ");
        btnGiamGiaCard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGiamGiaCardActionPerformed(evt);
            }
        });

        btnKhachHangCard.setText("KHÁCH HÀNG");
        btnKhachHangCard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKhachHangCardActionPerformed(evt);
            }
        });

        btnThongKeCard.setText("THỐNG KÊ");
        btnThongKeCard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThongKeCardActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlMain, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnBanHangCard, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnNhanVienCard, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(94, 94, 94)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnSanPhamCard, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnHoaDonCard, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btnBienTheSanPhamCard, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(49, 49, 49))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btnGiamGiaCard, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(59, 59, 59)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnKhachHangCard, javax.swing.GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE)
                            .addComponent(btnThongKeCard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(28, 28, 28))
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 864, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMain, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBanHangCard, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSanPhamCard, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBienTheSanPhamCard, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnKhachHangCard, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnNhanVienCard, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnHoaDonCard, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnGiamGiaCard, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(btnThongKeCard, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnKhachHangCardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKhachHangCardActionPerformed
        openKhachHangManager();
    }//GEN-LAST:event_btnKhachHangCardActionPerformed

    private void btnSanPhamCardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSanPhamCardActionPerformed
        openSanPhamManager();
    }//GEN-LAST:event_btnSanPhamCardActionPerformed

    private void btnSanPhamMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSanPhamMenuActionPerformed
        openSanPhamManager();
    }//GEN-LAST:event_btnSanPhamMenuActionPerformed

    private void btnGiamGiaCardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGiamGiaCardActionPerformed
        openPhieuGiamGia();
    }//GEN-LAST:event_btnGiamGiaCardActionPerformed

    private void btnGiamGiaMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGiamGiaMenuActionPerformed
        openPhieuGiamGia();
    }//GEN-LAST:event_btnGiamGiaMenuActionPerformed

    private void btnKhachHangMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKhachHangMenuActionPerformed

        openKhachHangManager();
    }//GEN-LAST:event_btnKhachHangMenuActionPerformed

    private void btnDoiMatKhauMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDoiMatKhauMenuActionPerformed

        ChangePasswordJDialog dialog = new ChangePasswordJDialog(this, true);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }//GEN-LAST:event_btnDoiMatKhauMenuActionPerformed

    private void btnDangXuatMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDangXuatMenuActionPerformed

        dangXuat();
    }//GEN-LAST:event_btnDangXuatMenuActionPerformed

    private void btnNhanVienCardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNhanVienCardActionPerformed
        openNhanVienManager();
    }//GEN-LAST:event_btnNhanVienCardActionPerformed

    private void btnNhanVienMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNhanVienMenuActionPerformed
        openNhanVienManager();
    }//GEN-LAST:event_btnNhanVienMenuActionPerformed

    private void btnBanHangCardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBanHangCardActionPerformed
        openBanHang();
    }//GEN-LAST:event_btnBanHangCardActionPerformed

    private void btnBanHangMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBanHangMenuActionPerformed
        openBanHang();
    }//GEN-LAST:event_btnBanHangMenuActionPerformed

    private void btnHoaDonCardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHoaDonCardActionPerformed
        openHoaDonManager();
    }//GEN-LAST:event_btnHoaDonCardActionPerformed

    private void btnHoaDonMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHoaDonMenuActionPerformed
        openHoaDonManager();
    }//GEN-LAST:event_btnHoaDonMenuActionPerformed

    private void btnThongKeCardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThongKeCardActionPerformed
        openThongKe();
    }//GEN-LAST:event_btnThongKeCardActionPerformed

    private void btnThongKeMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThongKeMenuActionPerformed
         openThongKe();
    }//GEN-LAST:event_btnThongKeMenuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBanHangCard;
    private javax.swing.JButton btnBanHangMenu;
    private javax.swing.JButton btnBienTheSanPhamCard;
    private javax.swing.JButton btnDangXuatMenu;
    private javax.swing.JButton btnDoiMatKhauMenu;
    private javax.swing.JButton btnGiamGiaCard;
    private javax.swing.JButton btnGiamGiaMenu;
    private javax.swing.JButton btnHoaDonCard;
    private javax.swing.JButton btnHoaDonMenu;
    private javax.swing.JButton btnKhachHangCard;
    private javax.swing.JButton btnKhachHangMenu;
    private javax.swing.JButton btnNhanVienCard;
    private javax.swing.JButton btnNhanVienMenu;
    private javax.swing.JButton btnSanPhamCard;
    private javax.swing.JButton btnSanPhamMenu;
    private javax.swing.JButton btnThongKeCard;
    private javax.swing.JButton btnThongKeMenu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel pnlMain;
    // End of variables declaration//GEN-END:variables

    private void openThongKe() {
        // Kiểm tra quyền admin một lần nữa cho chắc chắn nếu cần
        if (!XAuth.isAdmin()) {
            JOptionPane.showMessageDialog(this, "Bạn không có quyền xem thống kê!");
            return;
        }

        try {
            ThongKeJDialog dialog = new ThongKeJDialog(this, true);
            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi mở form thống kê: " + e.getMessage());
        }
    }
}
