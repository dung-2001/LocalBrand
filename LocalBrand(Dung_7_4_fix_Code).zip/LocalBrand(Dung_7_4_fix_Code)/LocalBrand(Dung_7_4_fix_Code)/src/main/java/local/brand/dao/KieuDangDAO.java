/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package local.brand.dao;

import java.util.List;
import local.brand.entity.KieuDang;

/**
 *
 * @author ASUS
 */
public interface KieuDangDAO {
    List<KieuDang> selectAll();
    KieuDang selectById(Integer id);
    
}
