/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.entity;

import java.math.BigDecimal;

/**
 *
 * @author ASUS
 */
public class SanPhamChiTiet {
    private int id;
    private int idSanPham;
    private int idMauSac;
    private int idKichThuoc;
    private String maSpChiTiet;
    private int soLuong;
    private BigDecimal donGia;
    private int trangThai;

    public SanPhamChiTiet() {
    }

    public SanPhamChiTiet(int id, int idSanPham, int idMauSac, int idKichThuoc, String maSpChiTiet, int soLuong, BigDecimal donGia, int trangThai) {
        this.id = id;
        this.idSanPham = idSanPham;
        this.idMauSac = idMauSac;
        this.idKichThuoc = idKichThuoc;
        this.maSpChiTiet = maSpChiTiet;
        this.soLuong = soLuong;
        this.donGia = donGia;
        this.trangThai = trangThai;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdSanPham() {
        return idSanPham;
    }

    public void setIdSanPham(int idSanPham) {
        this.idSanPham = idSanPham;
    }

    public int getIdMauSac() {
        return idMauSac;
    }

    public void setIdMauSac(int idMauSac) {
        this.idMauSac = idMauSac;
    }

    public int getIdKichThuoc() {
        return idKichThuoc;
    }

    public void setIdKichThuoc(int idKichThuoc) {
        this.idKichThuoc = idKichThuoc;
    }

    public String getMaSpChiTiet() {
        return maSpChiTiet;
    }

    public void setMaSpChiTiet(String maSpChiTiet) {
        this.maSpChiTiet = maSpChiTiet;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public BigDecimal getDonGia() {
        return donGia;
    }

    public void setDonGia(BigDecimal donGia) {
        this.donGia = donGia;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    public Object getMau() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
