/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.dao.impl;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import local.brand.dao.ThongKeChiTietDAO;
import local.brand.ulti.XJdbc;

/**
 *
 * @author CAU DIEN
 */
public class ThongKeChiTietDAOImpl implements ThongKeChiTietDAO{
     @Override
    public List<Object[]> getThongKeChiTiet(Date tuNgay, Date denNgay) {
        // Ép kiểu sang java.sql.Date để SQL Server so sánh chuẩn xác (bỏ qua giờ phút giây)
        java.sql.Date sqlTuNgay = new java.sql.Date(tuNgay.getTime());
        java.sql.Date sqlDenNgay = new java.sql.Date(denNgay.getTime());

        String sql = "SELECT " +
                     "CONVERT(VARCHAR, thoi_gian_mua, 103) AS Ngay, " +
                     "COUNT(id) AS SoDon, " +
                     "SUM(CASE WHEN id_hinh_thuc = 1 THEN thanh_tien ELSE 0 END) AS TienMat, " +
                     "SUM(CASE WHEN id_hinh_thuc = 2 THEN thanh_tien ELSE 0 END) AS ChuyenKhoan " +
                     "FROM hoa_don " +
                     "WHERE trang_thai = 1 AND CAST(thoi_gian_mua AS DATE) BETWEEN ? AND ? " +
                     "GROUP BY CAST(thoi_gian_mua AS DATE), CONVERT(VARCHAR, thoi_gian_mua, 103) " +
                     "ORDER BY CAST(thoi_gian_mua AS DATE) DESC";
        
        String[] cols = {"Ngay", "SoDon", "TienMat", "ChuyenKhoan"};
        return this.getListOfArray(sql, cols, sqlTuNgay, sqlDenNgay);
    }

    @Override
    public List<Object[]> getThongKeTheoThang(Date date) {
        java.sql.Date sqlDate = new java.sql.Date(date.getTime());
        
        String sql = "SELECT " +
                     "CONVERT(VARCHAR, thoi_gian_mua, 103) AS Ngay, " +
                     "COUNT(id) AS SoDon, " +
                     "SUM(CASE WHEN id_hinh_thuc = 1 THEN thanh_tien ELSE 0 END) AS TienMat, " +
                     "SUM(CASE WHEN id_hinh_thuc = 2 THEN thanh_tien ELSE 0 END) AS ChuyenKhoan " +
                     "FROM hoa_don " +
                     "WHERE trang_thai = 1 AND MONTH(thoi_gian_mua) = MONTH(?) AND YEAR(thoi_gian_mua) = YEAR(?) " +
                     "GROUP BY CAST(thoi_gian_mua AS DATE), CONVERT(VARCHAR, thoi_gian_mua, 103) " +
                     "ORDER BY CAST(thoi_gian_mua AS DATE) ASC";
        
        String[] cols = {"Ngay", "SoDon", "TienMat", "ChuyenKhoan"};
        return this.getListOfArray(sql, cols, sqlDate, sqlDate);
    }

    @Override
    public List<Object[]> getThongKeTheoNam(Date date) {
        java.sql.Date sqlDate = new java.sql.Date(date.getTime());

        String sql = "SELECT " +
                     "MONTH(thoi_gian_mua) AS Thang, " +
                     "COUNT(id) AS SoDon, " +
                     "SUM(CASE WHEN id_hinh_thuc = 1 THEN thanh_tien ELSE 0 END) AS TienMat, " +
                     "SUM(CASE WHEN id_hinh_thuc = 2 THEN thanh_tien ELSE 0 END) AS ChuyenKhoan " +
                     "FROM hoa_don " +
                     "WHERE trang_thai = 1 AND YEAR(thoi_gian_mua) = YEAR(?) " +
                     "GROUP BY MONTH(thoi_gian_mua) " +
                     "ORDER BY Thang ASC";
        
        String[] cols = {"Thang", "SoDon", "TienMat", "ChuyenKhoan"};
        return this.getListOfArray(sql, cols, sqlDate);
    }

    @Override
    public List<Object[]> getDoanhThuTheoNam(int nam) {
        String sql = "SELECT " +
                     "MONTH(thoi_gian_mua) AS Thang, " +
                     "COUNT(id) AS SoDon, " +
                     "SUM(CASE WHEN id_hinh_thuc = 1 THEN thanh_tien ELSE 0 END) AS TienMat, " +
                     "SUM(CASE WHEN id_hinh_thuc = 2 THEN thanh_tien ELSE 0 END) AS ChuyenKhoan " +
                     "FROM hoa_don " +
                     "WHERE trang_thai = 1 AND YEAR(thoi_gian_mua) = ? " +
                     "GROUP BY MONTH(thoi_gian_mua) " +
                     "ORDER BY Thang ASC";
        
        String[] cols = {"Thang", "SoDon", "TienMat", "ChuyenKhoan"};
        return this.getListOfArray(sql, cols, nam);
    }

    @Override
    public List<Object[]> getDoanhThuTheoKhoangNgay(Date tuNgay, Date denNgay) {
        java.sql.Date sqlTu = new java.sql.Date(tuNgay.getTime());
        java.sql.Date sqlDen = new java.sql.Date(denNgay.getTime());
        
        String sql = "SELECT " +
                     "CONVERT(VARCHAR, thoi_gian_mua, 103) AS Ngay, " +
                     "COUNT(id) AS SoDon, " +
                     "SUM(CASE WHEN id_hinh_thuc = 1 THEN thanh_tien ELSE 0 END) AS TienMat, " +
                     "SUM(CASE WHEN id_hinh_thuc = 2 THEN thanh_tien ELSE 0 END) AS ChuyenKhoan " +
                     "FROM hoa_don " +
                     "WHERE trang_thai = 1 AND CAST(thoi_gian_mua AS DATE) BETWEEN ? AND ? " +
                     "GROUP BY CAST(thoi_gian_mua AS DATE), CONVERT(VARCHAR, thoi_gian_mua, 103) " +
                     "ORDER BY CAST(thoi_gian_mua AS DATE) ASC";
        
        String[] cols = {"Ngay", "SoDon", "TienMat", "ChuyenKhoan"};
        return this.getListOfArray(sql, cols, sqlTu, sqlDen);
    }

    @Override
    public List<Object[]> getDoanhThuCacNgayTrongThang(int thang, int nam) {
        String sql = "SELECT " +
                     "CONVERT(VARCHAR, thoi_gian_mua, 103) AS Ngay, " +
                     "COUNT(id) AS SoDon, " +
                     "SUM(CASE WHEN id_hinh_thuc = 1 THEN thanh_tien ELSE 0 END) AS TienMat, " +
                     "SUM(CASE WHEN id_hinh_thuc = 2 THEN thanh_tien ELSE 0 END) AS ChuyenKhoan " +
                     "FROM hoa_don " +
                     "WHERE trang_thai = 1 AND MONTH(thoi_gian_mua) = ? AND YEAR(thoi_gian_mua) = ? " +
                     "GROUP BY CAST(thoi_gian_mua AS DATE), CONVERT(VARCHAR, thoi_gian_mua, 103) " +
                     "ORDER BY CAST(thoi_gian_mua AS DATE) ASC";
        
        String[] cols = {"Ngay", "SoDon", "TienMat", "ChuyenKhoan"};
        return this.getListOfArray(sql, cols, thang, nam);
    }

    /**
     * Hàm dùng chung để thực thi truy vấn và đổ dữ liệu vào danh sách mảng đối tượng
     */
    private List<Object[]> getListOfArray(String sql, String[] cols, Object... args) {
        List<Object[]> list = new ArrayList<>();
        try (ResultSet rs = XJdbc.query(sql, args)) {
            while (rs.next()) {
                Object[] vals = new Object[cols.length];
                for (int i = 0; i < cols.length; i++) {
                    vals[i] = rs.getObject(cols[i]);
                }
                list.add(vals);
            }
            // Giải phóng kết nối ngay sau khi ResultSet đóng (try-with-resources tự đóng rs)
            if (rs.getStatement() != null && rs.getStatement().getConnection() != null) {
                rs.getStatement().getConnection().close();
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Lỗi truy vấn thống kê: " + e.getMessage());
        }
        return list;
    }
}
