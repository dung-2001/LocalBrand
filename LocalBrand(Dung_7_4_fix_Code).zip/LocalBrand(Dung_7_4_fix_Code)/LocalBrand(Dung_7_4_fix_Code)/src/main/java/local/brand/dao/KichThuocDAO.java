/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package local.brand.dao;

import java.util.List;
import local.brand.entity.KichThuoc;

/**
 *
 * @author CAU DIEN
 */
public interface KichThuocDAO {
    List<KichThuoc> selectAll();
    KichThuoc selectById(int id);
    void insert(KichThuoc kt);
    void update(KichThuoc kt);
    void delete (int id);
}
