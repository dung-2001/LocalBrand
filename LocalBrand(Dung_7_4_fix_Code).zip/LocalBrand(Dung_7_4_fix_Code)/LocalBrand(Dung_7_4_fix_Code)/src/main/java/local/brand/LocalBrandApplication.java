/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand;

import local.brand.ui.LoginJDialog;

/**
 *
 * @author ASUS
 */
public class LocalBrandApplication {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                LoginJDialog login = new LoginJDialog(new javax.swing.JFrame(), true);
                login.setLocationRelativeTo(null);
                login.setVisible(true);
            }
        });
    }
}
