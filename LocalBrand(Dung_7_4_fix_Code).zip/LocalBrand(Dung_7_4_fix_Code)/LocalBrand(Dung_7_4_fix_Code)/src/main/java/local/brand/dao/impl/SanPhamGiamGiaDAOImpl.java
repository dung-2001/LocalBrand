/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.dao.impl;

import java.util.List;
import local.brand.dao.SanPhamGiamGiaDAO;
import local.brand.entity.SanPhamGiamGia;
import local.brand.ulti.XJdbc;

/**
 *
 * @author ASUS
 */
public class SanPhamGiamGiaDAOImpl implements SanPhamGiamGiaDAO {
    private static final String SELECT_BASE = """
        SELECT
            spgg.id AS id,
            spgg.id_dot_giam_gia AS idDotGiamGia,
            spgg.id_san_pham_chi_tiet AS idSanPhamChiTiet,
            spgg.gia_sau_giam AS giaSauGiam,
            spgg.trang_thai AS trangThai,
            spct.ma_sp_chi_tiet AS maSpChiTiet,
            sp.ten_san_pham AS tenSanPham,
            ms.ten_mau AS tenMau,
            kt.ten_kich_thuoc AS tenKichThuoc,
            spct.don_gia AS donGiaGoc,
            spct.so_luong AS soLuongTon
        FROM san_pham_giam_gia spgg
        JOIN san_pham_chi_tiet spct ON spct.id = spgg.id_san_pham_chi_tiet
        JOIN san_pham sp ON sp.id = spct.id_san_pham
        JOIN mau_sac ms ON ms.id = spct.id_mau_sac
        JOIN kich_thuoc kt ON kt.id = spct.id_kich_thuoc
        """;

    private static final String INSERT_SQL = """
        INSERT INTO san_pham_giam_gia (
            id_dot_giam_gia, id_san_pham_chi_tiet, gia_sau_giam, trang_thai
        )
        VALUES (?, ?, ?, ?)
        """;

    private static final String UPDATE_SQL = """
        UPDATE san_pham_giam_gia
        SET gia_sau_giam = ?, trang_thai = ?
        WHERE id = ?
        """;

    private static final String DELETE_SQL = """
        DELETE FROM san_pham_giam_gia
        WHERE id_dot_giam_gia = ? AND id_san_pham_chi_tiet = ?
        """;

    @Override
    public void insert(SanPhamGiamGia entity) {
         XJdbc.executeUpdate(
                INSERT_SQL,
                entity.getIdDotGiamGia(),
                entity.getIdSanPhamChiTiet(),
                entity.getGiaSauGiam(),
                entity.getTrangThai()
        );
    }

    @Override
    public void update(SanPhamGiamGia entity) {
        XJdbc.executeUpdate(
                UPDATE_SQL,
                entity.getGiaSauGiam(),
                entity.getTrangThai(),
                entity.getId()
        );
    }

    @Override
    public void deleteByDotAndSanPhamChiTiet(int idDotGiamGia, int idSanPhamChiTiet) {
        XJdbc.executeUpdate(DELETE_SQL, idDotGiamGia, idSanPhamChiTiet);
    }

    @Override
    public SanPhamGiamGia selectByDotAndSanPhamChiTiet(int idDotGiamGia, int idSanPhamChiTiet) {
        String sql = SELECT_BASE + """
            WHERE spgg.id_dot_giam_gia = ? AND spgg.id_san_pham_chi_tiet = ?
            """;
        return XJdbc.getSingleBean(SanPhamGiamGia.class, sql, idDotGiamGia, idSanPhamChiTiet);
    }

    @Override
    public List<SanPhamGiamGia> selectByDotGiamGiaId(int idDotGiamGia) {
         String sql = SELECT_BASE + """
            WHERE spgg.id_dot_giam_gia = ?
            ORDER BY spgg.id DESC
            """;
        return XJdbc.getBeanList(SanPhamGiamGia.class, sql, idDotGiamGia);
    }
    }

    

