/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package local.brand.ui.manager;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import local.brand.dao.PhieuGiamGiaDAO;
import local.brand.dao.impl.PhieuGiamGiaDAOImpl;
import local.brand.entity.PhieuGG;

/**
 *
 * @author ASUS
 */
public class PhieuGiamGia extends javax.swing.JDialog {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PhieuGiamGia.class.getName());
    PhieuGiamGiaDAO dao = new PhieuGiamGiaDAOImpl();
    DefaultTableModel model;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    NumberFormat vnd = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));

    public PhieuGiamGia(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();

        rdoDang.addActionListener(e -> {
            if (rdoDang.isSelected()) {
                rdoHet.setSelected(false);
            }
        });

        rdoHet.addActionListener(e -> {
            if (rdoHet.isSelected()) {
                rdoDang.setSelected(false);
            }
        });
        tblPhieuGiamGia.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "Mã", "Tên", "Loại", "Ngày BĐ", "Ngày KT",
                    "Gia trị giảm", "Giam tối đa", "Số lượng",
                    "Số lượng dùng", "Trạng thái"
                }
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        });
        model = (DefaultTableModel) tblPhieuGiamGia.getModel();
        loadTable();
        txtTimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent e) {
                String key = txtTimKiem.getText();
                loadTableSearch(key);
            }
        });
    }

    void loadTable() {
        model.setRowCount(0);
        ArrayList<PhieuGG> list = dao.getAll();
        for (PhieuGG p : list) {
            model.addRow(new Object[]{
                p.getMa(),
                p.getTen(),
                p.getLoai(),
                p.getNgayBatDau(),
                p.getNgayKetThuc(),
                vnd.format(p.getGiaTriGiam()),
                vnd.format(p.getGiamGiaToiDa()),
                p.getSoLuong(),
                p.getSoLuongDaDung(),
                p.isTrangThai() ? "Đang diễn ra" : "Hết hạn"
            });
        }
    }

    void loadTableSearch(String keyword) {
        model.setRowCount(0);

        ArrayList<PhieuGG> list = dao.search(keyword);

        for (PhieuGG p : list) {
            model.addRow(new Object[]{
                p.getMa(),
                p.getTen(),
                p.getLoai(),
                p.getNgayBatDau(),
                p.getNgayKetThuc(),
                vnd.format(p.getGiaTriGiam()),
                vnd.format(p.getGiamGiaToiDa()),
                p.getSoLuong(),
                p.getSoLuongDaDung(),
                p.isTrangThai() ? "Đang diễn ra" : "Hết hạn"
            });
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        btnDotGiamGia = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtMa = new javax.swing.JTextField();
        txtTen = new javax.swing.JTextField();
        txtLoai = new javax.swing.JTextField();
        txtNgayBD = new javax.swing.JTextField();
        txtNgayKT = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtDieuKien = new javax.swing.JTextField();
        txtGiaTri = new javax.swing.JTextField();
        txtGiamToiDa = new javax.swing.JTextField();
        txtSoLuong = new javax.swing.JTextField();
        txtSLDaDung = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        rdoDang = new javax.swing.JRadioButton();
        rdoHet = new javax.swing.JRadioButton();
        jLabel14 = new javax.swing.JLabel();
        txtLoc = new javax.swing.JTextField();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        btnLamMoi = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPhieuGiamGia = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel1.setText("QUẢN LÝ PHIẾU GIẢM GIÁ");

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel2.setText("Tìm kiếm");

        btnDotGiamGia.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        btnDotGiamGia.setText("ĐỢT GIẢM GIÁ");
        btnDotGiamGia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDotGiamGiaActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel3.setText("Mã phiếu");

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel4.setText("Tên phiếu");

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel5.setText("Loại phiếu");

        jLabel6.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel6.setText("Ngày bắt đầu");

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel7.setText("Ngày kết thúc");

        txtTen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTenActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel8.setText("Điều kiện");

        jLabel9.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel9.setText("Gia trị giảm");

        jLabel10.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel10.setText("Giam tối đa");

        jLabel11.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel11.setText("Số lượng");

        jLabel12.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel12.setText("Số lượng đã dùng");

        txtDieuKien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDieuKienActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel13.setText("Trạng thái");

        rdoDang.setText("Đang diễn ra");

        rdoHet.setText("Hết hạn");
        rdoHet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdoHetActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel14.setText("Lọc");

        btnThem.setText("THÊM");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setText("SỬA");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnXoa.setText("XÓA");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        btnLamMoi.setText("LÀM MỚI");
        btnLamMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiActionPerformed(evt);
            }
        });

        tblPhieuGiamGia.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã", "Tên", "Loại", "Ngày BĐ", "Ngày KT", "Gia trị giảm", "Giam tối đa", "Số lượng", "Số lượng dùng", "Trạng thái"
            }
        ));
        tblPhieuGiamGia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPhieuGiamGiaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblPhieuGiamGia);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(txtTen, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(26, 26, 26)
                                            .addComponent(txtLoai, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(txtMa, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtNgayBD, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtNgayKT, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel8))
                                        .addGap(0, 0, Short.MAX_VALUE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtDieuKien, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtGiamToiDa, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtSoLuong, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtSLDaDung, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtGiaTri, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(117, 117, 117))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addComponent(jLabel1)
                                .addGap(32, 32, 32)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(35, 35, 35)
                                .addComponent(btnDotGiamGia))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addGap(18, 18, 18)
                                .addComponent(rdoDang)
                                .addGap(18, 18, 18)
                                .addComponent(rdoHet)
                                .addGap(68, 68, 68)
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtLoc, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(btnThem)
                        .addGap(88, 88, 88)
                        .addComponent(btnSua)
                        .addGap(74, 74, 74)
                        .addComponent(btnXoa)
                        .addGap(81, 81, 81)
                        .addComponent(btnLamMoi))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 767, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 24, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDotGiamGia))
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtMa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(txtDieuKien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(txtGiaTri, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtLoai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(txtGiamToiDa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtNgayBD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtNgayKT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(txtSLDaDung, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(rdoDang)
                    .addComponent(rdoHet)
                    .addComponent(jLabel14)
                    .addComponent(txtLoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThem)
                    .addComponent(btnSua)
                    .addComponent(btnXoa)
                    .addComponent(btnLamMoi))
                .addGap(40, 40, 40)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(50, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtTenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTenActionPerformed

    }//GEN-LAST:event_txtTenActionPerformed

    private void txtDieuKienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDieuKienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDieuKienActionPerformed

    private void rdoHetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdoHetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdoHetActionPerformed

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        
        try {
            // ===== CHECK TRỐNG =====
            if (txtMa.getText().trim().isEmpty()
                    || txtTen.getText().trim().isEmpty()
                    || txtLoai.getText().trim().isEmpty()
                    || txtNgayBD.getText().trim().isEmpty()
                    || txtNgayKT.getText().trim().isEmpty()
                    || txtDieuKien.getText().trim().isEmpty()
                    || txtGiaTri.getText().trim().isEmpty()
                    || txtGiamToiDa.getText().trim().isEmpty()
                    || txtSoLuong.getText().trim().isEmpty()
                    || txtSLDaDung.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(this, "Không được để trống");
                return;
            }

            // ===== RADIO =====
            if (rdoDang.isSelected() && rdoHet.isSelected()) {
                JOptionPane.showMessageDialog(this, "Chỉ chọn 1 trạng thái");
                return;
            }

            if (!rdoDang.isSelected() && !rdoHet.isSelected()) {
                JOptionPane.showMessageDialog(this, "Phải chọn trạng thái");
                return;
            }

            // ===== TRÙNG =====
            if (dao.checkTrungMa(txtMa.getText())) {
                JOptionPane.showMessageDialog(this, "Trùng mã");
                return;
            }

            if (dao.checkTrungTen(txtTen.getText())) {
                JOptionPane.showMessageDialog(this, "Trùng tên");
                return;
            }

            // ===== PARSE =====
            double dieuKien = Double.parseDouble(txtDieuKien.getText());
            double giaTri = Double.parseDouble(txtGiaTri.getText());
            double giamMax = Double.parseDouble(txtGiamToiDa.getText());
            int soLuong = Integer.parseInt(txtSoLuong.getText());
            int daDung = Integer.parseInt(txtSLDaDung.getText());

            if (dieuKien < 0 || giaTri <= 0 || giamMax < 0) {
                JOptionPane.showMessageDialog(this, "Giá trị không hợp lệ");
                return;
            }

            if (daDung > soLuong) {
                JOptionPane.showMessageDialog(this, "SL đã dùng > SL");
                return;
            }

            java.util.Date bd = sdf.parse(txtNgayBD.getText());
            java.util.Date kt = sdf.parse(txtNgayKT.getText());

            if (bd.after(kt)) {
                JOptionPane.showMessageDialog(this, "Ngày không hợp lệ");
                return;
            }

            // ===== SET ENTITY =====
            PhieuGG p = new PhieuGG();
            p.setMa(txtMa.getText());
            p.setTen(txtTen.getText());
            p.setLoai(txtLoai.getText());
            p.setNgayBatDau(bd);
            p.setNgayKetThuc(kt);
            p.setDieuKien(dieuKien);
            p.setGiaTriGiam(giaTri);
            p.setGiamGiaToiDa(giamMax);
            p.setSoLuong(soLuong);
            p.setSoLuongDaDung(daDung);
            p.setTrangThai(rdoDang.isSelected());

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Bạn có chắc muốn thêm không?",
                    "Xác nhận",
                    JOptionPane.YES_NO_OPTION);

            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            // ===== INSERT =====
            if (dao.insert(p) > 0) {
                JOptionPane.showMessageDialog(this, "Thêm thành công");
                loadTable();
            } else {
                JOptionPane.showMessageDialog(this, "Thêm thất bại");
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Sai định dạng số");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
        }
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        // TODO add your handling code here:
        try {
            int row = tblPhieuGiamGia.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Chọn dòng để sửa");
                return;
            }

            // ===== CHECK TRỐNG =====
            if (txtMa.getText().trim().isEmpty()
                    || txtTen.getText().trim().isEmpty()
                    || txtLoai.getText().trim().isEmpty()
                    || txtNgayBD.getText().trim().isEmpty()
                    || txtNgayKT.getText().trim().isEmpty()
                    || txtDieuKien.getText().trim().isEmpty()
                    || txtGiaTri.getText().trim().isEmpty()
                    || txtGiamToiDa.getText().trim().isEmpty()
                    || txtSoLuong.getText().trim().isEmpty()
                    || txtSLDaDung.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(this, "Không được để trống");
                return;
            }

            // ===== RADIO =====
            if (rdoDang.isSelected() && rdoHet.isSelected()) {
                JOptionPane.showMessageDialog(this, "Chỉ chọn 1 trạng thái");
                return;
            }

            if (!rdoDang.isSelected() && !rdoHet.isSelected()) {
                JOptionPane.showMessageDialog(this, "Phải chọn trạng thái");
                return;
            }

            // ===== CHECK TRÙNG TÊN (TRỪ CHÍNH NÓ) =====
            String maCu = model.getValueAt(row, 0).toString();
            if (!txtMa.getText().equals(maCu) && dao.checkTrungMa(txtMa.getText())) {
                JOptionPane.showMessageDialog(this, "Trùng mã");
                return;
            }

            if (dao.checkTrungTen(txtTen.getText())) {
                JOptionPane.showMessageDialog(this, "Trùng tên");
                return;
            }

            // ===== PARSE =====
            double dieuKien = Double.parseDouble(txtDieuKien.getText());
            double giaTri = Double.parseDouble(txtGiaTri.getText());
            double giamMax = Double.parseDouble(txtGiamToiDa.getText());
            int soLuong = Integer.parseInt(txtSoLuong.getText());
            int daDung = Integer.parseInt(txtSLDaDung.getText());

            if (dieuKien < 0 || giaTri <= 0 || giamMax < 0) {
                JOptionPane.showMessageDialog(this, "Giá trị không hợp lệ");
                return;
            }

            if (daDung > soLuong) {
                JOptionPane.showMessageDialog(this, "SL đã dùng > SL");
                return;
            }

            java.util.Date bd = sdf.parse(txtNgayBD.getText());
            java.util.Date kt = sdf.parse(txtNgayKT.getText());

            if (bd.after(kt)) {
                JOptionPane.showMessageDialog(this, "Ngày không hợp lệ");
                return;
            }

            // ===== SET ENTITY =====
            PhieuGG p = new PhieuGG();
            p.setMa(txtMa.getText());
            p.setTen(txtTen.getText());
            p.setLoai(txtLoai.getText());
            p.setNgayBatDau(bd);
            p.setNgayKetThuc(kt);
            p.setDieuKien(dieuKien);
            p.setGiaTriGiam(giaTri);
            p.setGiamGiaToiDa(giamMax);
            p.setSoLuong(soLuong);
            p.setSoLuongDaDung(daDung);
            p.setTrangThai(rdoDang.isSelected());

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Bạn có chắc muốn sửa không?",
                    "Xác nhận",
                    JOptionPane.YES_NO_OPTION);

            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            // ===== UPDATE =====
            if (dao.update(p) > 0) {
                JOptionPane.showMessageDialog(this, "Sửa thành công");
                loadTable();
            } else {
                JOptionPane.showMessageDialog(this, "Sửa thất bại");
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Sai định dạng số");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
        }
    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        // TODO add your handling code here:
        int row = tblPhieuGiamGia.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Chọn dòng cần xoá");
            return;
        }

        String ma = tblPhieuGiamGia.getValueAt(row, 0).toString();

        int confirm = JOptionPane.showConfirmDialog(this, "Xoá?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (dao.delete(ma) > 0) {
                JOptionPane.showMessageDialog(this, "Xoá thành công");
                loadTable();
            }
        }
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnLamMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiActionPerformed
        // TODO add your handling code here:
        txtMa.setText("");
        txtTen.setText("");
        txtLoai.setText("");
        txtNgayBD.setText("");
        txtNgayKT.setText("");
        txtDieuKien.setText("");
        txtGiaTri.setText("");
        txtGiamToiDa.setText("");
        txtSoLuong.setText("");
        txtSLDaDung.setText("");
        rdoDang.setSelected(false);
        rdoHet.setSelected(false);
    }//GEN-LAST:event_btnLamMoiActionPerformed

    private void tblPhieuGiamGiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPhieuGiamGiaMouseClicked
        int row = tblPhieuGiamGia.getSelectedRow();
        if (row == -1) {
            return;
        }

        String ma = String.valueOf(tblPhieuGiamGia.getValueAt(row, 0));
        PhieuGG p = dao.findById(ma);

        if (p != null) {
            txtMa.setText(p.getMa());
            txtTen.setText(p.getTen());
            txtLoai.setText(p.getLoai());
            txtNgayBD.setText(sdf.format(p.getNgayBatDau()));
            txtNgayKT.setText(sdf.format(p.getNgayKetThuc()));
            txtDieuKien.setText(String.valueOf(p.getDieuKien()));
            txtGiaTri.setText(String.valueOf(p.getGiaTriGiam()));
            txtGiamToiDa.setText(String.valueOf(p.getGiamGiaToiDa()));
            txtSoLuong.setText(String.valueOf(p.getSoLuong()));
            txtSLDaDung.setText(String.valueOf(p.getSoLuongDaDung()));
            rdoDang.setSelected(p.isTrangThai());
            rdoHet.setSelected(!p.isTrangThai());
        }
    }//GEN-LAST:event_tblPhieuGiamGiaMouseClicked

    private void btnDotGiamGiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDotGiamGiaActionPerformed
        GiamGiaManagerJDialog dialog = new GiamGiaManagerJDialog(this, true);
        dialog.setVisible(true);
        loadTable();
    }//GEN-LAST:event_btnDotGiamGiaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PhieuGiamGia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PhieuGiamGia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PhieuGiamGia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PhieuGiamGia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                PhieuGiamGia dialog = new PhieuGiamGia(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDotGiamGia;
    private javax.swing.JButton btnLamMoi;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnXoa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rdoDang;
    private javax.swing.JRadioButton rdoHet;
    private javax.swing.JTable tblPhieuGiamGia;
    private javax.swing.JTextField txtDieuKien;
    private javax.swing.JTextField txtGiaTri;
    private javax.swing.JTextField txtGiamToiDa;
    private javax.swing.JTextField txtLoai;
    private javax.swing.JTextField txtLoc;
    private javax.swing.JTextField txtMa;
    private javax.swing.JTextField txtNgayBD;
    private javax.swing.JTextField txtNgayKT;
    private javax.swing.JTextField txtSLDaDung;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtTen;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables
}
