/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package local.brand.dao;

import java.util.List;
import local.brand.entity.SanPham;

/**
 *
 * @author ASUS
 */
public interface SanPhamDAO {

    void insert(SanPham entity);

    void update(SanPham entity);

    void delete(Integer id);

    SanPham selectById(Integer id);

    List<SanPham> selectAll();

    List<SanPham> selectByKeyword(String keyword);

    int getTongSoLuongBySanPhamId(Integer id);

    boolean existsByMaSanPham(String maSanPham);

    SanPham selectByMaSanPham(String maSanPham);
}
