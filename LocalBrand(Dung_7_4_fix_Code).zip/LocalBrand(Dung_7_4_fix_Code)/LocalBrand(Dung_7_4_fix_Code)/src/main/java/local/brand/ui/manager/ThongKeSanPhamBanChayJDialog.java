package local.brand.ui.manager;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class ThongKeSanPhamBanChayJDialog extends javax.swing.JDialog {

    private final JTable tblTopSanPham = new JTable();

    public ThongKeSanPhamBanChayJDialog(java.awt.Frame parent, boolean modal, List<Object[]> data, Date tuNgay, Date denNgay) {
        super(parent, modal);
        initUi(data, tuNgay, denNgay);
    }

    private void initUi(List<Object[]> data, Date tuNgay, Date denNgay) {
        setTitle("Top 5 sản phẩm bán chạy");
        setSize(760, 420);
        setLocationRelativeTo(getParent());
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(12, 12));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBorder(BorderFactory.createEmptyBorder(12, 12, 0, 12));

        JLabel lblTitle = new JLabel("TOP 5 SAN PHAM BAN CHAY");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        headerPanel.add(lblTitle, BorderLayout.NORTH);

        JLabel lblRange = new JLabel(buildDateRangeText(tuNgay, denNgay));
        lblRange.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblRange.setForeground(new Color(90, 90, 90));
        headerPanel.add(lblRange, BorderLayout.SOUTH);

        add(headerPanel, BorderLayout.NORTH);

        tblTopSanPham.setModel(new DefaultTableModel(
                new Object[][]{},
                new String[]{"Top", "Tên sản phẩm", "Số lượng bán", "Doanh thu"}
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        });
        tblTopSanPham.setRowHeight(28);
        tblTopSanPham.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tblTopSanPham.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
        tblTopSanPham.getColumnModel().getColumn(2).setCellRenderer(rightRenderer);
        tblTopSanPham.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);

        fillTable(data);
        add(new JScrollPane(tblTopSanPham), BorderLayout.CENTER);
    }

    private void fillTable(List<Object[]> data) {
        DefaultTableModel model = (DefaultTableModel) tblTopSanPham.getModel();
        model.setRowCount(0);

        if (data == null || data.isEmpty()) {
            model.addRow(new Object[]{"-", "Chưa có dữ liệu", 0, formatCurrency(0)});
            return;
        }

        int index = 1;
        for (Object[] row : data) {
            model.addRow(new Object[]{
                index++,
                row[0],
                row[1],
                formatCurrency(row[2])
            });
        }
    }

    private String buildDateRangeText(Date tuNgay, Date denNgay) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        if (tuNgay == null || denNgay == null) {
            return "Khong xac dinh khoang thoi gian";
        }
        return "Khoang thong ke: " + sdf.format(tuNgay) + " - " + sdf.format(denNgay);
    }

    private String formatCurrency(Object value) {
        double amount = 0;
        if (value != null) {
            amount = Double.parseDouble(value.toString());
        }
        return NumberFormat.getCurrencyInstance(new Locale("vi", "VN")).format(amount);
    }
}
