/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.dao.impl;

import java.util.List;
import local.brand.dao.KieuDangDAO;
import local.brand.entity.KieuDang;
import local.brand.ulti.XJdbc;

/**
 *
 * @author ASUS
 */
public class KieuDangDAOImpl implements KieuDangDAO {
     private static final String SELECT_ALL = """
        SELECT 
            id AS id,
            ma_kieu_dang AS maKieuDang,
            ten_kieu_dang AS tenKieuDang,
            trang_thai AS trangThai
        FROM kieu_dang
        ORDER BY ten_kieu_dang
        """;

    private static final String SELECT_BY_ID = """
        SELECT 
            id AS id,
            ma_kieu_dang AS maKieuDang,
            ten_kieu_dang AS tenKieuDang,
            trang_thai AS trangThai
        FROM kieu_dang
        WHERE id = ?
        """;
    @Override
    public List<KieuDang> selectAll() {
        return XJdbc.getBeanList(KieuDang.class, SELECT_ALL);
    }

    @Override
    public KieuDang selectById(Integer id) {
        return XJdbc.getSingleBean(KieuDang.class, SELECT_BY_ID, id);
    }
    
}
