/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package local.brand.ui.manager;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import local.brand.dao.DanhMucDAO;
import local.brand.dao.KhachHangDAO;
import local.brand.dao.KichThuocDAO;
import local.brand.dao.MauSacDAO;
import local.brand.dao.PhieuGiamGiaDAO;
import local.brand.dao.SanPhamChiTietDAO;
import local.brand.dao.impl.DanhMucDAOImpl;
import local.brand.dao.impl.HoaDonDAOImpl;
import local.brand.dao.impl.KhachHangDAOImpl;
import local.brand.dao.impl.KichThuocDAOImpl;
import local.brand.dao.impl.MauSacDAOImpl;
import local.brand.dao.impl.SanPhamChiTietDAOImpl;
import local.brand.entity.DanhMuc;
import local.brand.entity.HoaDon;
import local.brand.entity.KhachHang;
import local.brand.entity.KichThuoc;
import local.brand.entity.MauSac;
import local.brand.entity.PhieuGG;
import local.brand.entity.SanPhamChiTiet;
import local.brand.ulti.XAuth;
import local.brand.ulti.XJdbc;
import local.brand.ui.manager.HoaDonManagerJDialog;

public class BanHangJDialog extends javax.swing.JDialog {

    private final SanPhamChiTietDAO sanPhamChiTietDAO = new SanPhamChiTietDAOImpl();
    private final DanhMucDAO danhMucDAO = new DanhMucDAOImpl();
    private final MauSacDAO mauSacDAO = new MauSacDAOImpl();
    private final KichThuocDAO kichThuocDAO = new KichThuocDAOImpl();
    private final KhachHangDAO khachHangDAO = new KhachHangDAOImpl();
    private final PhieuGiamGiaDAO phieuGiamGiaDAO = new PhieuGiamGiaDAO();
    private final HoaDonDAOImpl hoaDonDAO = new HoaDonDAOImpl();

    private static final int MAX_HOA_DON_CHO = 5;

    private final java.util.Map<String, Integer> tonKhoGocMap = new java.util.HashMap<>();

    private DefaultTableModel modelSanPham;
    private DefaultTableModel modelGioHang;

    private final List<GioHangItem> gioHangList = new ArrayList<>();

    private final DecimalFormat df = new DecimalFormat("#,##0");
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private boolean daTaoHoaDon = false;
    private boolean daThanhToan = false;
    private Integer selectedKhachId = null;
    private Integer pendingKhachId = null;
    private Integer confirmedKhachId = null;

    private final List<HoaDonChoSnapshot> dsHoaDonCho = new ArrayList<>();
    private int currentHoaDonChoIndex = -1;
    private boolean dangLoadHoaDonCho = false;

    private static class GioHangItem {

        int idSpct;
        String maSpct;
        String tenSp;
        String mau;
        String size;
        BigDecimal donGia;
        int soLuong;

        public GioHangItem(int idSpct, String maSpct, String tenSp, String mau, String size, BigDecimal donGia, int soLuong) {
            this.idSpct = idSpct;
            this.maSpct = maSpct;
            this.tenSp = tenSp;
            this.mau = mau;
            this.size = size;
            this.donGia = donGia;
            this.soLuong = soLuong;
        }

        public BigDecimal getThanhTien() {
            return donGia.multiply(BigDecimal.valueOf(soLuong));
        }
    }

    private static class HoaDonChoSnapshot {

        String maHoaDon;
        String thoiGian;
        String tenKhach;
        String sdtKhach;
        String ghiChu;
        String thanhToan;
        String phieuGiamGia;
        Integer idKhachSelected;
        List<GioHangItem> gioHangSnapshot = new ArrayList<>();
        String maKhach;
        Integer pendingKhachId;
        Integer confirmedKhachId;
        String maKhachXacNhan;
        String tenKhachXacNhan;
        String sdtKhachXacNhan;
        String tienKhachDua;
        String tienThua;

        @Override
        public String toString() {
            return maHoaDon + " - " + thoiGian;
        }
    }

    private HoaDonChoSnapshot taoHoaDonChoTrong() {
        HoaDonChoSnapshot snap = new HoaDonChoSnapshot();
        snap.maHoaDon = taoMaHoaDon();
        snap.thoiGian = sdf.format(new Date());
        snap.tenKhach = "";
        snap.sdtKhach = "";
        snap.ghiChu = "";
        snap.thanhToan = "Chọn thanh toán";
        snap.phieuGiamGia = "Không áp dụng";
        snap.idKhachSelected = null;
        snap.tienKhachDua = "";
        snap.tienThua = "0 đ";
        return snap;
    }

    private void luuHoaDonChoDangChon() {
        if (dangLoadHoaDonCho) {
            return;
        }
        if (currentHoaDonChoIndex < 0 || currentHoaDonChoIndex >= dsHoaDonCho.size()) {
            return;
        }

        HoaDonChoSnapshot snap = dsHoaDonCho.get(currentHoaDonChoIndex);
        snap.maHoaDon = txtMaHoaDon2.getText().trim();
        snap.thoiGian = txtThoiGian2.getText().trim();

        snap.maKhach = txtMaKhachHang.getText().trim();
        snap.tenKhach = txtTenKhachHang.getText().trim();
        snap.sdtKhach = txtDienThoaiKhachTab2.getText().trim();

        snap.pendingKhachId = pendingKhachId;
        snap.confirmedKhachId = confirmedKhachId;
        snap.idKhachSelected = confirmedKhachId;

        snap.maKhachXacNhan = txtXacNhanMa.getText().trim();
        snap.tenKhachXacNhan = txtXacNhanTen.getText().trim();
        snap.sdtKhachXacNhan = txtXacNhanSDT.getText().trim();
        snap.tienKhachDua = txtTienKhachDua.getText().trim();
        snap.tienThua = txtTienThua.getText().trim();

        snap.thanhToan = cboThanhToanTab2.getSelectedItem() == null
                ? "Chọn thanh toán"
                : cboThanhToanTab2.getSelectedItem().toString();

        snap.phieuGiamGia = cboPhieuGiamGiaTab2.getSelectedItem() == null
                ? "Không áp dụng"
                : cboPhieuGiamGiaTab2.getSelectedItem().toString();

        snap.gioHangSnapshot.clear();
        for (GioHangItem item : gioHangList) {
            snap.gioHangSnapshot.add(new GioHangItem(
                    item.idSpct, item.maSpct, item.tenSp, item.mau, item.size, item.donGia, item.soLuong
            ));
        }

        refreshHoaDonChoCombo();
    }

    private void datKhachVangLai() {
        pendingKhachId = null;
        confirmedKhachId = null;

        txtMaKhachHang.setText("");
        txtTenKhachHang.setText("");
        txtDienThoaiKhachTab2.setText("");

        txtXacNhanMa.setText("");
        txtXacNhanTen.setText("");
        txtXacNhanSDT.setText("");

        luuHoaDonChoDangChon();
    }

    private void doFormTuSnapshot(HoaDonChoSnapshot snap) {
        dangLoadHoaDonCho = true;

        txtMaHoaDon2.setText(snap.maHoaDon == null ? "" : snap.maHoaDon);
        txtThoiGian2.setText(snap.thoiGian == null ? "" : snap.thoiGian);
        txtNhanVien2.setText(XAuth.user != null ? XAuth.user.getTenNV() : "");

        txtMaKhachHang.setText(snap.maKhach == null ? "" : snap.maKhach);
        txtTenKhachHang.setText(snap.tenKhach == null ? "" : snap.tenKhach);
        txtDienThoaiKhachTab2.setText(snap.sdtKhach == null ? "" : snap.sdtKhach);
        txtTienKhachDua.setText(snap.tienKhachDua == null ? "" : snap.tienKhachDua);
        txtTienThua.setText(snap.tienThua == null ? "0 đ" : snap.tienThua);

        pendingKhachId = snap.pendingKhachId;
        confirmedKhachId = snap.confirmedKhachId;

        txtXacNhanMa.setText(snap.maKhachXacNhan == null ? "" : snap.maKhachXacNhan);
        txtXacNhanTen.setText(snap.tenKhachXacNhan == null ? "" : snap.tenKhachXacNhan);
        txtXacNhanSDT.setText(snap.sdtKhachXacNhan == null ? "" : snap.sdtKhachXacNhan);

        cboThanhToanTab2.setSelectedItem(snap.thanhToan);
        cboPhieuGiamGiaTab2.setSelectedItem(snap.phieuGiamGia);

        gioHangList.clear();
        for (GioHangItem item : snap.gioHangSnapshot) {
            gioHangList.add(new GioHangItem(
                    item.idSpct, item.maSpct, item.tenSp, item.mau, item.size, item.donGia, item.soLuong
            ));
        }

        loadSanPhamTable();
        renderGioHang();
        capNhatTonKhoHienThiTheoGioHang();
        tinhTien();

        daTaoHoaDon = false;
        daThanhToan = false;
        rdoChoThanhToan2.setSelected(true);

        dangLoadHoaDonCho = false;
    }

    private static class PaymentSplit {

        BigDecimal tienMat = BigDecimal.ZERO;
        BigDecimal chuyenKhoan = BigDecimal.ZERO;
    }

    private static class HinhThucItem {

        int id;
        String ten;

        public HinhThucItem(int id, String ten) {
            this.id = id;
            this.ten = ten;
        }

        @Override
        public String toString() {
            return ten;
        }
    }

    public BanHangJDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        initBanHang();

        setMinimumSize(new java.awt.Dimension(1700, 1000));
        setSize(1700, 1000);
    }

    private void initBanHang() {
        modelSanPham = (DefaultTableModel) tblSanPham.getModel();
        modelGioHang = (DefaultTableModel) tblGioHang.getModel();

        tblSanPham.setDefaultEditor(Object.class, null);
        tblGioHang.setDefaultEditor(Object.class, null);

        txtMaHoaDon2.setEditable(false);
        txtNhanVien2.setEditable(false);
        txtThoiGian2.setEditable(false);

        txtTongTien.setEditable(false);
        txtTienGiam.setEditable(false);
        txtThanhTien.setEditable(false);

        txtTongTienThanhToan2.setEditable(false);
        txtTienGiamThanhToan.setEditable(false);
        txtThanhTienThanhToan.setEditable(false);

        txtMaKhachHang.setEditable(true);
        txtTenKhachHang.setEditable(true);
        txtDienThoaiKhachTab2.setEditable(true);

        txtXacNhanMa.setEditable(false);
        txtXacNhanTen.setEditable(false);
        txtXacNhanSDT.setEditable(false);

        txtTienKhachDua.setText("");
        txtTienThua.setEditable(false);
        txtTienThua.setText("0 đ");

        buttonGroup1.add(rdoChoThanhToan2);
        buttonGroup1.add(rdoDaThanhToan2);
        rdoChoThanhToan2.setSelected(true);
        rdoDaThanhToan2.setEnabled(false);

        txtMaHoaDon2.setText("");
        txtThoiGian2.setText("");
        txtNhanVien2.setText(XAuth.user != null ? XAuth.user.getTenNV() : "");

        loadComboBox();
        loadSanPhamTable();
        renderGioHang();
        tinhTien();

        btnTim.addActionListener(e -> loadSanPhamTable());
        btnThemVaoGio.addActionListener(e -> themVaoGio());
        btnSangThanhToan.addActionListener(e -> sangTabThanhToan());
        btnQuayLaiSanPham.addActionListener(e -> jTabbedPane2.setSelectedIndex(0));
        btnChonKhach.addActionListener(e -> chonKhachHangTuBang());

        cboDanhMuc.addActionListener(e -> loadSanPhamTable());
        cboMauSac.addActionListener(e -> loadSanPhamTable());
        cboKichThuoc.addActionListener(e -> loadSanPhamTable());

        btnTaoHoaDon.addActionListener(e -> taoHoaDonChoMoi());
        btnSuaHoaDon2.addActionListener(e -> suaHoaDon());
        btnHuyHoaDon2.addActionListener(e -> huyHoaDon());
        btnThanhToan.addActionListener(e -> thanhToan());
        btnXemHoaDon.addActionListener(e -> moManHoaDon());

        btnLamMoiGioHang.addActionListener(e -> lamMoiGioHang());
        btnSuaGioHang.addActionListener(e -> suaGioHang());
        btnXoaGioHang.addActionListener(e -> xoaGioHang());
        btnLamMoi.addActionListener(e -> resetFormBanHang());

        cboHoaDonCho.addActionListener(e -> chonHoaDonCho());

        btnThemtab2.addActionListener(e -> themKhachHang());
        btnLamMoitab2.addActionListener(e -> lamMoiThongTinKhach());
        btnTimKhach.addActionListener(e -> timKhachHang());
        btnXacNhanKhach.addActionListener(e -> xacNhanKhachHang());

        txtTienKhachDua.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent e) {
                tinhTienThua();
            }
        });

        cboPhieuGiamGiaTab2.addActionListener(e -> {
            tinhTien();
            luuHoaDonChoDangChon();
        });

        cboThanhToanTab2.addActionListener(e -> {
            capNhatTrangThaiTienMat();
            tinhTienThua();
            luuHoaDonChoDangChon();
        });

        tblSanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    if (txtSoLuong.getText().trim().isEmpty()) {
                        txtSoLuong.setText("1");
                    }
                    themVaoGio();
                }
            }
        });

        jTabbedPane2.setSelectedIndex(0);

        capNhatTrangThaiTienMat();
        tinhTienThua();
    }

    private void loadComboBox() {
        cboDanhMuc.removeAllItems();
        cboMauSac.removeAllItems();
        cboKichThuoc.removeAllItems();

        cboPhieuGiamGiaTab2.removeAllItems();
        cboThanhToanTab2.removeAllItems();

        // Danh mục
        cboDanhMuc.addItem("Tất cả");
        for (DanhMuc dm : danhMucDAO.selectAll()) {
            cboDanhMuc.addItem(dm.getTenDanhMuc());
        }

        // Màu sắc
        cboMauSac.addItem("Tất cả");
        for (MauSac ms : mauSacDAO.selectAll()) {
            cboMauSac.addItem(ms.getTenMau());
        }

        // Kích thước
        cboKichThuoc.addItem("Tất cả");
        for (KichThuoc kt : kichThuocDAO.selectAll()) {
            cboKichThuoc.addItem(kt.getTenKichThuoc());
        }

        // Phiếu giảm giá
        cboPhieuGiamGiaTab2.addItem("Không áp dụng");

        Date now = new Date();
        for (PhieuGG p : phieuGiamGiaDAO.getAll()) {
            boolean hopLe = p.isTrangThai()
                    && (p.getNgayBatDau() == null || !now.before(p.getNgayBatDau()))
                    && (p.getNgayKetThuc() == null
                    || !now.after(new Date(p.getNgayKetThuc().getTime() + 24L * 60 * 60 * 1000 - 1)))
                    && p.getSoLuongDaDung() < p.getSoLuong();

            if (hopLe) {
                String item = p.getMa() + " - " + p.getTen();
                cboPhieuGiamGiaTab2.addItem(item);
            }
        }

        // Hình thức thanh toán
        cboThanhToanTab2.addItem("Chọn thanh toán");

        try (ResultSet rs = XJdbc.query("""
        SELECT ten_hinh_thuc
        FROM hinh_thuc_thanh_toan
        WHERE trang_thai = 1
        ORDER BY id DESC
    """)) {
            while (rs.next()) {
                cboThanhToanTab2.addItem(rs.getString("ten_hinh_thuc"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadSanPhamTable() {
        modelSanPham.setRowCount(0);
        tonKhoGocMap.clear();

        String keyword = txtTimSanPham.getText().trim();
        String danhMuc = cboDanhMuc.getSelectedItem() == null ? "Tất cả" : cboDanhMuc.getSelectedItem().toString();
        String mau = cboMauSac.getSelectedItem() == null ? "Tất cả" : cboMauSac.getSelectedItem().toString();
        String size = cboKichThuoc.getSelectedItem() == null ? "Tất cả" : cboKichThuoc.getSelectedItem().toString();

        String sql = """
            SELECT 
                spct.id,
                spct.ma_sp_chi_tiet,
                sp.ten_san_pham,
                ms.ten_mau,
                kt.ten_kich_thuoc,
                COALESCE(gg_dang_ap_dung.gia_sau_giam, spct.don_gia) AS don_gia,
                spct.so_luong
            FROM san_pham_chi_tiet spct
            JOIN san_pham sp ON spct.id_san_pham = sp.id
            JOIN mau_sac ms ON spct.id_mau_sac = ms.id
            JOIN kich_thuoc kt ON spct.id_kich_thuoc = kt.id
            JOIN danh_muc dm ON sp.id_danh_muc = dm.id
            LEFT JOIN (
                SELECT
                    spgg.id_san_pham_chi_tiet,
                    MIN(spgg.gia_sau_giam) AS gia_sau_giam
                FROM san_pham_giam_gia spgg
                JOIN dot_giam_gia dgg ON dgg.id = spgg.id_dot_giam_gia
                WHERE spgg.trang_thai = 1
                  AND dgg.trang_thai = 1
                  AND CAST(GETDATE() AS DATE) BETWEEN dgg.ngay_bat_dau AND dgg.ngay_ket_thuc
                GROUP BY spgg.id_san_pham_chi_tiet
            ) gg_dang_ap_dung ON gg_dang_ap_dung.id_san_pham_chi_tiet = spct.id
            WHERE spct.trang_thai = 1
              AND sp.trang_thai = 1
              AND spct.so_luong > 0
              AND (? = '' OR sp.ten_san_pham LIKE ? OR spct.ma_sp_chi_tiet LIKE ?)
              AND (? = N'Tất cả' OR dm.ten_danh_muc = ?)
              AND (? = N'Tất cả' OR ms.ten_mau = ?)
              AND (? = N'Tất cả' OR kt.ten_kich_thuoc = ?)
        """;

        try {
            ResultSet rs = XJdbc.query(
                    sql,
                    keyword, "%" + keyword + "%", "%" + keyword + "%",
                    danhMuc, danhMuc,
                    mau, mau,
                    size, size
            );

            while (rs.next()) {
                String maSpct = rs.getString("ma_sp_chi_tiet");
                int tonKho = rs.getInt("so_luong");

                tonKhoGocMap.put(maSpct, tonKho);

                modelSanPham.addRow(new Object[]{
                    maSpct,
                    rs.getString("ten_san_pham"),
                    rs.getString("ten_mau"),
                    rs.getString("ten_kich_thuoc"),
                    rs.getBigDecimal("don_gia"),
                    tonKho
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi load sản phẩm: " + e.getMessage());
        }
    }

    private int getIdSpctByMa(String maSpct) {
        try {
            Object value = XJdbc.getValue("SELECT id FROM san_pham_chi_tiet WHERE ma_sp_chi_tiet = ?", maSpct);
            return value == null ? -1 : Integer.parseInt(value.toString());
        } catch (Exception e) {
            return -1;
        }
    }

    private void themVaoGio() {
        int row = tblSanPham.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm!");
            return;
        }

        String soLuongText = txtSoLuong.getText().trim();
        if (soLuongText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập số lượng!");
            txtSoLuong.requestFocus();
            return;
        }

        int soLuongMua;
        try {
            soLuongMua = Integer.parseInt(soLuongText);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Số lượng phải là số nguyên!");
            txtSoLuong.requestFocus();
            return;
        }
        if (soLuongMua <= 0) {
            JOptionPane.showMessageDialog(this, "Số lượng phải lớn hơn 0!");
            txtSoLuong.requestFocus();
            return;
        }

        String maSpct = modelSanPham.getValueAt(row, 0).toString();
        String tenSp = modelSanPham.getValueAt(row, 1).toString();
        String mau = modelSanPham.getValueAt(row, 2).toString();
        String size = modelSanPham.getValueAt(row, 3).toString();
        BigDecimal donGia = new BigDecimal(modelSanPham.getValueAt(row, 4).toString());

        int tonKhoThucTe = getTonKhoThucTeByMa(maSpct);
        int daGiuOHoaDonKhac = getSoLuongDaGiuOHoaDonChoKhac(maSpct);

        GioHangItem itemTonTai = null;
        for (GioHangItem it : gioHangList) {
            if (it.maSpct.equalsIgnoreCase(maSpct)) {
                itemTonTai = it;
                break;
            }
        }
        int dangCo = itemTonTai == null ? 0 : itemTonTai.soLuong;
        int tonCoTheDung = tonKhoThucTe - daGiuOHoaDonKhac;

        if (tonCoTheDung <= 0) {
            loadSanPhamTable();
            capNhatTonKhoHienThiTheoGioHang();
            JOptionPane.showMessageDialog(this, "Sản phẩm này đã được giữ hết ở hóa đơn khác hoặc đã hết hàng!");
            return;
        }

        int tongSauKhiThem = dangCo + soLuongMua;
        if (tongSauKhiThem > tonCoTheDung) {
            loadSanPhamTable();
            capNhatTonKhoHienThiTheoGioHang();
            JOptionPane.showMessageDialog(this,
                    "Số lượng mua vượt quá tồn khả dụng!\nTồn thực tế: " + tonKhoThucTe
                    + "\nĐã giữ ở hóa đơn khác: " + daGiuOHoaDonKhac
                    + "\nCòn có thể thêm: " + Math.max(0, tonCoTheDung - dangCo));
            return;
        }

        if (itemTonTai == null) {
            int idSpct = getIdSpctByMa(maSpct);
            gioHangList.add(new GioHangItem(idSpct, maSpct, tenSp, mau, size, donGia, soLuongMua));
        } else {
            itemTonTai.soLuong += soLuongMua;
        }

        txtSoLuong.setText("");
        renderGioHang();
        tinhTien();
        luuHoaDonChoDangChon();
        loadSanPhamTable();
        capNhatTonKhoHienThiTheoGioHang();
        JOptionPane.showMessageDialog(this, "Đã thêm vào giỏ hàng!");
    }

    private int getSoLuongTrongGio(String maSpct) {
        for (GioHangItem item : gioHangList) {
            if (item.maSpct.equalsIgnoreCase(maSpct)) {
                return item.soLuong;
            }
        }
        return 0;
    }

    private void capNhatTonKhoHienThiTheoGioHang() {
        for (int i = 0; i < modelSanPham.getRowCount(); i++) {
            String maSpct = modelSanPham.getValueAt(i, 0).toString();
            int tonKhoGoc = tonKhoGocMap.getOrDefault(maSpct, 0);
            int daGiuOHoaDonKhac = getSoLuongDaGiuOHoaDonChoKhac(maSpct);
            int daThemTrongHoaDonHienTai = getSoLuongTrongGio(maSpct);

            int tonHienTai = tonKhoGoc - daGiuOHoaDonKhac - daThemTrongHoaDonHienTai;
            modelSanPham.setValueAt(Math.max(0, tonHienTai), i, 5);
        }
    }

    private void renderGioHang() {
        modelGioHang.setRowCount(0);

        for (GioHangItem item : gioHangList) {
            modelGioHang.addRow(new Object[]{
                item.maSpct,
                item.tenSp,
                item.mau,
                item.size,
                item.soLuong,
                item.donGia,
                item.getThanhTien()
            });
        }
    }

    private void tinhTien() {
        BigDecimal tongTien = BigDecimal.ZERO;
        for (GioHangItem item : gioHangList) {
            tongTien = tongTien.add(item.getThanhTien());
        }

        BigDecimal tienGiam = tinhTienGiam(tongTien);
        BigDecimal thanhTien = tongTien.subtract(tienGiam);
        if (thanhTien.compareTo(BigDecimal.ZERO) < 0) {
            thanhTien = BigDecimal.ZERO;
        }

        txtTongTien.setText(formatMoney(tongTien));
        txtTienGiam.setText(formatMoney(tienGiam));
        txtThanhTien.setText(formatMoney(thanhTien));

        txtTongTienThanhToan2.setText(formatMoney(tongTien));
        txtTienGiamThanhToan.setText(formatMoney(tienGiam));
        txtThanhTienThanhToan.setText(formatMoney(thanhTien));
        tinhTienThua();
    }

    private BigDecimal tinhTienGiam(BigDecimal tongTien) {
        PhieuGG p = getPhieuGGSelected();
        if (p == null) {
            return BigDecimal.ZERO;
        }

        Date now = new Date();

        if (!p.isTrangThai()) {
            return BigDecimal.ZERO;
        }

        if (p.getNgayBatDau() != null && now.before(p.getNgayBatDau())) {
            return BigDecimal.ZERO;
        }

        if (p.getNgayKetThuc() != null) {
            Date endOfDay = new Date(p.getNgayKetThuc().getTime() + 24L * 60 * 60 * 1000 - 1);
            if (now.after(endOfDay)) {
                return BigDecimal.ZERO;
            }
        }

        if (p.getSoLuongDaDung() >= p.getSoLuong()) {
            return BigDecimal.ZERO;
        }

        BigDecimal dieuKien = BigDecimal.valueOf(p.getDieuKien());
        if (tongTien.compareTo(dieuKien) < 0) {
            return BigDecimal.ZERO;
        }

        BigDecimal giam;

        if ("PHAN_TRAM".equalsIgnoreCase(p.getLoai())) {
            giam = tongTien.multiply(BigDecimal.valueOf(p.getGiaTriGiam()))
                    .divide(BigDecimal.valueOf(100));

            BigDecimal giamMax = BigDecimal.valueOf(p.getGiamGiaToiDa());
            if (giamMax.compareTo(BigDecimal.ZERO) > 0 && giam.compareTo(giamMax) > 0) {
                giam = giamMax;
            }
        } else if ("SO_TIEN".equalsIgnoreCase(p.getLoai())) {
            giam = BigDecimal.valueOf(p.getGiaTriGiam());
        } else {
            return BigDecimal.ZERO;
        }

        if (giam.compareTo(tongTien) > 0) {
            giam = tongTien;
        }

        return giam;
    }

    private String getSdtKhachThucTe() {
        String sdt = txtXacNhanSDT.getText().trim();
        return sdt.isEmpty() ? "" : sdt;
    }

    private boolean validateSangThanhToan() {
        if (gioHangList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Giỏ hàng đang trống!");
            return false;
        }
        return true;
    }

    private boolean validateThanhToanInfo() {
        if (gioHangList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Giỏ hàng đang trống!");
            return false;
        }

        if (cboThanhToanTab2.getSelectedItem() == null
                || "Chọn thanh toán".equals(cboThanhToanTab2.getSelectedItem().toString())) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn hình thức thanh toán!");
            return false;
        }

        String maNhap = txtMaKhachHang.getText().trim();
        String tenNhap = txtTenKhachHang.getText().trim();
        String sdtNhap = txtDienThoaiKhachTab2.getText().trim();

        String maXn = txtXacNhanMa.getText().trim();
        String tenXn = txtXacNhanTen.getText().trim();
        String sdtXn = txtXacNhanSDT.getText().trim();

        boolean panelTrenTrong = maNhap.isEmpty() && tenNhap.isEmpty() && sdtNhap.isEmpty();
        boolean panelXacNhanTrong = maXn.isEmpty() && tenXn.isEmpty() && sdtXn.isEmpty();

        if (panelTrenTrong && panelXacNhanTrong) {
            return true; // khách vãng lai
        }

        if (confirmedKhachId == null || panelXacNhanTrong) {
            JOptionPane.showMessageDialog(this, "Vui lòng bấm XÁC NHẬN KHÁCH trước khi thanh toán!");
            return false;
        }
        if (isThanhToanTienMat()) {
            BigDecimal thanhTien = parseMoney(txtThanhTienThanhToan.getText());
            BigDecimal tienKhachDua = parseMoneyInput(txtTienKhachDua.getText());

            if (tienKhachDua.compareTo(BigDecimal.ZERO) <= 0) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập tiền khách đưa!");
                txtTienKhachDua.requestFocus();
                return false;
            }

            if (tienKhachDua.compareTo(thanhTien) < 0) {
                JOptionPane.showMessageDialog(this, "Tiền khách đưa chưa đủ để thanh toán!");
                txtTienKhachDua.requestFocus();
                return false;
            }
        }
        return true;
    }

    private void sangTabThanhToan() {
        if (!validateSangThanhToan()) {
            return;
        }
        jTabbedPane2.setSelectedIndex(1);
    }

    private Integer getIdHinhThucThanhToanSelected() {
        Object selected = cboThanhToanTab2.getSelectedItem();

        if (selected == null) {
            return null;
        }

        String tenHinhThuc = selected.toString().trim();

        if (tenHinhThuc.isEmpty() || tenHinhThuc.equalsIgnoreCase("Chọn thanh toán")) {
            return null;
        }

        try {
            Object value = XJdbc.getValue(
                    "SELECT id FROM hinh_thuc_thanh_toan WHERE ten_hinh_thuc = ?",
                    tenHinhThuc
            );
            return value == null ? null : Integer.valueOf(value.toString());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private Integer getIdKhachSelected() {
        String maXn = txtXacNhanMa.getText().trim();
        String tenXn = txtXacNhanTen.getText().trim();
        String sdtXn = txtXacNhanSDT.getText().trim();

        if (maXn.isEmpty() && tenXn.isEmpty() && sdtXn.isEmpty()) {
            return null; // khách vãng lai
        }

        return confirmedKhachId;
    }

    private PhieuGG getPhieuGGSelected() {
        Object selected = cboPhieuGiamGiaTab2.getSelectedItem();

        if (selected == null) {
            return null;
        }

        String value = selected.toString().trim();
        if (value.isEmpty() || value.equalsIgnoreCase("Không áp dụng")) {
            return null;
        }

        try {
            String maPhieu = value.split(" - ")[0].trim();
            return phieuGiamGiaDAO.findById(maPhieu);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private Integer getIdPhieuSelected() {
        PhieuGG p = getPhieuGGSelected();
        if (p == null) {
            return null;
        }

        try {
            Object value = XJdbc.getValue("SELECT id FROM phieu_giam_gia WHERE ma_phieu = ?", p.getMa());
            return value == null ? null : Integer.parseInt(value.toString());
        } catch (Exception e) {
            return null;
        }
    }

    private HoaDon buildHoaDonFromForm(int trangThai) {
        if (XAuth.user == null) {
            throw new RuntimeException("Chưa đăng nhập nhân viên!");
        }

        Integer idNV = XAuth.user.getId();
        if (idNV == null || idNV <= 0) {
            throw new RuntimeException("ID nhân viên đăng nhập không hợp lệ!");
        }

        Integer idHinhThuc = getIdHinhThucThanhToanSelected();
        if (idHinhThuc == null) {
            throw new RuntimeException("Chưa chọn hình thức thanh toán!");
        }

        String maHoaDon = txtMaHoaDon2.getText().trim();
        if (maHoaDon.isEmpty()) {
            throw new RuntimeException("Mã hóa đơn đang rỗng!");
        }

        HoaDon hd = new HoaDon();
        hd.setMaHoaDon(maHoaDon);
        hd.setThoiGianMua(getThoiGianMuaFromForm());
        hd.setIdNhanVien(idNV);
        hd.setIdKhach(getIdKhachSelected());
        hd.setIdHinhThuc(idHinhThuc);
        hd.setPhieuGiam(getIdPhieuSelected());
        hd.setTongTien(parseMoney(txtTongTienThanhToan2.getText()));
        hd.setTienGiam(parseMoney(txtTienGiamThanhToan.getText()));
        hd.setThanhTien(parseMoney(txtThanhTienThanhToan.getText()));
        hd.setTenKh(getTenKhachThucTe());
        hd.setSdtKh(getSdtKhachThucTe());
        hd.setTrangThai(trangThai);

        return hd;
    }

    private Date getThoiGianMuaFromForm() {
        String text = txtThoiGian2.getText().trim();
        if (text.isEmpty()) {
            throw new RuntimeException("Thời gian mua không được để trống!");
        }

        try {
            return sdf.parse(text);
        } catch (Exception e) {
            throw new RuntimeException("Sai định dạng thời gian! Dùng yyyy-MM-dd HH:mm:ss");
        }
    }

    private void insertHoaDonChiTiet(int idHoaDon) {
        String sql = """
            INSERT INTO hoa_don_chi_tiet(id_san_pham_chi_tiet, id_hoa_don, so_luong, don_gia)
            VALUES (?, ?, ?, ?)
        """;

        for (GioHangItem item : gioHangList) {
            XJdbc.executeUpdate(sql, item.idSpct, idHoaDon, item.soLuong, item.donGia);
        }
    }

    private void deleteHoaDonChiTietByIdHoaDon(int idHoaDon) {
        XJdbc.executeUpdate("DELETE FROM hoa_don_chi_tiet WHERE id_hoa_don = ?", idHoaDon);
    }

    private void updateHoaDonHeader(HoaDon hd) {
        String sql = """
            UPDATE hoa_don
            SET id_nhan_vien = ?, id_khach = ?, id_hinh_thuc = ?, phieu_giam = ?,
                tong_tien = ?, trang_thai = ?, tien_giam = ?, thanh_tien = ?, ten_kh = ?, sdt_kh = ?
            WHERE ma_hoa_don = ?
        """;

        XJdbc.executeUpdate(sql,
                hd.getIdNhanVien(),
                hd.getIdKhach(),
                hd.getIdHinhThuc(),
                hd.getPhieuGiam(),
                hd.getTongTien(),
                hd.getTrangThai(),
                hd.getTienGiam(),
                hd.getThanhTien(),
                hd.getTenKh(),
                hd.getSdtKh(),
                hd.getMaHoaDon()
        );
    }

    private void truSoLuongTonKho() {
        for (GioHangItem item : gioHangList) {
            int updated = XJdbc.executeUpdate("""
            UPDATE san_pham_chi_tiet
            SET so_luong = so_luong - ?
            WHERE id = ? AND so_luong >= ?
        """, item.soLuong, item.idSpct, item.soLuong);

            if (updated <= 0) {
                throw new RuntimeException("Sản phẩm " + item.maSpct + " không đủ tồn kho để thanh toán!");
            }
        }
    }

    private void tangSoLuongDaDungVoucher() {
        PhieuGG p = getPhieuGGSelected();
        if (p == null) {
            return;
        }

        XJdbc.executeUpdate("""
        UPDATE phieu_giam_gia
        SET so_luong_dung_ma_giam = so_luong_dung_ma_giam + 1
        WHERE ma_phieu = ?
    """, p.getMa());
    }

    private void taoHoaDon() {
        if (daTaoHoaDon) {
            JOptionPane.showMessageDialog(this, "Hóa đơn này đã được tạo rồi!");
            return;
        }

        if (!validateThanhToanInfo()) {
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn tạo hóa đơn?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            HoaDon hd = buildHoaDonFromForm(0);
            hoaDonDAO.insert(hd);

            HoaDon hdDb = hoaDonDAO.selectById(hd.getMaHoaDon());
            if (hdDb != null) {
                insertHoaDonChiTiet(hdDb.getId());
            }

            daTaoHoaDon = true;
            JOptionPane.showMessageDialog(this, "Tạo hóa đơn thành công!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Tạo hóa đơn thất bại: " + e.getMessage());
        }
    }

    private void suaHoaDon() {
        if (!daTaoHoaDon) {
            JOptionPane.showMessageDialog(this, "Chưa có hóa đơn để sửa!");
            return;
        }

        if (!validateThanhToanInfo()) {
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn sửa hóa đơn?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            HoaDon hd = buildHoaDonFromForm(0);
            updateHoaDonHeader(hd);

            HoaDon hdDb = hoaDonDAO.selectById(hd.getMaHoaDon());
            if (hdDb != null) {
                deleteHoaDonChiTietByIdHoaDon(hdDb.getId());
                insertHoaDonChiTiet(hdDb.getId());
            }

            JOptionPane.showMessageDialog(this, "Sửa hóa đơn thành công!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Sửa hóa đơn thất bại: " + e.getMessage());
        }
    }

    private void huyHoaDon() {
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc muốn hủy hóa đơn này không?",
                "Xác nhận hủy",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        if (daThanhToan) {
            JOptionPane.showMessageDialog(this, "Hóa đơn đã thanh toán, không thể hủy!");
            return;
        }

        try {
            if (daTaoHoaDon) {
                String maHd = txtMaHoaDon2.getText().trim();
                Integer idHd = hoaDonDAO.getIdByMa(maHd);

                if (idHd != null) {
                    XJdbc.executeUpdate("DELETE FROM hoa_don_chi_tiet WHERE id_hoa_don = ?", idHd);
                    XJdbc.executeUpdate("DELETE FROM hoa_don WHERE id = ?", idHd);
                }
            }

            xoaHoaDonChoHienTaiNeuCo();
            loadSanPhamTable();
            dongBoTatCaHoaDonChoTheoTonKho();
            resetFormBanHang();

            JOptionPane.showMessageDialog(this, "Đã hủy hóa đơn!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi hủy hóa đơn: " + e.getMessage());
        }
    }

    private void thanhToan() {
        if (daThanhToan) {
            JOptionPane.showMessageDialog(this, "Hóa đơn đã thanh toán rồi!");
            return;
        }

        if (!validateThanhToanInfo()) {
            return;
        }

        if (!kiemTraTonKhoTruocThanhToan()) {
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Xác nhận thanh toán?", "Thanh toán", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            if (!daTaoHoaDon) {
                HoaDon hd = buildHoaDonFromForm(0);
                hoaDonDAO.insert(hd);
                HoaDon hdDb = hoaDonDAO.selectById(hd.getMaHoaDon());
                if (hdDb != null) {
                    insertHoaDonChiTiet(hdDb.getId());
                }
                daTaoHoaDon = true;
            }

            HoaDon hdThanhToan = buildHoaDonFromForm(1);
            updateHoaDonHeader(hdThanhToan);

            truSoLuongTonKho();
            tangSoLuongDaDungVoucher();

            loadSanPhamTable();
            dongBoTatCaHoaDonChoTheoTonKho();
            daTaoHoaDon = false;
            daThanhToan = false;
            rdoChoThanhToan2.setSelected(true);

            xoaHoaDonChoHienTaiNeuCo();

            JOptionPane.showMessageDialog(this, "Thanh toán thành công!");
            resetFormBanHang();
            loadSanPhamTable(); // load lại tồn kho thật từ DB

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Thanh toán thất bại: " + e.getMessage());
        }
    }

    private void resetFormBanHang() {
        txtMaHoaDon2.setText("");
        txtThoiGian2.setText("");
        txtNhanVien2.setText(XAuth.user != null ? XAuth.user.getTenNV() : "");

        pendingKhachId = null;
        confirmedKhachId = null;

        txtMaKhachHang.setText("");
        txtTenKhachHang.setText("");
        txtDienThoaiKhachTab2.setText("");

        txtXacNhanMa.setText("");
        txtXacNhanTen.setText("");
        txtXacNhanSDT.setText("");

        txtTienKhachDua.setText("");
        txtTienThua.setText("0 đ");
        capNhatTrangThaiTienMat();

        gioHangList.clear();
        renderGioHang();
        capNhatTonKhoHienThiTheoGioHang();
        tinhTien();

        if (cboThanhToanTab2.getItemCount() > 0) {
            cboThanhToanTab2.setSelectedIndex(0);
        }

        if (cboPhieuGiamGiaTab2.getItemCount() > 0) {
            cboPhieuGiamGiaTab2.setSelectedIndex(0);
        }

        daTaoHoaDon = false;
        daThanhToan = false;
        rdoChoThanhToan2.setSelected(true);
    }

    private String taoMaHoaDon() {
        return "HD" + new SimpleDateFormat("ddMMyyHHmmssSSS").format(new Date());
    }

    private String formatMoney(BigDecimal value) {
        return df.format(value) + " đ";
    }

    private BigDecimal parseMoney(String text) {
        String cleaned = text.replace("đ", "").replace(",", "").replace(".", "").trim();
        if (cleaned.isEmpty()) {
            return BigDecimal.ZERO;
        }
        return new BigDecimal(cleaned);
    }

    private void suaGioHang() {
        int row = tblGioHang.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn dòng trong giỏ hàng!");
            return;
        }

        String maSpct = tblGioHang.getValueAt(row, 0).toString();
        String soLuongMoiText = JOptionPane.showInputDialog(this, "Nhập số lượng mới:");

        if (soLuongMoiText == null) {
            return;
        }

        int soLuongMoi;
        try {
            soLuongMoi = Integer.parseInt(soLuongMoiText.trim());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Số lượng không hợp lệ!");
            return;
        }

        if (soLuongMoi <= 0) {
            JOptionPane.showMessageDialog(this, "Số lượng phải lớn hơn 0!");
            return;
        }

        int tonKhoGoc = tonKhoGocMap.getOrDefault(maSpct, 0);
        if (soLuongMoi > tonKhoGoc) {
            JOptionPane.showMessageDialog(this, "Số lượng vượt quá tồn kho!");
            return;
        }

        for (GioHangItem item : gioHangList) {
            if (item.maSpct.equalsIgnoreCase(maSpct)) {
                item.soLuong = soLuongMoi;
                break;
            }
        }

        renderGioHang();
        capNhatTonKhoHienThiTheoGioHang();
        tinhTien();
        luuHoaDonChoDangChon();
    }

    private void xoaGioHang() {
        int row = tblGioHang.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm trong giỏ hàng!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc muốn xóa sản phẩm này khỏi giỏ hàng không?",
                "Xác nhận xóa",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String maSpct = tblGioHang.getValueAt(row, 0).toString();

        gioHangList.removeIf(item -> item.maSpct.equalsIgnoreCase(maSpct));

        renderGioHang();
        capNhatTonKhoHienThiTheoGioHang();
        tinhTien();
        luuHoaDonChoDangChon();
    }

    private void xoaHoaDonChoHienTaiNeuCo() {
        if (currentHoaDonChoIndex >= 0 && currentHoaDonChoIndex < dsHoaDonCho.size()) {
            dsHoaDonCho.remove(currentHoaDonChoIndex);
        }

        currentHoaDonChoIndex = -1;
        refreshHoaDonChoCombo();
    }

    private void lamMoiGioHang() {
        gioHangList.clear();
        renderGioHang();
        capNhatTonKhoHienThiTheoGioHang();
        tinhTien();
        luuHoaDonChoDangChon();
    }

    private void taoHoaDonChoMoi() {
        if (dsHoaDonCho.size() >= MAX_HOA_DON_CHO) {
            JOptionPane.showMessageDialog(this, "Chỉ được tạo tối đa 5 hóa đơn chờ!");
            return;
        }

        luuHoaDonChoDangChon();

        HoaDonChoSnapshot snap = taoHoaDonChoTrong();
        dsHoaDonCho.add(snap);
        currentHoaDonChoIndex = dsHoaDonCho.size() - 1;

        gioHangList.clear();
        renderGioHang();
        tinhTien();
        capNhatTonKhoHienThiTheoGioHang();

        refreshHoaDonChoCombo();
        doFormTuSnapshot(snap);
    }

    private void chonHoaDonCho() {
        if (dangLoadHoaDonCho) {
            return;
        }

        int newIndex = cboHoaDonCho.getSelectedIndex();
        if (newIndex < 0 || newIndex >= dsHoaDonCho.size()) {
            return;
        }

        if (currentHoaDonChoIndex != -1 && currentHoaDonChoIndex != newIndex) {
            luuHoaDonChoDangChon();
        }

        currentHoaDonChoIndex = newIndex;
        gioHangList.clear();
        renderGioHang();

        doFormTuSnapshot(dsHoaDonCho.get(currentHoaDonChoIndex));
    }

    private void moManHoaDon() {
        HoaDonManagerJDialog dialog = new HoaDonManagerJDialog((java.awt.Frame) this.getOwner(), true);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void refreshHoaDonChoCombo() {
        dangLoadHoaDonCho = true;

        cboHoaDonCho.removeAllItems();
        for (int i = 0; i < dsHoaDonCho.size(); i++) {
            HoaDonChoSnapshot snap = dsHoaDonCho.get(i);
            cboHoaDonCho.addItem("Hóa đơn chờ " + (i + 1) + " - " + snap.maHoaDon);
        }

        if (currentHoaDonChoIndex >= 0 && currentHoaDonChoIndex < dsHoaDonCho.size()) {
            cboHoaDonCho.setSelectedIndex(currentHoaDonChoIndex);
        } else {
            cboHoaDonCho.setSelectedIndex(-1);
        }

        dangLoadHoaDonCho = false;
    }

    private void timKhachHang() {
        String ma = txtMaKhachHang.getText().trim();
        String sdt = txtDienThoaiKhachTab2.getText().trim();

        if (ma.isEmpty() && sdt.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập mã khách hàng hoặc SĐT!");
            txtMaKhachHang.requestFocus();
            return;
        }

        napKhachHangLenForm(ma, sdt, true);
    }

    private void xacNhanKhachHang() {
        String ma = txtMaKhachHang.getText().trim();
        String sdt = txtDienThoaiKhachTab2.getText().trim();
        String ten = txtTenKhachHang.getText().trim();

        if (ma.isEmpty() && ten.isEmpty() && sdt.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Chưa có thông tin khách để xác nhận!");
            return;
        }

        if (pendingKhachId == null) {
            boolean found = napKhachHangLenForm(ma, sdt, false);
            if (!found) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy khách hàng trong hệ thống. Vui lòng kiểm tra lại mã, tên hoặc SĐT!");
                return;
            }
        }

        confirmedKhachId = pendingKhachId;

        txtXacNhanMa.setText(txtMaKhachHang.getText().trim());
        txtXacNhanTen.setText(txtTenKhachHang.getText().trim());
        txtXacNhanSDT.setText(txtDienThoaiKhachTab2.getText().trim());

        luuHoaDonChoDangChon();
    }

    private void lamMoiThongTinKhach() {
        pendingKhachId = null;
        confirmedKhachId = null;

        txtMaKhachHang.setText("");
        txtTenKhachHang.setText("");
        txtDienThoaiKhachTab2.setText("");

        txtXacNhanMa.setText("");
        txtXacNhanTen.setText("");
        txtXacNhanSDT.setText("");
    }

    private void themKhachHang() {
        KhachHangManagerJDialog dialog = new KhachHangManagerJDialog((java.awt.Frame) this.getOwner(), true);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);

        String ma = txtMaKhachHang.getText().trim();
        String ten = txtTenKhachHang.getText().trim();
        String sdt = txtDienThoaiKhachTab2.getText().trim();

        if (!ma.isEmpty() || !ten.isEmpty() || !sdt.isEmpty()) {
            napKhachHangLenForm(ma, sdt, false);
        }
    }

    private boolean kiemTraTonKhoTruocThanhToan() {
        try {
            for (GioHangItem item : gioHangList) {
                Object value = XJdbc.getValue(
                        "SELECT so_luong FROM san_pham_chi_tiet WHERE id = ?",
                        item.idSpct
                );

                int tonHienTai = value == null ? 0 : Integer.parseInt(value.toString());

                if (item.soLuong > tonHienTai) {
                    JOptionPane.showMessageDialog(
                            this,
                            "Sản phẩm " + item.maSpct + " không đủ tồn kho.\n"
                            + "Tồn hiện tại: " + tonHienTai + ", số lượng cần: " + item.soLuong
                    );
                    return false;
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi kiểm tra tồn kho: " + e.getMessage());
            return false;
        }
        return true;
    }

    private String getTenKhachThucTe() {
        String ten = txtXacNhanTen.getText().trim();
        if (!ten.isEmpty()) {
            return ten;
        }
        return txtTenKhachHang.getText().trim();
    }

    private boolean napKhachHangLenForm(String ma, String sdt, boolean showNotFoundMessage) {
        String sql;
        Object[] args;

        if (!ma.isEmpty()) {
            sql = """
            SELECT TOP 1 id, ma_kh, ten_kh, sdt
            FROM khach_hang
            WHERE ma_kh = ?
            ORDER BY id DESC
        """;
            args = new Object[]{ma};
        } else {
            sql = """
            SELECT TOP 1 id, ma_kh, ten_kh, sdt
            FROM khach_hang
            WHERE sdt = ?
            ORDER BY id DESC
        """;
            args = new Object[]{sdt};
        }

        try (ResultSet rs = XJdbc.query(sql, args)) {
            if (rs.next()) {
                pendingKhachId = rs.getInt("id");
                confirmedKhachId = null;

                txtMaKhachHang.setText(rs.getString("ma_kh"));
                txtTenKhachHang.setText(rs.getString("ten_kh"));
                txtDienThoaiKhachTab2.setText(rs.getString("sdt"));

                txtXacNhanMa.setText("");
                txtXacNhanTen.setText("");
                txtXacNhanSDT.setText("");

                luuHoaDonChoDangChon();
                return true;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi tìm khách hàng: " + e.getMessage());
            return false;
        }

        pendingKhachId = null;
        confirmedKhachId = null;

        if (showNotFoundMessage) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy khách hàng!");
        }
        return false;
    }

    public void setKhachHangDuocChon(KhachHang kh) {
        if (kh == null) {
            return;
        }

        pendingKhachId = kh.getId();
        confirmedKhachId = null;

        txtMaKhachHang.setText(kh.getMaKH());
        txtTenKhachHang.setText(kh.getTenKH());
        txtDienThoaiKhachTab2.setText(kh.getSdt());

        txtXacNhanMa.setText("");
        txtXacNhanTen.setText("");
        txtXacNhanSDT.setText("");

        luuHoaDonChoDangChon();
    }

    private void chonKhachHangTuBang() {
        KhachHangManagerJDialog dialog = new KhachHangManagerJDialog((java.awt.Frame) this.getOwner(), true);
        dialog.setBanHangForm(this);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private BigDecimal parseMoneyInput(String text) {
        if (text == null) {
            return BigDecimal.ZERO;
        }

        String cleaned = text.replace("đ", "")
                .replace(",", "")
                .replace(".", "")
                .trim();

        if (cleaned.isEmpty()) {
            return BigDecimal.ZERO;
        }

        return new BigDecimal(cleaned);
    }

    private boolean isThanhToanTienMat() {
        Object selected = cboThanhToanTab2.getSelectedItem();
        if (selected == null) {
            return false;
        }

        String hinhThuc = selected.toString().trim();
        return hinhThuc.equalsIgnoreCase("Tiền mặt");
    }

    private void capNhatTrangThaiTienMat() {
        boolean tienMat = isThanhToanTienMat();
        txtTienKhachDua.setEditable(tienMat);

        if (!tienMat) {
            txtTienKhachDua.setText(txtThanhTienThanhToan.getText().trim());
        }

        tinhTienThua();
    }

    private void tinhTienThua() {
        BigDecimal thanhTien = parseMoney(txtThanhTienThanhToan.getText());
        BigDecimal tienKhachDua = parseMoneyInput(txtTienKhachDua.getText());

        if (!isThanhToanTienMat()) {
            txtTienThua.setText(formatMoney(BigDecimal.ZERO));
            return;
        }

        BigDecimal tienThua = tienKhachDua.subtract(thanhTien);
        if (tienThua.compareTo(BigDecimal.ZERO) < 0) {
            txtTienThua.setText("Khách đưa chưa đủ");
        } else {
            txtTienThua.setText(formatMoney(tienThua));
        }
    }

    private int getTonKhoThucTeByMa(String maSpct) {
        try {
            Object value = XJdbc.getValue("""
            SELECT so_luong
            FROM san_pham_chi_tiet
            WHERE ma_sp_chi_tiet = ?
        """, maSpct);

            return value == null ? 0 : Integer.parseInt(value.toString());
        } catch (Exception e) {
            return 0;
        }
    }

    private void dongBoGioHangTheoTonKhoThucTe() {
        boolean changed = false;

        for (int i = gioHangList.size() - 1; i >= 0; i--) {
            GioHangItem item = gioHangList.get(i);
            int tonThucTe = getTonKhoThucTeByMa(item.maSpct);

            if (tonThucTe <= 0) {
                gioHangList.remove(i);
                changed = true;
            } else if (item.soLuong > tonThucTe) {
                item.soLuong = tonThucTe;
                changed = true;
            }
        }

        if (changed) {
            renderGioHang();
            tinhTien();
            capNhatTonKhoHienThiTheoGioHang();
            luuHoaDonChoDangChon();
            JOptionPane.showMessageDialog(this,
                    "Giỏ hàng đã được cập nhật lại theo tồn kho thực tế.");
        }
    }

    private void dongBoTatCaHoaDonChoTheoTonKho() {
        for (HoaDonChoSnapshot snap : dsHoaDonCho) {
            for (int i = snap.gioHangSnapshot.size() - 1; i >= 0; i--) {
                GioHangItem item = snap.gioHangSnapshot.get(i);
                int tonThucTe = getTonKhoThucTeByMa(item.maSpct);

                // chỉ cắt theo tồn DB, không xét giữ chỗ ở đây
                if (tonThucTe <= 0) {
                    snap.gioHangSnapshot.remove(i);
                } else if (item.soLuong > tonThucTe) {
                    item.soLuong = tonThucTe;
                }
            }
        }
    }

    private int getSoLuongDaGiuOHoaDonChoKhac(String maSpct) {
        int tong = 0;
        for (int i = 0; i < dsHoaDonCho.size(); i++) {
            if (i == currentHoaDonChoIndex) {
                continue;
            }
            HoaDonChoSnapshot snap = dsHoaDonCho.get(i);
            for (GioHangItem item : snap.gioHangSnapshot) {
                if (item.maSpct.equalsIgnoreCase(maSpct)) {
                    tong += item.soLuong;
                }
            }
        }
        return tong;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        pnlMain = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        SanPham3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        pnlThongTinHoaDon3 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        txtMaHoaDon2 = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        txtNhanVien2 = new javax.swing.JTextField();
        txtThoiGian2 = new javax.swing.JTextField();
        rdoChoThanhToan2 = new javax.swing.JRadioButton();
        rdoDaThanhToan2 = new javax.swing.JRadioButton();
        btnHuyHoaDon2 = new javax.swing.JButton();
        btnSuaHoaDon2 = new javax.swing.JButton();
        btnTaoHoaDon = new javax.swing.JButton();
        jLabel46 = new javax.swing.JLabel();
        cboHoaDonCho = new javax.swing.JComboBox<>();
        btnXemHoaDon = new javax.swing.JButton();
        pnlSanPham1 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        txtTimSanPham = new javax.swing.JTextField();
        btnTim = new javax.swing.JButton();
        jLabel38 = new javax.swing.JLabel();
        cboDanhMuc = new javax.swing.JComboBox<>();
        jLabel39 = new javax.swing.JLabel();
        cboMauSac = new javax.swing.JComboBox<>();
        jLabel40 = new javax.swing.JLabel();
        cboKichThuoc = new javax.swing.JComboBox<>();
        jLabel41 = new javax.swing.JLabel();
        txtSoLuong = new javax.swing.JTextField();
        scrSanPham = new javax.swing.JScrollPane();
        tblSanPham = new javax.swing.JTable();
        btnThemVaoGio = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        txtTongTien = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        txtTienGiam = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        txtThanhTien = new javax.swing.JTextField();
        scrGioHang1 = new javax.swing.JScrollPane();
        tblGioHang = new javax.swing.JTable();
        btnSangThanhToan = new javax.swing.JButton();
        btnLamMoiGioHang = new javax.swing.JButton();
        btnSuaGioHang = new javax.swing.JButton();
        btnXoaGioHang = new javax.swing.JButton();
        jLabel50 = new javax.swing.JLabel();
        cboThanhToanTab2 = new javax.swing.JComboBox<>();
        jLabel51 = new javax.swing.JLabel();
        cboPhieuGiamGiaTab2 = new javax.swing.JComboBox<>();
        XacNhanKhach = new javax.swing.JPanel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        txtXacNhanMa = new javax.swing.JTextField();
        jLabel59 = new javax.swing.JLabel();
        txtXacNhanTen = new javax.swing.JTextField();
        jLabel60 = new javax.swing.JLabel();
        txtXacNhanSDT = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        btnThemtab2 = new javax.swing.JButton();
        jLabel49 = new javax.swing.JLabel();
        txtDienThoaiKhachTab2 = new javax.swing.JTextField();
        btnLamMoitab2 = new javax.swing.JButton();
        btnXacNhanKhach = new javax.swing.JButton();
        txtTenKhachHang = new javax.swing.JTextField();
        btnTimKhach = new javax.swing.JButton();
        jLabel52 = new javax.swing.JLabel();
        txtMaKhachHang = new javax.swing.JTextField();
        btnChonKhach = new javax.swing.JButton();
        pnlTongTien2 = new javax.swing.JPanel();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        txtTongTienThanhToan2 = new javax.swing.JTextField();
        txtTienGiamThanhToan = new javax.swing.JTextField();
        jLabel56 = new javax.swing.JLabel();
        txtThanhTienThanhToan = new javax.swing.JTextField();
        btnLamMoi = new javax.swing.JButton();
        btnQuayLaiSanPham = new javax.swing.JButton();
        btnThanhToan = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        txtTienKhachDua = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtTienThua = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        SanPham3.setPreferredSize(new java.awt.Dimension(2500, 2600));

        pnlThongTinHoaDon3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel32.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel32.setText("Thông tin hóa đơn");

        jLabel33.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel33.setText("Mã hóa đơn");

        jLabel34.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel34.setText("Nhân viên");

        jLabel35.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel35.setText("Thời gian tạo ");

        jLabel36.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel36.setText("Trạng thái");

        buttonGroup1.add(rdoChoThanhToan2);
        rdoChoThanhToan2.setText("Chờ thanh toán");

        buttonGroup1.add(rdoDaThanhToan2);
        rdoDaThanhToan2.setText("Đã thanh toán");

        btnHuyHoaDon2.setText("HỦY HĐ");
        btnHuyHoaDon2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHuyHoaDonActionPerformed(evt);
            }
        });

        btnSuaHoaDon2.setText("SỬA HĐ");
        btnSuaHoaDon2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaHoaDonActionPerformed(evt);
            }
        });

        btnTaoHoaDon.setBackground(new java.awt.Color(51, 153, 0));
        btnTaoHoaDon.setForeground(new java.awt.Color(255, 255, 255));
        btnTaoHoaDon.setText("Tạo HĐ");
        btnTaoHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTaoHoaDonActionPerformed(evt);
            }
        });

        jLabel46.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel46.setText("Hóa đơn chờ");

        cboHoaDonCho.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnXemHoaDon.setText("Xem hóa đơn");
        btnXemHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXemHoaDonActionPerformed(evt);
            }
        });

        pnlSanPham1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel26.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel26.setText("Danh sách sản phẩm");

        jLabel37.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel37.setText("Tìm sản phẩm");

        btnTim.setText("Tìm");

        jLabel38.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel38.setText("Danh mục");

        cboDanhMuc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel39.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel39.setText("Màu sắc");

        cboMauSac.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel40.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel40.setText("Size");

        cboKichThuoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel41.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel41.setText("Số lượng");

        tblSanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Mã SPCT", "Tên SP", "Màu", "Size", "Đơn giá", "Tồn kho"
            }
        ));
        scrSanPham.setViewportView(tblSanPham);

        btnThemVaoGio.setBackground(new java.awt.Color(0, 153, 0));
        btnThemVaoGio.setForeground(new java.awt.Color(255, 255, 255));
        btnThemVaoGio.setText("Thêm vào giỏ");

        javax.swing.GroupLayout pnlSanPham1Layout = new javax.swing.GroupLayout(pnlSanPham1);
        pnlSanPham1.setLayout(pnlSanPham1Layout);
        pnlSanPham1Layout.setHorizontalGroup(
            pnlSanPham1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSanPham1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlSanPham1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlSanPham1Layout.createSequentialGroup()
                        .addGroup(pnlSanPham1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlSanPham1Layout.createSequentialGroup()
                                .addGroup(pnlSanPham1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlSanPham1Layout.createSequentialGroup()
                                        .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cboKichThuoc, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlSanPham1Layout.createSequentialGroup()
                                        .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cboDanhMuc, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(33, 33, 33)
                                .addGroup(pnlSanPham1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(pnlSanPham1Layout.createSequentialGroup()
                                        .addComponent(jLabel39)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(cboMauSac, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pnlSanPham1Layout.createSequentialGroup()
                                        .addComponent(jLabel41)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtSoLuong))))
                            .addGroup(pnlSanPham1Layout.createSequentialGroup()
                                .addComponent(jLabel37)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtTimSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnTim))
                            .addComponent(scrSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnlSanPham1Layout.createSequentialGroup()
                        .addComponent(jLabel26)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnThemVaoGio)
                        .addGap(53, 53, 53))))
        );
        pnlSanPham1Layout.setVerticalGroup(
            pnlSanPham1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSanPham1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlSanPham1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(btnThemVaoGio))
                .addGap(18, 18, 18)
                .addGroup(pnlSanPham1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(txtTimSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTim))
                .addGap(18, 18, 18)
                .addGroup(pnlSanPham1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel38)
                    .addComponent(cboDanhMuc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel39)
                    .addComponent(cboMauSac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(pnlSanPham1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel40)
                    .addComponent(cboKichThuoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel41)
                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52)
                .addComponent(scrSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel42.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel42.setText("Giỏ hàng");

        jLabel43.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel43.setText("Tổng tiền");

        jLabel44.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel44.setText("Tiền giảm");

        jLabel45.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel45.setText("Thành tiền");

        tblGioHang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã SPCT", "Tên SP", "Màu sắc", "Size", "Số lượng", "Đơn giá", "Thành tiền"
            }
        ));
        scrGioHang1.setViewportView(tblGioHang);

        btnSangThanhToan.setText("Tiếp tục thanh toán");

        btnLamMoiGioHang.setText("Làm mới");
        btnLamMoiGioHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiGioHangActionPerformed(evt);
            }
        });

        btnSuaGioHang.setText("Sửa");
        btnSuaGioHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaGioHangActionPerformed(evt);
            }
        });

        btnXoaGioHang.setText("Xóa");
        btnXoaGioHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaGioHangActionPerformed(evt);
            }
        });

        jLabel50.setText("Thanh toán");

        cboThanhToanTab2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel51.setText("Phiếu giảm giá");

        cboPhieuGiamGiaTab2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrGioHang1)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(64, 64, 64)
                                        .addComponent(btnLamMoiGioHang, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(28, 28, 28)
                                        .addComponent(btnSuaGioHang))
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(23, 23, 23)
                                        .addComponent(txtThanhTien, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(36, 36, 36)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSangThanhToan)
                                    .addComponent(btnXoaGioHang)))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel43)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel44)
                                        .addGap(28, 28, 28)
                                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(txtTongTien, javax.swing.GroupLayout.DEFAULT_SIZE, 142, Short.MAX_VALUE)
                                            .addComponent(txtTienGiam))))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(15, 15, 15)
                                        .addComponent(cboThanhToanTab2, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel51)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(cboPhieuGiamGiaTab2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel42)
                    .addComponent(btnLamMoiGioHang)
                    .addComponent(btnSuaGioHang)
                    .addComponent(btnXoaGioHang))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel43)
                    .addComponent(txtTongTien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel50)
                    .addComponent(cboThanhToanTab2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel44)
                    .addComponent(txtTienGiam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel51)
                    .addComponent(cboPhieuGiamGiaTab2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel45)
                    .addComponent(txtThanhTien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSangThanhToan))
                .addGap(18, 18, 18)
                .addComponent(scrGioHang1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(49, Short.MAX_VALUE))
        );

        XacNhanKhach.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel57.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel57.setText("XÁC NHẬN KHÁCH HÀNG");

        jLabel58.setText("MÃ");

        jLabel59.setText("TÊN");

        jLabel60.setText("SĐT");

        javax.swing.GroupLayout XacNhanKhachLayout = new javax.swing.GroupLayout(XacNhanKhach);
        XacNhanKhach.setLayout(XacNhanKhachLayout);
        XacNhanKhachLayout.setHorizontalGroup(
            XacNhanKhachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(XacNhanKhachLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(XacNhanKhachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(XacNhanKhachLayout.createSequentialGroup()
                        .addComponent(jLabel60, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtXacNhanSDT))
                    .addGroup(XacNhanKhachLayout.createSequentialGroup()
                        .addComponent(jLabel59, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtXacNhanTen))
                    .addGroup(XacNhanKhachLayout.createSequentialGroup()
                        .addComponent(jLabel58, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtXacNhanMa, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel57))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        XacNhanKhachLayout.setVerticalGroup(
            XacNhanKhachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(XacNhanKhachLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel57)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(XacNhanKhachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel58)
                    .addComponent(txtXacNhanMa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(XacNhanKhachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel59)
                    .addComponent(txtXacNhanTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(XacNhanKhachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel60)
                    .addComponent(txtXacNhanSDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel47.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel47.setText("Thông tin đơn đang xử lý");

        jLabel48.setText("Khách hàng");

        btnThemtab2.setBackground(new java.awt.Color(0, 153, 0));
        btnThemtab2.setForeground(new java.awt.Color(255, 255, 255));
        btnThemtab2.setText("Thêm");
        btnThemtab2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemtab2ActionPerformed(evt);
            }
        });

        jLabel49.setText("Điện thoại");

        btnLamMoitab2.setBackground(new java.awt.Color(204, 102, 0));
        btnLamMoitab2.setForeground(new java.awt.Color(255, 255, 255));
        btnLamMoitab2.setText("Làm mới");
        btnLamMoitab2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoitab2ActionPerformed(evt);
            }
        });

        btnXacNhanKhach.setBackground(new java.awt.Color(0, 0, 153));
        btnXacNhanKhach.setForeground(new java.awt.Color(255, 255, 255));
        btnXacNhanKhach.setText("Xác nhận");
        btnXacNhanKhach.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXacNhanKhachActionPerformed(evt);
            }
        });

        btnTimKhach.setText("Tìm khách");

        jLabel52.setText("Mã khách hàng");

        btnChonKhach.setText("Chọn");
        btnChonKhach.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChonKhachActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel47)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel48)
                            .addComponent(jLabel49)
                            .addComponent(jLabel52))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDienThoaiKhachTab2, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtTenKhachHang, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtMaKhachHang, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(41, 41, 41)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnXacNhanKhach)
                            .addComponent(btnThemtab2, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(btnChonKhach)
                                .addGap(10, 10, 10)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnTimKhach, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLamMoitab2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel47)
                    .addComponent(btnXacNhanKhach)
                    .addComponent(btnLamMoitab2))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel52)
                    .addComponent(txtMaKhachHang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnThemtab2)
                    .addComponent(btnTimKhach))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(btnChonKhach)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtDienThoaiKhachTab2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel49)))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel48)
                            .addComponent(txtTenKhachHang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlTongTien2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel53.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel53.setText("THANH TOÁN");

        jLabel54.setText("Tổng tiền");

        jLabel55.setText("Tiền giảm");

        txtTienGiamThanhToan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTienGiamThanhToanActionPerformed(evt);
            }
        });

        jLabel56.setText("Tổng thanh toán");

        txtThanhTienThanhToan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtThanhTienThanhToanActionPerformed(evt);
            }
        });

        btnLamMoi.setBackground(new java.awt.Color(0, 51, 204));
        btnLamMoi.setForeground(new java.awt.Color(255, 255, 255));
        btnLamMoi.setText("LÀM MỚI");

        btnQuayLaiSanPham.setBackground(new java.awt.Color(204, 102, 0));
        btnQuayLaiSanPham.setForeground(new java.awt.Color(255, 255, 255));
        btnQuayLaiSanPham.setText("CHỌN LẠI SẢN PHẨM");

        btnThanhToan.setBackground(new java.awt.Color(51, 204, 0));
        btnThanhToan.setForeground(new java.awt.Color(255, 255, 255));
        btnThanhToan.setText("THANH TOÁN");

        jLabel3.setText("Tiền khách đưa");

        jLabel4.setText("Tiền thừa");

        javax.swing.GroupLayout pnlTongTien2Layout = new javax.swing.GroupLayout(pnlTongTien2);
        pnlTongTien2.setLayout(pnlTongTien2Layout);
        pnlTongTien2Layout.setHorizontalGroup(
            pnlTongTien2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTongTien2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTongTien2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTongTien2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtTienKhachDua, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(txtTienThua, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnlTongTien2Layout.createSequentialGroup()
                        .addGroup(pnlTongTien2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlTongTien2Layout.createSequentialGroup()
                                .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnLamMoi)
                                .addGap(18, 18, 18)
                                .addComponent(btnQuayLaiSanPham)
                                .addGap(18, 18, 18)
                                .addComponent(btnThanhToan))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlTongTien2Layout.createSequentialGroup()
                                .addComponent(jLabel55)
                                .addGap(29, 29, 29)
                                .addComponent(txtTienGiamThanhToan, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel56)
                                .addGap(18, 18, 18)
                                .addComponent(txtThanhTienThanhToan, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnlTongTien2Layout.createSequentialGroup()
                        .addComponent(jLabel54, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtTongTienThanhToan2, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        pnlTongTien2Layout.setVerticalGroup(
            pnlTongTien2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTongTien2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTongTien2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel53)
                    .addGroup(pnlTongTien2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLamMoi)
                        .addComponent(btnQuayLaiSanPham)
                        .addComponent(btnThanhToan)))
                .addGap(18, 18, 18)
                .addGroup(pnlTongTien2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel54)
                    .addComponent(txtTongTienThanhToan2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(pnlTongTien2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel55)
                    .addComponent(txtTienGiamThanhToan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel56)
                    .addComponent(txtThanhTienThanhToan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(pnlTongTien2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtTienKhachDua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(txtTienThua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnlThongTinHoaDon3Layout = new javax.swing.GroupLayout(pnlThongTinHoaDon3);
        pnlThongTinHoaDon3.setLayout(pnlThongTinHoaDon3Layout);
        pnlThongTinHoaDon3Layout.setHorizontalGroup(
            pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinHoaDon3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(XacNhanKhach, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(pnlSanPham1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(pnlThongTinHoaDon3Layout.createSequentialGroup()
                            .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel34)
                                .addComponent(jLabel33)
                                .addComponent(jLabel36))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtMaHoaDon2, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtThoiGian2, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtNhanVien2, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(pnlThongTinHoaDon3Layout.createSequentialGroup()
                                    .addComponent(rdoChoThanhToan2)
                                    .addGap(28, 28, 28)
                                    .addComponent(rdoDaThanhToan2)))))
                    .addGroup(pnlThongTinHoaDon3Layout.createSequentialGroup()
                        .addComponent(btnTaoHoaDon)
                        .addGap(21, 21, 21)
                        .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cboHoaDonCho, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnXemHoaDon))
                    .addGroup(pnlThongTinHoaDon3Layout.createSequentialGroup()
                        .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(btnHuyHoaDon2)
                        .addGap(51, 51, 51)
                        .addComponent(btnSuaHoaDon2)))
                .addGap(36, 36, 36)
                .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(pnlTongTien2, javax.swing.GroupLayout.PREFERRED_SIZE, 536, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(543, Short.MAX_VALUE))
        );
        pnlThongTinHoaDon3Layout.setVerticalGroup(
            pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinHoaDon3Layout.createSequentialGroup()
                .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlThongTinHoaDon3Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnTaoHoaDon)
                            .addComponent(jLabel46)
                            .addComponent(cboHoaDonCho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnXemHoaDon))
                        .addGap(18, 18, 18)
                        .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel32)
                            .addComponent(btnHuyHoaDon2)
                            .addComponent(btnSuaHoaDon2))
                        .addGap(18, 18, 18)
                        .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel33)
                            .addComponent(txtMaHoaDon2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel34)
                            .addComponent(txtNhanVien2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlThongTinHoaDon3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlThongTinHoaDon3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtThoiGian2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel35))
                        .addGap(15, 15, 15)
                        .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlThongTinHoaDon3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel36)
                                .addComponent(rdoChoThanhToan2))
                            .addGroup(pnlThongTinHoaDon3Layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(rdoDaThanhToan2)))
                        .addGap(18, 18, 18)
                        .addComponent(pnlSanPham1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(XacNhanKhach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlThongTinHoaDon3Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(pnlTongTien2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 1067, Short.MAX_VALUE))
        );

        jScrollPane2.setViewportView(pnlThongTinHoaDon3);

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel2.setText("THI CÔNG XONG!!!");

        javax.swing.GroupLayout SanPham3Layout = new javax.swing.GroupLayout(SanPham3);
        SanPham3.setLayout(SanPham3Layout);
        SanPham3Layout.setHorizontalGroup(
            SanPham3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SanPham3Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jLabel2)
                .addGap(61, 61, 61)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(1126, Short.MAX_VALUE))
        );
        SanPham3Layout.setVerticalGroup(
            SanPham3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SanPham3Layout.createSequentialGroup()
                .addGroup(SanPham3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SanPham3Layout.createSequentialGroup()
                        .addGap(185, 185, 185)
                        .addComponent(jLabel2))
                    .addGroup(SanPham3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 842, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(1745, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("SẢN PHẨM", SanPham3);

        javax.swing.GroupLayout pnlMainLayout = new javax.swing.GroupLayout(pnlMain);
        pnlMain.setLayout(pnlMainLayout);
        pnlMainLayout.setHorizontalGroup(
            pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMainLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlMainLayout.setVerticalGroup(
            pnlMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMainLayout.createSequentialGroup()
                .addGap(0, 2, Short.MAX_VALUE)
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 2, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMain, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMain, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtThanhTienThanhToanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtThanhTienThanhToanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtThanhTienThanhToanActionPerformed

    private void txtTienGiamThanhToanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTienGiamThanhToanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTienGiamThanhToanActionPerformed

    private void btnXacNhanKhachActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXacNhanKhachActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnXacNhanKhachActionPerformed

    private void btnLamMoitab2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoitab2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnLamMoitab2ActionPerformed

    private void btnThemtab2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemtab2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnThemtab2ActionPerformed

    private void btnXemHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXemHoaDonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnXemHoaDonActionPerformed

    private void btnTaoHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTaoHoaDonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnTaoHoaDonActionPerformed

    private void btnXoaGioHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaGioHangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnXoaGioHangActionPerformed

    private void btnSuaGioHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaGioHangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSuaGioHangActionPerformed

    private void btnLamMoiGioHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiGioHangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnLamMoiGioHangActionPerformed

    private void btnSuaHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaHoaDonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSuaHoaDonActionPerformed

    private void btnHuyHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHuyHoaDonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnHuyHoaDonActionPerformed

    private void btnChonKhachActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChonKhachActionPerformed
        KhachHangManagerJDialog dialog = new KhachHangManagerJDialog((java.awt.Frame) this.getOwner(), true);
        dialog.setBanHangForm(this);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }//GEN-LAST:event_btnChonKhachActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BanHangJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BanHangJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BanHangJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BanHangJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                BanHangJDialog dialog = new BanHangJDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel SanPham3;
    private javax.swing.JPanel XacNhanKhach;
    private javax.swing.JButton btnChonKhach;
    private javax.swing.JButton btnHuyHoaDon2;
    private javax.swing.JButton btnLamMoi;
    private javax.swing.JButton btnLamMoiGioHang;
    private javax.swing.JButton btnLamMoitab2;
    private javax.swing.JButton btnQuayLaiSanPham;
    private javax.swing.JButton btnSangThanhToan;
    private javax.swing.JButton btnSuaGioHang;
    private javax.swing.JButton btnSuaHoaDon2;
    private javax.swing.JButton btnTaoHoaDon;
    private javax.swing.JButton btnThanhToan;
    private javax.swing.JButton btnThemVaoGio;
    private javax.swing.JButton btnThemtab2;
    private javax.swing.JButton btnTim;
    private javax.swing.JButton btnTimKhach;
    private javax.swing.JButton btnXacNhanKhach;
    private javax.swing.JButton btnXemHoaDon;
    private javax.swing.JButton btnXoaGioHang;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cboDanhMuc;
    private javax.swing.JComboBox<String> cboHoaDonCho;
    private javax.swing.JComboBox<String> cboKichThuoc;
    private javax.swing.JComboBox<String> cboMauSac;
    private javax.swing.JComboBox<String> cboPhieuGiamGiaTab2;
    private javax.swing.JComboBox<String> cboThanhToanTab2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JPanel pnlMain;
    private javax.swing.JPanel pnlSanPham1;
    private javax.swing.JPanel pnlThongTinHoaDon3;
    private javax.swing.JPanel pnlTongTien2;
    private javax.swing.JRadioButton rdoChoThanhToan2;
    private javax.swing.JRadioButton rdoDaThanhToan2;
    private javax.swing.JScrollPane scrGioHang1;
    private javax.swing.JScrollPane scrSanPham;
    private javax.swing.JTable tblGioHang;
    private javax.swing.JTable tblSanPham;
    private javax.swing.JTextField txtDienThoaiKhachTab2;
    private javax.swing.JTextField txtMaHoaDon2;
    private javax.swing.JTextField txtMaKhachHang;
    private javax.swing.JTextField txtNhanVien2;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtTenKhachHang;
    private javax.swing.JTextField txtThanhTien;
    private javax.swing.JTextField txtThanhTienThanhToan;
    private javax.swing.JTextField txtThoiGian2;
    private javax.swing.JTextField txtTienGiam;
    private javax.swing.JTextField txtTienGiamThanhToan;
    private javax.swing.JTextField txtTienKhachDua;
    private javax.swing.JTextField txtTienThua;
    private javax.swing.JTextField txtTimSanPham;
    private javax.swing.JTextField txtTongTien;
    private javax.swing.JTextField txtTongTienThanhToan2;
    private javax.swing.JTextField txtXacNhanMa;
    private javax.swing.JTextField txtXacNhanSDT;
    private javax.swing.JTextField txtXacNhanTen;
    // End of variables declaration//GEN-END:variables
}
