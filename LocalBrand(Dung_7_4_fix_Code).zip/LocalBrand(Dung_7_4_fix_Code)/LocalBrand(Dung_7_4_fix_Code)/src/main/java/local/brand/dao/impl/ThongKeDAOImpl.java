package local.brand.dao.impl;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import local.brand.dao.ThongKeDAO;
import local.brand.ulti.XJdbc;

public class ThongKeDAOImpl implements ThongKeDAO {

    @Override
    public List<Object[]> getDoanhThuTheoNam(int nam) {
        // SỬA: HoaDon -> hoa_don, NgayTao -> thoi_gian_mua, TongTien -> thanh_tien
        String sql = "SELECT MONTH(thoi_gian_mua) AS Thang, SUM(thanh_tien) AS DoanhThu "
                + "FROM hoa_don "
                + "WHERE YEAR(thoi_gian_mua) = ? AND trang_thai = 1 "
                + "GROUP BY MONTH(thoi_gian_mua) "
                + "ORDER BY Thang ASC";
        List<Object[]> list = new ArrayList<>();
        try (ResultSet rs = XJdbc.query(sql, nam)) {
            while (rs.next()) {
                list.add(new Object[]{rs.getInt("Thang"), rs.getDouble("DoanhThu")});
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Object[]> getDoanhThuTheoKhoangNgay(java.util.Date tuNgay, java.util.Date denNgay) {
        // KIỂM TRA NULL TRƯỚC KHI XỬ LÝ
        if (tuNgay == null || denNgay == null) {
            return new ArrayList<>();
        }

        String sql = "SELECT CAST(thoi_gian_mua AS DATE) AS Ngay, SUM(thanh_tien) AS DoanhThu "
                + "FROM hoa_don "
                + "WHERE trang_thai = 1 AND CAST(thoi_gian_mua AS DATE) BETWEEN ? AND ? "
                + "GROUP BY CAST(thoi_gian_mua AS DATE) "
                + "ORDER BY Ngay ASC";
        List<Object[]> list = new ArrayList<>();

        // Sử dụng try-with-resources để tự động đóng ResultSet
        try (ResultSet rs = XJdbc.query(sql, new java.sql.Date(tuNgay.getTime()), new java.sql.Date(denNgay.getTime()))) {
            while (rs.next()) {
                list.add(new Object[]{rs.getDate("Ngay"), rs.getDouble("DoanhThu")});
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Object[]> getDoanhThuCacNgayTrongThang(int thang, int nam) {
        // Hàm này gọi Store Procedure Dũng đã tạo trong SQL
        String sql = "{CALL sp_ThongKeDoanhThuTheoThang(?, ?)}";
        List<Object[]> list = new ArrayList<>();
        try (ResultSet rs = XJdbc.query(sql, thang, nam)) {
            while (rs.next()) {
                list.add(new Object[]{rs.getDate("Ngay"), rs.getDouble("DoanhThu")});
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Object[]> getDoanhThuTheoThang(int thang, int nam) {
        // SỬA: HoaDon -> hoa_don, NgayTao -> thoi_gian_mua, TongTien -> thanh_tien
        String sql = "SELECT DAY(thoi_gian_mua) as Ngay, SUM(thanh_tien) as DoanhThu "
                + "FROM hoa_don "
                + "WHERE MONTH(thoi_gian_mua) = ? AND YEAR(thoi_gian_mua) = ? AND trang_thai = 1 "
                + "GROUP BY DAY(thoi_gian_mua) "
                + "ORDER BY Ngay ASC";
        List<Object[]> list = new ArrayList<>();
        try (ResultSet rs = XJdbc.query(sql, thang, nam)) {
            while (rs.next()) {
                list.add(new Object[]{rs.getInt("Ngay"), rs.getDouble("DoanhThu")});
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Object[] getSummaryByMonth(int thang, int nam) {
        // Để an toàn, SQL nên dùng COALESCE hoặc ISNULL để tránh trả về NULL
        String sql = "SELECT COALESCE(SUM(thanh_tien), 0) AS DoanhThu, "
                + "COUNT(id) AS TongDon, "
                + "SUM(CASE WHEN trang_thai = 1 THEN 1 ELSE 0 END) AS ThanhCong, "
                + "SUM(CASE WHEN trang_thai = 0 THEN 1 ELSE 0 END) AS Huy "
                + "FROM hoa_don "
                + "WHERE MONTH(thoi_gian_mua) = ? AND YEAR(thoi_gian_mua) = ?";

        try (ResultSet rs = XJdbc.query(sql, thang, nam)) { // Đã bỏ +1, hãy cộng ở UI
            if (rs.next()) {
                return new Object[]{
                    rs.getDouble("DoanhThu"),
                    rs.getInt("TongDon"),
                    rs.getInt("ThanhCong"),
                    rs.getInt("Huy")
                };
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new Object[]{0.0, 0, 0, 0};
    }

    @Override
    public Object[] getSummaryData(Integer nam, java.util.Date tuNgay, java.util.Date denNgay) {
        String sql = "SELECT COALESCE(SUM(thanh_tien), 0) AS DoanhThu, COUNT(id) AS TongDon, "
                + "SUM(CASE WHEN trang_thai = 1 THEN 1 ELSE 0 END) AS ThanhCong, "
                + "SUM(CASE WHEN trang_thai = 0 THEN 1 ELSE 0 END) AS Huy "
                + "FROM hoa_don WHERE 1=1 ";

        try {
            ResultSet rs = null;
            if (nam != null) {
                sql += " AND YEAR(thoi_gian_mua) = ?";
                rs = XJdbc.query(sql, nam);
            } else {
                // KIỂM TRA NULL CHO KHOẢNG NGÀY
                if (tuNgay == null || denNgay == null) {
                    return new Object[]{0.0, 0, 0, 0};
                }
                sql += " AND CAST(thoi_gian_mua AS DATE) BETWEEN ? AND ?";
                rs = XJdbc.query(sql, new java.sql.Date(tuNgay.getTime()), new java.sql.Date(denNgay.getTime()));
            }

            if (rs != null && rs.next()) {
                Object[] data = new Object[]{
                    rs.getDouble("DoanhThu"), rs.getInt("TongDon"),
                    rs.getInt("ThanhCong"), rs.getInt("Huy")
                };
                rs.close();
                return data;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new Object[]{0.0, 0, 0, 0};
    }

    // Trong ThongKeDAOImpl.java
    // Trong ThongKeDAOImpl.java
// Trong ThongKeDAOImpl.java
    @Override
    public List<Object[]> getDoanhThuTheo24Gio(Date ngay) {
        // Sửa tên bảng/cột cho khớp với database: hoa_don, thoi_gian_mua, thanh_tien
        String sql = "SELECT DATEPART(HOUR, thoi_gian_mua) as Gio, SUM(thanh_tien) as DoanhThu "
                + "FROM hoa_don "
                + "WHERE CAST(thoi_gian_mua AS DATE) = ? AND trang_thai = 1 "
                + "GROUP BY DATEPART(HOUR, thoi_gian_mua) "
                + "ORDER BY Gio ASC";

        List<Object[]> list = new ArrayList<>();
        try (java.sql.ResultSet rs = XJdbc.query(sql, new java.sql.Date(ngay.getTime()))) {
            while (rs.next()) {
                list.add(new Object[]{
                    rs.getInt("Gio"),
                    rs.getDouble("DoanhThu")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Object[] getPaymentMethodSummary(Date tuNgay, Date denNgay) {
        if (tuNgay == null || denNgay == null) {
            return new Object[]{0.0, 0.0};
        }

        String sql = "SELECT "
                + "COALESCE(SUM(CASE WHEN id_hinh_thuc = 1 THEN thanh_tien ELSE 0 END), 0) AS TienMat, "
                + "COALESCE(SUM(CASE WHEN id_hinh_thuc = 2 THEN thanh_tien ELSE 0 END), 0) AS ChuyenKhoan "
                + "FROM hoa_don "
                + "WHERE trang_thai = 1 AND CAST(thoi_gian_mua AS DATE) BETWEEN ? AND ?";

        try (ResultSet rs = XJdbc.query(sql, new java.sql.Date(tuNgay.getTime()), new java.sql.Date(denNgay.getTime()))) {
            if (rs.next()) {
                return new Object[]{
                    rs.getDouble("TienMat"),
                    rs.getDouble("ChuyenKhoan")
                };
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new Object[]{0.0, 0.0};
    }

    @Override
    public List<Object[]> getTopSellingProducts(Date tuNgay, Date denNgay, int limit) {
        List<Object[]> list = new ArrayList<>();
        if (tuNgay == null || denNgay == null || limit <= 0) {
            return list;
        }

        String sql = "SELECT TOP (?) "
                + "sp.ten_san_pham AS TenSanPham, "
                + "SUM(hdct.so_luong) AS SoLuongBan, "
                + "SUM(hdct.so_luong * hdct.don_gia) AS DoanhThu "
                + "FROM hoa_don_chi_tiet hdct "
                + "JOIN hoa_don hd ON hdct.id_hoa_don = hd.id "
                + "JOIN san_pham_chi_tiet spct ON hdct.id_san_pham_chi_tiet = spct.id "
                + "JOIN san_pham sp ON spct.id_san_pham = sp.id "
                + "WHERE hd.trang_thai = 1 AND CAST(hd.thoi_gian_mua AS DATE) BETWEEN ? AND ? "
                + "GROUP BY sp.ten_san_pham "
                + "ORDER BY SoLuongBan DESC, DoanhThu DESC";

        try (ResultSet rs = XJdbc.query(sql, limit, new java.sql.Date(tuNgay.getTime()), new java.sql.Date(denNgay.getTime()))) {
            while (rs.next()) {
                list.add(new Object[]{
                    rs.getString("TenSanPham"),
                    rs.getInt("SoLuongBan"),
                    rs.getDouble("DoanhThu")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

}
