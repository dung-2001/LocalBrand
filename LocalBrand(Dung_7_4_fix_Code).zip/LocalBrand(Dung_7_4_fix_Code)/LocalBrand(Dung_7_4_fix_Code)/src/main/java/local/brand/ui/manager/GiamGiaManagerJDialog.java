/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package local.brand.ui.manager;

import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import local.brand.entity.DotGiamGia;

/**
 *
 * @author ASUS
 */
public class GiamGiaManagerJDialog extends javax.swing.JDialog {

    private final local.brand.dao.DotGiamGiaDAO dotGiamGiaDAO = new local.brand.dao.impl.DotGiamGiaDAOImpl();
    @SuppressWarnings("FieldNameHidesFieldInSuperclass")
    private DefaultTableModel model;
    private int selectedId = -1;

    public GiamGiaManagerJDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initFormData();
    }

    public GiamGiaManagerJDialog(java.awt.Dialog parent, boolean modal) {
        super(parent, modal);
        initFormData();
    }

    private void initFormData() {
        initComponents();
        model = (DefaultTableModel) tblDotGiamGia.getModel();
        initForm();
    }

    private void initForm() {
        txtId.setEditable(false);
        loadTable();
        clearForm();
    }

    private void loadTable() {
        model.setRowCount(0);

        for (DotGiamGia dgg : dotGiamGiaDAO.selectAll()) {
            model.addRow(new Object[]{
                dgg.getId(),
                dgg.getMaDotGiam(),
                dgg.getTenDotGiam(),
                formatDate(dgg.getNgayBatDau()),
                formatDate(dgg.getNgayKetThuc()),
                dgg.getTrangThai() == 1 ? "Hoạt động" : "Ngừng hoạt động"
            });
        }
    }

    private String formatDate(java.util.Date date) {
        if (date == null) {
            return "";
        }
        return new java.text.SimpleDateFormat("yyyy-MM-dd").format(date);
    }

    private java.util.Date parseDate(String text) {
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
            sdf.setLenient(false);
            return sdf.parse(text.trim());
        } catch (Exception e) {
            return null;
        }
    }

    private boolean validateForm() {
        String ma = txtMa.getText().trim();
        String ten = txtTen.getText().trim();
        String ngayBDText = txtNgayBD.getText().trim();
        String ngayKTText = txtNgayKT.getText().trim();

        if (ma.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mã giảm giá không được để trống");
            txtMa.requestFocus();
            return false;
        }

        if (ten.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tên đợt giảm không được để trống");
            txtTen.requestFocus();
            return false;
        }

        if (ngayBDText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ngày bắt đầu không được để trống");
            txtNgayBD.requestFocus();
            return false;
        }

        if (ngayKTText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ngày kết thúc không được để trống");
            txtNgayKT.requestFocus();
            return false;
        }

        java.util.Date ngayBD = parseDate(ngayBDText);
        if (ngayBD == null) {
            JOptionPane.showMessageDialog(this, "Ngày bắt đầu phải đúng định dạng yyyy-MM-dd");
            txtNgayBD.requestFocus();
            return false;
        }

        java.util.Date ngayKT = parseDate(ngayKTText);
        if (ngayKT == null) {
            JOptionPane.showMessageDialog(this, "Ngày kết thúc phải đúng định dạng yyyy-MM-dd");
            txtNgayKT.requestFocus();
            return false;
        }

        if (ngayKT.before(ngayBD)) {
            JOptionPane.showMessageDialog(this, "Ngày kết thúc phải lớn hơn hoặc bằng ngày bắt đầu");
            txtNgayKT.requestFocus();
            return false;
        }

        if (!rdoHoaDong.isSelected() && !rdoNgungHD.isSelected()) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn trạng thái");
            return false;
        }

        DotGiamGia tonTai = dotGiamGiaDAO.selectByMa(ma);

        if (txtId.getText().trim().isEmpty()) {
            if (tonTai != null) {
                JOptionPane.showMessageDialog(this, "Mã giảm giá đã tồn tại");
                txtMa.requestFocus();
                return false;
            }
        } else {
            int idDangSua = Integer.parseInt(txtId.getText().trim());
            if (tonTai != null && tonTai.getId() != idDangSua) {
                JOptionPane.showMessageDialog(this, "Mã giảm giá đã tồn tại");
                txtMa.requestFocus();
                return false;
            }
        }

        return true;
    }

    private DotGiamGia getFormData() {
        DotGiamGia dgg = new DotGiamGia();
        dgg.setMaDotGiam(txtMa.getText().trim());
        dgg.setTenDotGiam(txtTen.getText().trim());
        dgg.setNgayBatDau(parseDate(txtNgayBD.getText().trim()));
        dgg.setNgayKetThuc(parseDate(txtNgayKT.getText().trim()));
        dgg.setTrangThai(rdoHoaDong.isSelected() ? 1 : 0);
        return dgg;
    }

    private void setFormData(DotGiamGia dgg) {
        txtId.setText(String.valueOf(dgg.getId()));
        txtMa.setText(dgg.getMaDotGiam());
        txtTen.setText(dgg.getTenDotGiam());
        txtNgayBD.setText(formatDate(dgg.getNgayBatDau()));
        txtNgayKT.setText(formatDate(dgg.getNgayKetThuc()));

        if (dgg.getTrangThai() == 1) {
            rdoHoaDong.setSelected(true);
        } else {
            rdoNgungHD.setSelected(true);
        }
    }

    private void clearForm() {
        txtId.setText("");
        txtMa.setText("");
        txtTen.setText("");
        txtNgayBD.setText("");
        txtNgayKT.setText("");
        rdoHoaDong.setSelected(true);
        tblDotGiamGia.clearSelection();
        selectedId = -1;
    }

    private void insertDotGiamGia() {
        if (!validateForm()) {
            return;
        }

        try {
            DotGiamGia dgg = getFormData();
            dotGiamGiaDAO.insert(dgg);
            JOptionPane.showMessageDialog(this, "Thêm đợt giảm giá thành công");
            loadTable();
            clearForm();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Thêm thất bại: " + e.getMessage());
        }
    }

    private void updateDotGiamGia() {
        if (txtId.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn đợt giảm giá cần sửa");
            return;
        }

        if (!validateForm()) {
            return;
        }

        try {
            DotGiamGia dgg = getFormData();
            dgg.setId(Integer.parseInt(txtId.getText().trim()));
            dotGiamGiaDAO.update(dgg);
            JOptionPane.showMessageDialog(this, "Cập nhật thành công");
            loadTable();
            clearForm();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Cập nhật thất bại: " + e.getMessage());
        }
    }

    private void deleteDotGiamGia() {
        if (txtId.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn đợt giảm giá cần xóa");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc muốn xóa đợt giảm giá này không?",
                "Xác nhận xóa",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            int id = Integer.parseInt(txtId.getText().trim());
            dotGiamGiaDAO.delete(id);
            JOptionPane.showMessageDialog(this, "Xóa thành công");
            loadTable();
            clearForm();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Xóa thất bại: " + e.getMessage());
        }
    }

    private void tableClick() {
        int row = tblDotGiamGia.getSelectedRow();
        if (row == -1) {
            return;
        }

        int id = Integer.parseInt(String.valueOf(tblDotGiamGia.getValueAt(row, 0)));
        DotGiamGia dgg = dotGiamGiaDAO.selectById(id);

        if (dgg != null) {
            setFormData(dgg);
            selectedId = id;
        }
    }

    private void searchDotGiamGia() {
        String keyword = txtTim.getText().trim();

        if (keyword.isEmpty()) {
            loadTable();
            return;
        }

        model.setRowCount(0);

        List<DotGiamGia> list = dotGiamGiaDAO.selectByKeyword(keyword);

        for (DotGiamGia dgg : list) {
            model.addRow(new Object[]{
                dgg.getId(),
                dgg.getMaDotGiam(),
                dgg.getTenDotGiam(),
                formatDate(dgg.getNgayBatDau()),
                formatDate(dgg.getNgayKetThuc()),
                dgg.getTrangThai() == 1 ? "Hoạt động" : "Ngừng hoạt động"
            });
        }
    }

    private void filterDotGiamGia() {
        String keyword = txtDate.getText().trim();

        if (keyword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập năm, tháng hoặc ngày để lọc");
            txtDate.requestFocus();
            return;
        }

        model.setRowCount(0);

        List<DotGiamGia> list = dotGiamGiaDAO.filterByDate(keyword);

        if (list.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy dữ liệu theo ngày tháng đã nhập");
            return;
        }

        for (DotGiamGia dgg : list) {
            model.addRow(new Object[]{
                dgg.getId(),
                dgg.getMaDotGiam(),
                dgg.getTenDotGiam(),
                formatDate(dgg.getNgayBatDau()),
                formatDate(dgg.getNgayKetThuc()),
                dgg.getTrangThai() == 1 ? "Hoạt động" : "Ngừng hoạt động"
            });
        }
    }

    private void openSanPhamApDungDialog() {
        int row = tblDotGiamGia.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một đợt giảm giá trước.");
            return;
        }

        int idDot = Integer.parseInt(tblDotGiamGia.getValueAt(row, 0).toString()); // cột 0 = ID
        DotGiamGia dot = dotGiamGiaDAO.selectById(idDot);
        if (dot == null) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy đợt giảm giá.");
            return;
        }

        SanPhamApDungDotGiamGiaJDialog dlg
                = new SanPhamApDungDotGiamGiaJDialog(this, true, dot);
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);

        // reload bảng đợt giảm giá (nếu muốn)
        loadTable();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtMa = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtTen = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtNgayBD = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtNgayKT = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        rdoHoaDong = new javax.swing.JRadioButton();
        rdoNgungHD = new javax.swing.JRadioButton();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        btnLoc = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblDotGiamGia = new javax.swing.JTable();
        txtTim = new javax.swing.JTextField();
        btnTim = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        txtDate = new javax.swing.JTextField();
        btnSanPhamApDung = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        jLabel1.setText("QUẢN LÝ ĐỢT GIẢM GIÁ");

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel2.setText("Mã Giam giá");

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel3.setText("Tên đợt giảm");

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel4.setText("ID");

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel5.setText("Ngày bắt đầu");

        jLabel6.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel6.setText("Ngày kết thúc");

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel7.setText("Trạng thái");

        buttonGroup1.add(rdoHoaDong);
        rdoHoaDong.setText("Hoạt động");

        buttonGroup1.add(rdoNgungHD);
        rdoNgungHD.setText("Ngừng hoạt động");

        btnThem.setText("THÊM");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setText("SỬA");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnXoa.setText("XÓA");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        btnLoc.setText("LỌC");
        btnLoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLocActionPerformed(evt);
            }
        });

        tblDotGiamGia.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Mã giảm giá", "Tên", "Ngày bắt đầu", "Ngày kết thúc", "Trạng thái"
            }
        ));
        tblDotGiamGia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblDotGiamGiaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblDotGiamGia);

        btnTim.setText("Tìm");
        btnTim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel8.setText("Tìm kiếm ngày tháng");

        btnSanPhamApDung.setText("ÁP DỤNG GIẢM GIÁ SP");
        btnSanPhamApDung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSanPhamApDungActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel5))
                                .addGap(24, 24, 24))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtNgayKT, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtMa, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3)
                                .addGap(26, 26, 26))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtDate, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(223, 223, 223))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(9, 9, 9)
                                        .addComponent(btnThem)
                                        .addGap(68, 68, 68)
                                        .addComponent(btnSua)
                                        .addGap(50, 50, 50)
                                        .addComponent(btnXoa)
                                        .addGap(50, 50, 50)
                                        .addComponent(btnLoc)
                                        .addGap(63, 63, 63)
                                        .addComponent(btnSanPhamApDung)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rdoNgungHD)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtTim, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnTim))
                            .addComponent(txtTen, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rdoHoaDong)
                            .addComponent(txtNgayBD, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTim))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtMa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(txtTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtNgayBD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel6)
                    .addComponent(txtNgayKT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rdoHoaDong))
                .addGap(21, 21, 21)
                .addComponent(rdoNgungHD)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txtDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThem)
                    .addComponent(btnSua)
                    .addComponent(btnXoa)
                    .addComponent(btnLoc)
                    .addComponent(btnSanPhamApDung))
                .addGap(44, 44, 44)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        insertDotGiamGia();
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        updateDotGiamGia();
    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        deleteDotGiamGia();
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnLocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLocActionPerformed
        filterDotGiamGia();
    }//GEN-LAST:event_btnLocActionPerformed

    private void btnTimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimActionPerformed
        searchDotGiamGia();
    }//GEN-LAST:event_btnTimActionPerformed

    private void tblDotGiamGiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDotGiamGiaMouseClicked
        tableClick();
    }//GEN-LAST:event_tblDotGiamGiaMouseClicked

    private void btnSanPhamApDungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSanPhamApDungActionPerformed
        openSanPhamApDungDialog();
    }//GEN-LAST:event_btnSanPhamApDungActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GiamGiaManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GiamGiaManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GiamGiaManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GiamGiaManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                GiamGiaManagerJDialog dialog = new GiamGiaManagerJDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLoc;
    private javax.swing.JButton btnSanPhamApDung;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnTim;
    private javax.swing.JButton btnXoa;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rdoHoaDong;
    private javax.swing.JRadioButton rdoNgungHD;
    private javax.swing.JTable tblDotGiamGia;
    private javax.swing.JTextField txtDate;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtMa;
    private javax.swing.JTextField txtNgayBD;
    private javax.swing.JTextField txtNgayKT;
    private javax.swing.JTextField txtTen;
    private javax.swing.JTextField txtTim;
    // End of variables declaration//GEN-END:variables
}
