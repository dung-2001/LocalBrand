/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.dao.impl;

import java.util.ArrayList;
import java.util.List;
import local.brand.dao.HoaDonDAO;
import local.brand.entity.HoaDon;
import local.brand.ulti.XJdbc;

/**
 *
 * @author ASUS
 */
public class HoaDonDAOImpl implements HoaDonDAO {

    private final String SELECT_ALL = "SELECT "
            + "hd.id, hd.ma_hoa_don AS maHoaDon, hd.thoi_gian_mua AS thoiGianMua, "
            + "hd.id_nhan_vien AS idNhanVien, hd.ten_kh AS tenKh, hd.sdt_kh AS sdtKh, "
            + "hd.tong_tien AS tongTien, hd.trang_thai AS trangThai, "
            + "hd.tien_giam AS tienGiam, hd.thanh_tien AS thanhTien, "
            + "hd.phieu_giam AS phieuGiam, "
            + "ht.ten_hinh_thuc AS tenHinhThuc "
            + "FROM hoa_don hd "
            + "LEFT JOIN hinh_thuc_thanh_toan ht ON hd.id_hinh_thuc = ht.id ";

    @Override
    public void insert(HoaDon entity) {
        String sql = "INSERT INTO hoa_don (id_nhan_vien, id_khach, id_hinh_thuc, phieu_giam, ma_hoa_don, "
                + "tong_tien, trang_thai, tien_giam, thanh_tien, ten_kh, sdt_kh) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        XJdbc.executeUpdate(sql,
                entity.getIdNhanVien(),
                entity.getIdKhach(),
                entity.getIdHinhThuc(),
                entity.getPhieuGiam(),
                entity.getMaHoaDon(),
                entity.getTongTien(),
                entity.getTrangThai(),
                entity.getTienGiam(),
                entity.getThanhTien(),
                entity.getTenKh(),
                entity.getSdtKh()
        );
    }

    @Override
    public List<HoaDon> selectAll() {
        return XJdbc.getBeanList(HoaDon.class, SELECT_ALL + " ORDER BY hd.thoi_gian_mua DESC");
    }

    @Override
    public HoaDon selectById(String maHD) {
        String sql = SELECT_ALL + " WHERE hd.ma_hoa_don = ?";
        return XJdbc.getSingleBean(HoaDon.class, sql, maHD);
    }

    @Override
    public List<HoaDon> selectByKeyword(String keyword) {
        String sql = SELECT_ALL + " WHERE hd.ma_hoa_don LIKE ? OR hd.sdt_kh LIKE ? OR hd.ten_kh LIKE ? ORDER BY hd.thoi_gian_mua DESC";
        String value = "%" + keyword + "%";
        return XJdbc.getBeanList(HoaDon.class, sql, value, value, value);
    }

    @Override
    public void delete(String maHD) {
        String sql = "DELETE FROM hoa_don WHERE ma_hoa_don = ?";
        XJdbc.executeUpdate(sql, maHD);
    }

    @Override
    public List<HoaDon> selectByFilter(String keyword, String startDate, String endDate, Integer trangThai) {
        StringBuilder sql = new StringBuilder(SELECT_ALL + " WHERE 1=1 ");
        List<Object> params = new ArrayList<>();

        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append(" AND (hd.ma_hoa_don LIKE ? OR hd.sdt_kh LIKE ? OR hd.ten_kh LIKE ? OR ht.ten_hinh_thuc LIKE ?) ");
            String key = "%" + keyword.trim() + "%";
            params.add(key);
            params.add(key);
            params.add(key);
            params.add(key);
        }

        if (startDate != null && !startDate.isEmpty()) {
            sql.append(" AND CAST(hd.thoi_gian_mua AS DATE) >= ? ");
            params.add(startDate);
        }

        if (endDate != null && !endDate.isEmpty()) {
            sql.append(" AND CAST(hd.thoi_gian_mua AS DATE) <= ? ");
            params.add(endDate);
        }

        if (trangThai != null) {
            sql.append(" AND hd.trang_thai = ? ");
            params.add(trangThai);
        }

        sql.append(" ORDER BY hd.thoi_gian_mua DESC");
        return XJdbc.getBeanList(HoaDon.class, sql.toString(), params.toArray());
    }

   

    public Integer getIdByMa(String maHd) {
        String sql = "SELECT id FROM hoa_don WHERE ma_hoa_don = ?";
        try {
            Object value = XJdbc.getValue(sql, maHd);
            if (value != null) {
                return Integer.valueOf(value.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
