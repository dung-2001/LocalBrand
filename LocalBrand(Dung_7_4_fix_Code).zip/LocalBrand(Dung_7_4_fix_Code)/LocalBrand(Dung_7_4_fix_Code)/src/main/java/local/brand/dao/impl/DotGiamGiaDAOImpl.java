/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.dao.impl;

import java.util.List;
import local.brand.dao.DotGiamGiaDAO;
import local.brand.entity.DotGiamGia;
import local.brand.ulti.XJdbc;

public class DotGiamGiaDAOImpl implements DotGiamGiaDAO {

    private static final String INSERT_SQL = """
        INSERT INTO dot_giam_gia (
            ma_dot_giam, ten_dot_giam, ngay_bat_dau, ngay_ket_thuc, trang_thai
        )
        VALUES (?, ?, ?, ?, ?)
        """;

    private static final String UPDATE_SQL = """
        UPDATE dot_giam_gia
        SET ma_dot_giam = ?,
            ten_dot_giam = ?,
            ngay_bat_dau = ?,
            ngay_ket_thuc = ?,
            trang_thai = ?
        WHERE id = ?
        """;

    private static final String DELETE_SQL = """
        DELETE FROM dot_giam_gia
        WHERE id = ?
        """;

    private static final String SELECT_BY_ID_SQL = """
        SELECT
            id AS id,
            ma_dot_giam AS maDotGiam,
            ten_dot_giam AS tenDotGiam,
            ngay_bat_dau AS ngayBatDau,
            ngay_ket_thuc AS ngayKetThuc,
            trang_thai AS trangThai
        FROM dot_giam_gia
        WHERE id = ?
        """;

    private static final String SELECT_BY_MA_SQL = """
        SELECT
            id AS id,
            ma_dot_giam AS maDotGiam,
            ten_dot_giam AS tenDotGiam,
            ngay_bat_dau AS ngayBatDau,
            ngay_ket_thuc AS ngayKetThuc,
            trang_thai AS trangThai
        FROM dot_giam_gia
        WHERE ma_dot_giam = ?
        """;

    private static final String SELECT_ALL_SQL = """
        SELECT
            id AS id,
            ma_dot_giam AS maDotGiam,
            ten_dot_giam AS tenDotGiam,
            ngay_bat_dau AS ngayBatDau,
            ngay_ket_thuc AS ngayKetThuc,
            trang_thai AS trangThai
        FROM dot_giam_gia
        ORDER BY id DESC
        """;

    private static final String SELECT_BY_KEYWORD_SQL = """
    SELECT
        id AS id,
        ma_dot_giam AS maDotGiam,
        ten_dot_giam AS tenDotGiam,
        ngay_bat_dau AS ngayBatDau,
        ngay_ket_thuc AS ngayKetThuc,
        trang_thai AS trangThai
    FROM dot_giam_gia
    WHERE CAST(id AS VARCHAR) LIKE ?
       OR ma_dot_giam LIKE ?
       OR ten_dot_giam LIKE ?
    ORDER BY id DESC
    """;

    private static final String FILTER_BY_DATE_SQL = """
    SELECT
        id AS id,
        ma_dot_giam AS maDotGiam,
        ten_dot_giam AS tenDotGiam,
        ngay_bat_dau AS ngayBatDau,
        ngay_ket_thuc AS ngayKetThuc,
        trang_thai AS trangThai
    FROM dot_giam_gia
    WHERE CONVERT(VARCHAR(10), ngay_bat_dau, 23) LIKE ?
       OR CONVERT(VARCHAR(10), ngay_ket_thuc, 23) LIKE ?
    ORDER BY id DESC
    """;

    @Override
    public void insert(DotGiamGia entity) {
        XJdbc.executeUpdate(
                INSERT_SQL,
                entity.getMaDotGiam(),
                entity.getTenDotGiam(),
                new java.sql.Date(entity.getNgayBatDau().getTime()),
                new java.sql.Date(entity.getNgayKetThuc().getTime()),
                entity.getTrangThai()
        );
    }

    @Override
    public void update(DotGiamGia entity) {
        XJdbc.executeUpdate(
                UPDATE_SQL,
                entity.getMaDotGiam(),
                entity.getTenDotGiam(),
                new java.sql.Date(entity.getNgayBatDau().getTime()),
                new java.sql.Date(entity.getNgayKetThuc().getTime()),
                entity.getTrangThai(),
                entity.getId()
        );

    }

    @Override
    public void delete(Integer id) {
        XJdbc.executeUpdate(DELETE_SQL, id);
    }

    @Override
    public DotGiamGia selectById(Integer id) {
        return XJdbc.getSingleBean(DotGiamGia.class, SELECT_BY_ID_SQL, id);
    }

    @Override
    public DotGiamGia selectByMa(String ma) {
        return XJdbc.getSingleBean(DotGiamGia.class, SELECT_BY_MA_SQL, ma);
    }

    @Override
    public List<DotGiamGia> selectAll() {
        return XJdbc.getBeanList(DotGiamGia.class, SELECT_ALL_SQL);
    }

    @Override
    public List<DotGiamGia> selectByKeyword(String keyword) {
        String value = "%" + keyword + "%";
        return XJdbc.getBeanList(DotGiamGia.class, SELECT_BY_KEYWORD_SQL, value, value, value);
    }

    @Override
    public boolean existsByMa(String ma) {
        return selectByMa(ma) != null;
    }

    @Override
    public List<DotGiamGia> filterByDate(String keyword) {
        String value = keyword + "%";
        return XJdbc.getBeanList(DotGiamGia.class, FILTER_BY_DATE_SQL, value, value);
    }
}
