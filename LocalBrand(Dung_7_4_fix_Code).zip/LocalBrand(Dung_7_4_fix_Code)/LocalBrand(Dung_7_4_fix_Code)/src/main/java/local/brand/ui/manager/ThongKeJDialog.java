package local.brand.ui.manager;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.io.File;
import java.io.FileOutputStream;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.filechooser.FileNameExtensionFilter;
import local.brand.dao.ThongKeChiTietDAO;
import local.brand.dao.ThongKeDAO;
import local.brand.dao.impl.ThongKeChiTietDAOImpl;
import local.brand.dao.impl.ThongKeDAOImpl;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

/**
 *
 * @author CAU DIEN
 */
public class ThongKeJDialog extends javax.swing.JDialog {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ThongKeJDialog.class.getName());
    private final ThongKeDAO dao = new ThongKeDAOImpl();
    private final ThongKeChiTietDAO thongKeChiTietDAO = new ThongKeChiTietDAOImpl();
    private JButton btnSanPhamBanChay;
    private JButton btnXuatExcel;
    private JLabel lblTienMat;
    private JLabel lblChuyenKhoan;
    private JPanel pnlTyLeThanhToan;

    public ThongKeJDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        // 1. PHẢI GỌI CÁI NÀY ĐẦU TIÊN (Trước initComponents)
        this.setUndecorated(true);
        // 2. Khởi tạo components từ NetBeans (Không sửa trong initComponents)
        initComponents();

        // 3. Thiết lập Full màn hình
        java.awt.GraphicsConfiguration config = this.getGraphicsConfiguration();
        java.awt.Insets insets = java.awt.Toolkit.getDefaultToolkit().getScreenInsets(config);
        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();

        // Chiều cao = Toàn màn hình trừ thanh Taskbar
        this.setSize(screenSize.width, screenSize.height - insets.bottom);
        this.setLocation(0, 0);

        // 3. Cấu hình lại Layout để ép pnlBieuDo giãn ra (Quan trọng nhất)
        setupLayout(screenSize.width);
        initExtendedUi();

        // 4. Thiết lập giá trị mặc định cho các bộ chọn ngày
        java.util.Date today = new java.util.Date();
        jdTuNgay.setDate(today);
        jdDenNgay.setDate(today);
        jdNgay.setDate(today);

        // 5. Khởi tạo trạng thái bộ lọc
        jcbLoc.setSelectedIndex(0);
        updateFilterUI();

        // 6. Đăng ký sự kiện (Lưu ý: Ông cần viết hàm setupEventListeners hoặc gọi trực tiếp refreshData)
        // setupEventListeners(); 
        // 7. Đổ dữ liệu lần đầu
        refreshData();

        // Buộc Swing vẽ lại toàn bộ giao diện theo kích thước mới
        this.validate();
        this.repaint();
    }

    /**
     * Hàm này dùng để "ép" các Panel vào đúng vị trí BorderLayout giúp biểu đồ
     * không bị lùn.
     */
    private void setupLayout(int width) {
        java.awt.Container container = this.getContentPane();
        container.setLayout(new java.awt.BorderLayout());

        // Thay vì set cứng 250, hãy để Panel tự tính toán nhưng có giới hạn tối thiểu
        // Hoặc tăng lên 300-320 nếu ông thấy vẫn thiếu
        pnlHeader.setPreferredSize(new java.awt.Dimension(width, 365));
        panel6.setPreferredSize(new java.awt.Dimension(width, 165));

        container.add(pnlHeader, java.awt.BorderLayout.NORTH);

        // Panel biểu đồ chiếm phần còn lại
        container.add(pnlBieuDo, java.awt.BorderLayout.CENTER);
        pnlBieuDo.setLayout(new java.awt.BorderLayout());
        pnlBieuDo.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 20, 10, 20));
    }

    public String formatMoney(Double money) {
        java.text.DecimalFormat df = new java.text.DecimalFormat("###,###");
        return df.format(money) + " VNĐ";
    }

    private void updateFilterUI() {
        int index = jcbLoc.getSelectedIndex();

        // Index 0: Lọc theo khoảng ngày
        boolean isRange = (index == 0);
        lblTuNgay.setVisible(isRange);
        jdTuNgay.setVisible(isRange);
        lblDenNgay.setVisible(isRange);
        jdDenNgay.setVisible(isRange);

        // Index 1: Lọc theo ngày đơn lẻ
        boolean isSingleDate = (index == 1);
        lblNgay.setVisible(isSingleDate);
        jdNgay.setVisible(isSingleDate);

        // Index 2: Lọc theo tháng (Hiện Tháng + Năm)
        boolean isMonth = (index == 2);
        lblThang.setVisible(isMonth);
        jMonthChooser.setVisible(isMonth);

        // Index 2 & 3: Cần chọn Năm
        boolean needsYear = (index == 2 || index == 3);
        lblNam.setVisible(needsYear);
        cboNam.setVisible(needsYear);

        this.revalidate();
        this.repaint();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenu1 = new javax.swing.JMenu();
        theoNgay = new javax.swing.JCheckBoxMenuItem();
        theoTuan = new javax.swing.JCheckBoxMenuItem();
        theoThang = new javax.swing.JCheckBoxMenuItem();
        theoNam = new javax.swing.JCheckBoxMenuItem();
        pnlBieuDo = new javax.swing.JPanel();
        pnlHeader = new java.awt.Panel();
        panel1 = new java.awt.Panel();
        jLabel1 = new javax.swing.JLabel();
        panel2 = new java.awt.Panel();
        lblNam = new javax.swing.JLabel();
        cboNam = new javax.swing.JComboBox<>();
        lblThang = new javax.swing.JLabel();
        jMonthChooser = new com.toedter.calendar.JMonthChooser();
        panel4 = new java.awt.Panel();
        jcbLoc = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        panel3 = new java.awt.Panel();
        lblTuNgay = new javax.swing.JLabel();
        jdTuNgay = new com.toedter.calendar.JDateChooser();
        lblDenNgay = new javax.swing.JLabel();
        jdDenNgay = new com.toedter.calendar.JDateChooser();
        panel5 = new java.awt.Panel();
        btnLamMoi = new javax.swing.JButton();
        xemChiTietDoanhThu = new javax.swing.JButton();
        lblNgay = new javax.swing.JLabel();
        jdNgay = new com.toedter.calendar.JDateChooser();
        btnThoat = new javax.swing.JButton();
        btnspBanChay = new javax.swing.JButton();
        btnxuatEx = new javax.swing.JButton();
        panel6 = new java.awt.Panel();
        panel7 = new java.awt.Panel();
        lblsoDoanhThu = new javax.swing.JLabel();
        lblDoanhThu = new javax.swing.JLabel();
        panel8 = new java.awt.Panel();
        lblSoDonHang = new javax.swing.JLabel();
        lblDonHang = new javax.swing.JLabel();
        lblThanhCong = new javax.swing.JLabel();
        lblThanhCong1 = new javax.swing.JLabel();
        lblSoThanhCong = new javax.swing.JLabel();
        lblSoDonHuy = new javax.swing.JLabel();
        panel9 = new java.awt.Panel();
        lblDoanhThuThang = new javax.swing.JLabel();
        lblSoDoanhThuThang = new javax.swing.JLabel();
        panel10 = new java.awt.Panel();
        lblDoanhThuNam = new javax.swing.JLabel();
        lblSoDoanhThuNam = new javax.swing.JLabel();

        jMenu1.setText("jMenu1");

        theoNgay.setSelected(true);
        theoNgay.setText("jCheckBoxMenuItem1");
        theoNgay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                theoNgayActionPerformed(evt);
            }
        });
        jMenu1.add(theoNgay);

        theoTuan.setSelected(true);
        theoTuan.setText("jCheckBoxMenuItem2");
        jMenu1.add(theoTuan);

        theoThang.setSelected(true);
        theoThang.setText("jCheckBoxMenuItem3");
        jMenu1.add(theoThang);

        theoNam.setSelected(true);
        theoNam.setText("jCheckBoxMenuItem1");
        jMenu1.add(theoNam);

        jPopupMenu1.add(jMenu1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        pnlBieuDo.setLayout(new java.awt.BorderLayout());

        pnlHeader.setForeground(new java.awt.Color(255, 255, 204));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("THỐNG KÊ DOANH THU");

        lblNam.setText("Năm");

        cboNam.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2021", "2022", "2023", "2024", "2025", "2026", " " }));
        cboNam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboNamActionPerformed(evt);
            }
        });

        lblThang.setText("Tháng");

        jMonthChooser.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jMonthChooserPropertyChange(evt);
            }
        });

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblNam, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThang, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cboNam, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jMonthChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26))
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNam)
                    .addComponent(cboNam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblThang)
                    .addComponent(jMonthChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jcbLoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lọc theo khoảng ngày", "Lọc theo ngày", "Lọc theo tháng", "Lọc theo năm " }));
        jcbLoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcbLocActionPerformed(evt);
            }
        });

        jLabel5.setText("Lọc");

        javax.swing.GroupLayout panel4Layout = new javax.swing.GroupLayout(panel4);
        panel4.setLayout(panel4Layout);
        panel4Layout.setHorizontalGroup(
            panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jcbLoc, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel4Layout.setVerticalGroup(
            panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel4Layout.createSequentialGroup()
                .addGroup(panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jcbLoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(0, 15, Short.MAX_VALUE))
        );

        lblTuNgay.setText("Từ ngày");

        jdTuNgay.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jdTuNgayPropertyChange(evt);
            }
        });

        lblDenNgay.setText("Đến ngày ");

        jdDenNgay.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jdDenNgayPropertyChange(evt);
            }
        });

        javax.swing.GroupLayout panel3Layout = new javax.swing.GroupLayout(panel3);
        panel3.setLayout(panel3Layout);
        panel3Layout.setHorizontalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(lblTuNgay, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jdTuNgay, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addComponent(lblDenNgay, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jdDenNgay, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );
        panel3Layout.setVerticalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jdDenNgay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDenNgay)
                    .addComponent(jdTuNgay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTuNgay))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnLamMoi.setText("Làm mới");
        btnLamMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiActionPerformed(evt);
            }
        });

        xemChiTietDoanhThu.setText("Xem chi tiết doanh thu");
        xemChiTietDoanhThu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                xemChiTietDoanhThuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel5Layout = new javax.swing.GroupLayout(panel5);
        panel5.setLayout(panel5Layout);
        panel5Layout.setHorizontalGroup(
            panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(xemChiTietDoanhThu)
                .addGap(30, 30, 30)
                .addComponent(btnLamMoi)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel5Layout.setVerticalGroup(
            panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLamMoi)
                    .addComponent(xemChiTietDoanhThu))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblNgay.setText("Ngày");

        jdNgay.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jdNgayPropertyChange(evt);
            }
        });

        btnThoat.setText("Thoát");
        btnThoat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThoatActionPerformed(evt);
            }
        });

        btnspBanChay.setText("Sản phẩm bán chạy");
        btnspBanChay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnspBanChayActionPerformed(evt);
            }
        });

        btnxuatEx.setText("Xuất excel");

        btnxuatEx.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnxuatExActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(389, 389, 389)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(555, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(panel1Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(lblNgay, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31)
                                .addComponent(jdNgay, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20)
                                .addComponent(panel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(panel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(1, 1, 1)
                        .addComponent(btnspBanChay)
                        .addGap(18, 18, 18)
                        .addComponent(btnxuatEx)
                        .addGap(18, 18, 18)
                        .addComponent(btnThoat)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(panel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(41, 41, 41))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(panel1Layout.createSequentialGroup()
                                .addComponent(panel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(panel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jdNgay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblNgay))))
                        .addGap(122, 122, 122))
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addComponent(panel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnThoat)
                            .addComponent(btnspBanChay)
                            .addComponent(btnxuatEx))
                        .addGap(127, 127, 127))))
        );

        panel6.setForeground(new java.awt.Color(255, 204, 204));

        lblsoDoanhThu.setText("0");

        lblDoanhThu.setText("DOANH THU: ");

        javax.swing.GroupLayout panel7Layout = new javax.swing.GroupLayout(panel7);
        panel7.setLayout(panel7Layout);
        panel7Layout.setHorizontalGroup(
            panel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel7Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(lblDoanhThu, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblsoDoanhThu, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(83, Short.MAX_VALUE))
        );
        panel7Layout.setVerticalGroup(
            panel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel7Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(panel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblsoDoanhThu)
                    .addComponent(lblDoanhThu, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(55, Short.MAX_VALUE))
        );

        lblSoDonHang.setText("0");

        lblDonHang.setText("SỐ ĐƠN HÀNG");

        lblThanhCong.setText("Thành công:");

        lblThanhCong1.setText("Hủy: ");

        lblSoThanhCong.setText("0");

        lblSoDonHuy.setText("0");

        javax.swing.GroupLayout panel8Layout = new javax.swing.GroupLayout(panel8);
        panel8.setLayout(panel8Layout);
        panel8Layout.setHorizontalGroup(
            panel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDonHang, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThanhCong, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThanhCong1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSoDonHang, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(lblSoDonHuy, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE)
                        .addComponent(lblSoThanhCong, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel8Layout.setVerticalGroup(
            panel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel8Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(panel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSoDonHang)
                    .addComponent(lblDonHang, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblThanhCong)
                    .addComponent(lblSoThanhCong))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblThanhCong1)
                    .addComponent(lblSoDonHuy))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblDoanhThuThang.setText("DOANH THU THÁNG: ");

        lblSoDoanhThuThang.setText("0");

        javax.swing.GroupLayout panel9Layout = new javax.swing.GroupLayout(panel9);
        panel9.setLayout(panel9Layout);
        panel9Layout.setHorizontalGroup(
            panel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel9Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(lblDoanhThuThang, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblSoDoanhThuThang, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel9Layout.setVerticalGroup(
            panel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel9Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(panel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDoanhThuThang, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSoDoanhThuThang))
                .addContainerGap(52, Short.MAX_VALUE))
        );

        lblDoanhThuNam.setText("DOANH THU NĂM: ");

        lblSoDoanhThuNam.setText("0");

        javax.swing.GroupLayout panel10Layout = new javax.swing.GroupLayout(panel10);
        panel10.setLayout(panel10Layout);
        panel10Layout.setHorizontalGroup(
            panel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel10Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(lblDoanhThuNam, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblSoDoanhThuNam, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE))
        );
        panel10Layout.setVerticalGroup(
            panel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel10Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(panel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDoanhThuNam)
                    .addComponent(lblSoDoanhThuNam))
                .addContainerGap(60, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout panel6Layout = new javax.swing.GroupLayout(panel6);
        panel6.setLayout(panel6Layout);
        panel6Layout.setHorizontalGroup(
            panel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel6Layout.createSequentialGroup()
                .addComponent(panel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(53, 53, 53)
                .addComponent(panel8, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66)
                .addComponent(panel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(115, 115, 115)
                .addComponent(panel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54))
        );
        panel6Layout.setVerticalGroup(
            panel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel6Layout.createSequentialGroup()
                .addGroup(panel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel6Layout.createSequentialGroup()
                        .addGroup(panel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(panel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(panel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(panel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 15, Short.MAX_VALUE))
                    .addComponent(panel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout pnlHeaderLayout = new javax.swing.GroupLayout(pnlHeader);
        pnlHeader.setLayout(pnlHeaderLayout);
        pnlHeaderLayout.setHorizontalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlHeaderLayout.setVerticalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(pnlBieuDo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlHeader, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63)
                .addComponent(pnlBieuDo, javax.swing.GroupLayout.PREFERRED_SIZE, 511, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void theoNgayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_theoNgayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_theoNgayActionPerformed

    private void cboNamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboNamActionPerformed
        refreshData();
    }//GEN-LAST:event_cboNamActionPerformed

    private void jMonthChooserPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jMonthChooserPropertyChange
        if ("month".equals(evt.getPropertyName())) {
            refreshData();
        }

    }//GEN-LAST:event_jMonthChooserPropertyChange

    private void jcbLocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbLocActionPerformed
        updateFilterUI();
        refreshData();


    }//GEN-LAST:event_jcbLocActionPerformed

    private void jdTuNgayPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jdTuNgayPropertyChange
        if ("date".equals(evt.getPropertyName())) {
            refreshData();
        }
    }//GEN-LAST:event_jdTuNgayPropertyChange

    private void jdDenNgayPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jdDenNgayPropertyChange
        if ("date".equals(evt.getPropertyName())) {
            refreshData();
        }
    }//GEN-LAST:event_jdDenNgayPropertyChange

    private void xemChiTietDoanhThuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_xemChiTietDoanhThuActionPerformed
        ThongKeChiTietJDialog chiTiet = new ThongKeChiTietJDialog((java.awt.Frame) this.getParent(), true);
        chiTiet.setVisible(true);
    }//GEN-LAST:event_xemChiTietDoanhThuActionPerformed

    private void btnLamMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiActionPerformed
        resetForm();
    }//GEN-LAST:event_btnLamMoiActionPerformed

    private void jdNgayPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jdNgayPropertyChange
        // Chỉ chạy khi thuộc tính "date" thay đổi
        if ("date".equals(evt.getPropertyName())) {
            refreshData();
        }
    }//GEN-LAST:event_jdNgayPropertyChange

    private void btnThoatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThoatActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnThoatActionPerformed

    private void btnspBanChayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnspBanChayActionPerformed
        openTopSellingProductsDialog();
    }//GEN-LAST:event_btnspBanChayActionPerformed

    private void btnxuatExActionPerformed(java.awt.event.ActionEvent evt) {
        exportThongKeToExcel();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                ThongKeJDialog dialog = new ThongKeJDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    private void showChartOnPanel(JFreeChart chart, int dataSize) {
        ChartPanel chartPanel = new ChartPanel(chart);

        // Tính toán độ rộng động: Nếu dữ liệu nhiều thì cho cuộn, ít thì giãn đều
        int panelWidth = pnlBieuDo.getWidth();
        int panelHeight = pnlBieuDo.getHeight();
        int minWidthRequired = dataSize * 80; // Tăng lên 80px mỗi cột cho thoáng

        if (minWidthRequired > panelWidth) {
            chartPanel.setPreferredSize(new java.awt.Dimension(minWidthRequired, panelHeight - 50));
        } else {
            // Nếu ít dữ liệu, ép nó giãn bằng đúng chiều rộng Panel để không bị thừa khoảng trắng
            chartPanel.setPreferredSize(new java.awt.Dimension(panelWidth - 20, panelHeight - 50));
        }

        chartPanel.setMouseWheelEnabled(true);
        chartPanel.setDisplayToolTips(true);

        javax.swing.JScrollPane scrollPane = new javax.swing.JScrollPane(chartPanel);
        // Luôn hiện thanh cuộn ngang để người dùng biết là có thể kéo
        scrollPane.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);

        pnlBieuDo.removeAll();
        pnlBieuDo.setLayout(new java.awt.BorderLayout());
        pnlBieuDo.add(scrollPane, java.awt.BorderLayout.CENTER);

        pnlBieuDo.validate();
        pnlBieuDo.repaint();
    }

    private void initExtendedUi() {
        tuneSummaryCardSizes();
        initPaymentSummaryPanel();
    }

    private void tuneSummaryCardSizes() {
        lblDoanhThuThang.setPreferredSize(new java.awt.Dimension(135, 28));
        lblDoanhThuNam.setPreferredSize(new java.awt.Dimension(125, 28));
        lblSoDoanhThuThang.setPreferredSize(new java.awt.Dimension(120, 28));
        lblSoDoanhThuNam.setPreferredSize(new java.awt.Dimension(135, 28));
    }

    private void initActionButtons() {

        btnSanPhamBanChay = new JButton("Sản phẩm bán chạy");
        btnSanPhamBanChay.addActionListener(evt -> openTopSellingProductsDialog());

        btnXuatExcel = new JButton("Xuất Excel");
        btnXuatExcel.addActionListener(evt -> exportThongKeToExcel());

        panel5.add(xemChiTietDoanhThu);
        panel5.add(btnLamMoi);
        panel5.add(btnThoat);
        panel5.add(btnSanPhamBanChay);
        panel5.add(btnXuatExcel);
        panel5.revalidate();
        panel5.repaint();
    }

    private void initPaymentSummaryPanel() {
        panel7.removeAll();
        panel7.setLayout(new BorderLayout(18, 0));

        JPanel textPanel = new JPanel();
        textPanel.setOpaque(false);
        textPanel.setLayout(new javax.swing.BoxLayout(textPanel, javax.swing.BoxLayout.Y_AXIS));

        lblDoanhThu.setText("DOANH THU:");
        lblDoanhThu.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblsoDoanhThu.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JLabel lblTienMatTitle = new JLabel("Tiền mặt:");
        lblTienMatTitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblTienMat = new JLabel("0 VNĐ");
        lblTienMat.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTienMatTitle.setText("Ti\u1ec1n m\u1eb7t:");
        lblTienMat.setText("0 VN\u0110");

        JLabel lblChuyenKhoanTitle = new JLabel("Chuyển khoản:");
        lblChuyenKhoanTitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblChuyenKhoan = new JLabel("0 VNĐ");
        lblChuyenKhoan.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblChuyenKhoanTitle.setText("Chuy\u1ec3n kho\u1ea3n:");
        lblChuyenKhoan.setText("0 VN\u0110");

        textPanel.add(lblDoanhThu);
        textPanel.add(Box.createVerticalStrut(6));
        textPanel.add(lblsoDoanhThu);
        textPanel.add(Box.createVerticalStrut(18));
        textPanel.add(lblTienMatTitle);
        textPanel.add(Box.createVerticalStrut(4));
        textPanel.add(lblTienMat);
        textPanel.add(Box.createVerticalStrut(10));
        textPanel.add(lblChuyenKhoanTitle);
        textPanel.add(Box.createVerticalStrut(4));
        textPanel.add(lblChuyenKhoan);

        pnlTyLeThanhToan = new JPanel(new BorderLayout());
        pnlTyLeThanhToan.setOpaque(false);
        pnlTyLeThanhToan.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 0));

        panel7.add(textPanel, BorderLayout.CENTER);
        panel7.add(pnlTyLeThanhToan, BorderLayout.EAST);
        panel7.revalidate();
        panel7.repaint();
    }

    private void openTopSellingProductsDialog() {
        Date[] range = getCurrentDateRange();
        if (range[0] == null || range[1] == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn đầy đủ mốc thời gian để xem sản phẩm bán chạy.");
            return;
        }

        List<Object[]> products = dao.getTopSellingProducts(range[0], range[1], 5);
        ThongKeSanPhamBanChayJDialog dialog = new ThongKeSanPhamBanChayJDialog((java.awt.Frame) this.getParent(), true, products, range[0], range[1]);
        dialog.setVisible(true);
    }

    private Date[] getCurrentDateRange() {
        int index = jcbLoc.getSelectedIndex();
        Calendar cal = Calendar.getInstance();

        if (index == 0) {
            return new Date[]{jdTuNgay.getDate(), jdDenNgay.getDate()};
        }
        if (index == 1) {
            Date ngay = jdNgay.getDate();
            return new Date[]{ngay, ngay};
        }
        if (index == 2 && cboNam.getSelectedItem() != null) {
            cal.clear();
            cal.set(Calendar.YEAR, Integer.parseInt(cboNam.getSelectedItem().toString().trim()));
            cal.set(Calendar.MONTH, jMonthChooser.getMonth());
            cal.set(Calendar.DAY_OF_MONTH, 1);
            Date start = cal.getTime();
            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
            return new Date[]{start, cal.getTime()};
        }
        if (index == 3 && cboNam.getSelectedItem() != null) {
            int year = Integer.parseInt(cboNam.getSelectedItem().toString().trim());
            cal.clear();
            cal.set(year, Calendar.JANUARY, 1);
            Date start = cal.getTime();
            cal.set(year, Calendar.DECEMBER, 31);
            return new Date[]{start, cal.getTime()};
        }
        return new Date[]{null, null};
    }

    private void updatePaymentSummary() {
        if (lblTienMat == null || lblChuyenKhoan == null || pnlTyLeThanhToan == null) {
            return;
        }

        Date[] range = getCurrentDateRange();
        Object[] paymentData = dao.getPaymentMethodSummary(range[0], range[1]);
        double tienMatValue = Double.parseDouble(paymentData[0].toString());
        double chuyenKhoanValue = Double.parseDouble(paymentData[1].toString());

        lblTienMat.setText(formatMoney(tienMatValue));
        lblChuyenKhoan.setText(formatMoney(chuyenKhoanValue));
        renderPaymentPieChart(tienMatValue, chuyenKhoanValue);
    }

    private void renderPaymentPieChart(double tienMatValue, double chuyenKhoanValue) {
        DefaultPieDataset<String> dataset = new DefaultPieDataset<>();
        if (tienMatValue <= 0 && chuyenKhoanValue <= 0) {
            dataset.setValue("Chưa có dữ liệu", 1);
        } else {
            dataset.setValue("Tiền mặt", tienMatValue);
            dataset.setValue("Chuyển khoản", chuyenKhoanValue);
        }

        String cashKey = "Ti\u1ec1n m\u1eb7t";
        String transferKey = "Chuy\u1ec3n kho\u1ea3n";
        String emptyKey = "Ch\u01b0a c\u00f3 d\u1eef li\u1ec7u";
        dataset.clear();
        if (tienMatValue <= 0 && chuyenKhoanValue <= 0) {
            dataset.setValue(emptyKey, 1);
        } else {
            dataset.setValue(cashKey, tienMatValue);
            dataset.setValue(transferKey, chuyenKhoanValue);
        }

        JFreeChart pieChart = ChartFactory.createPieChart("", dataset, false, true, false);
        pieChart.setBackgroundPaint(panel7.getBackground());

        PiePlot<?> plot = (PiePlot<?>) pieChart.getPlot();
        plot.setBackgroundPaint(panel7.getBackground());
        plot.setOutlinePaint(null);
        plot.setShadowPaint(null);
        plot.setInteriorGap(0.04);
        plot.setLabelBackgroundPaint(new Color(255, 255, 255, 220));
        plot.setLabelOutlinePaint(new Color(180, 180, 180));
        plot.setLabelShadowPaint(null);
        plot.setLabelFont(new Font("Segoe UI", Font.PLAIN, 11));
        plot.setLabelGap(0.035);
        plot.setInteriorGap(0.10);
        plot.setSimpleLabels(false);
        plot.setSectionPaint(cashKey, new Color(255, 92, 92));
        plot.setSectionPaint(transferKey, new Color(90, 88, 232));
        plot.setSectionPaint(emptyKey, new Color(180, 180, 180));
        plot.setLabelGenerator(new StandardPieSectionLabelGenerator("{0}: {2}", NumberFormat.getNumberInstance(), new DecimalFormat("0.0%")));

        ChartPanel chartPanel = new ChartPanel(pieChart);
        chartPanel.setPreferredSize(new java.awt.Dimension(280, 130));
        chartPanel.setMouseZoomable(false);

        JPanel wrapper = new JPanel(new BorderLayout(0, 8));
        wrapper.setOpaque(false);
        wrapper.add(chartPanel, BorderLayout.CENTER);
        wrapper.add(createPaymentLegendPanel(tienMatValue, chuyenKhoanValue), BorderLayout.SOUTH);

        pnlTyLeThanhToan.removeAll();
        pnlTyLeThanhToan.add(wrapper, BorderLayout.CENTER);
        pnlTyLeThanhToan.revalidate();
        pnlTyLeThanhToan.repaint();
    }

    private JPanel createPaymentLegendPanel(double tienMatValue, double chuyenKhoanValue) {
        JPanel legendPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 24, 0));
        legendPanel.setOpaque(false);

        double total = tienMatValue + chuyenKhoanValue;
        String cashLabel = "Ti\u1ec1n m\u1eb7t";
        String transferLabel = "Chuy\u1ec3n kho\u1ea3n";
        legendPanel.add(createLegendItem(cashLabel, tienMatValue, total, new Color(255, 92, 92)));
        legendPanel.add(createLegendItem(transferLabel, chuyenKhoanValue, total, new Color(90, 88, 232)));
        return legendPanel;
    }

    private JLabel createLegendItem(String label, double value, double total, Color color) {
        double percent = total <= 0 ? 0 : value / total;
        JLabel legendItem = new JLabel(String.format("<html><span style='color:#%02x%02x%02x;'>&#9679;</span> %s (%.1f%%)</html>",
                color.getRed(), color.getGreen(), color.getBlue(), label, percent * 100));
        legendItem.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        legendItem.setBorder(BorderFactory.createEmptyBorder(0, 4, 0, 4));
        return legendItem;
    }

    private void exportThongKeToExcel() {
        try {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Chọn nơi lưu file Excel thống kê");
            chooser.setFileFilter(new FileNameExtensionFilter("Excel Files", "xlsx"));

            if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
                return;
            }

            File file = chooser.getSelectedFile();
            if (!file.getName().toLowerCase().endsWith(".xlsx")) {
                file = new File(file.getAbsolutePath() + ".xlsx");
            }

            Date[] range = getCurrentDateRange();
            Object[] summary = getCurrentSummaryData();
            Object[] payment = dao.getPaymentMethodSummary(range[0], range[1]);
            List<Object[]> detailRows = getCurrentDetailRows();
            List<Object[]> topProducts = dao.getTopSellingProducts(range[0], range[1], 5);

            try (Workbook workbook = new XSSFWorkbook()) {
                writeTongQuanSheet(workbook, summary, payment, range);
                writeChiTietSheet(workbook, detailRows);
                writeTopProductsSheet(workbook, topProducts);

                try (FileOutputStream fos = new FileOutputStream(file)) {
                    workbook.write(fos);
                }
            }

            JOptionPane.showMessageDialog(this, "Xuất Excel thống kê thành công.");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Xuất Excel thống kê thất bại.");
        }
    }

    private Object[] getCurrentSummaryData() {
        int index = jcbLoc.getSelectedIndex();
        if (index == 2 && cboNam.getSelectedItem() != null) {
            return dao.getSummaryByMonth(jMonthChooser.getMonth() + 1, Integer.parseInt(cboNam.getSelectedItem().toString().trim()));
        }
        if (index == 3 && cboNam.getSelectedItem() != null) {
            return dao.getSummaryData(Integer.parseInt(cboNam.getSelectedItem().toString().trim()), null, null);
        }
        Date[] range = getCurrentDateRange();
        return dao.getSummaryData(null, range[0], range[1]);
    }

    private List<Object[]> getCurrentDetailRows() {
        int index = jcbLoc.getSelectedIndex();
        Date[] range = getCurrentDateRange();

        if (range[0] == null || range[1] == null) {
            return new ArrayList<>();
        }

        if (index == 2) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(range[0]);
            return thongKeChiTietDAO.getThongKeTheoThang(cal.getTime());
        }
        if (index == 3) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(range[0]);
            return thongKeChiTietDAO.getThongKeTheoNam(cal.getTime());
        }
        return thongKeChiTietDAO.getThongKeChiTiet(range[0], range[1]);
    }

    private void writeTongQuanSheet(Workbook workbook, Object[] summary, Object[] payment, Date[] range) {
        Sheet sheet = workbook.createSheet("TongQuan");
        String[] labels = {"Từ ngày", "Đến ngày", "Doanh thu", "Số đơn hàng", "Thành công", "Hủy", "Tiền mặt", "Chuyển khoản"};
        Object[] values = {
            formatDate(range[0]),
            formatDate(range[1]),
            formatMoney(Double.parseDouble(summary[0].toString())),
            summary[1],
            summary[2],
            summary[3],
            formatMoney(Double.parseDouble(payment[0].toString())),
            formatMoney(Double.parseDouble(payment[1].toString()))
        };

        for (int i = 0; i < labels.length; i++) {
            Row row = sheet.createRow(i);
            row.createCell(0).setCellValue(labels[i]);
            row.createCell(1).setCellValue(values[i] == null ? "" : values[i].toString());
        }
        sheet.autoSizeColumn(0);
        sheet.autoSizeColumn(1);
    }

    private void writeChiTietSheet(Workbook workbook, List<Object[]> detailRows) {
        Sheet sheet = workbook.createSheet("ChiTiet");
        Row header = sheet.createRow(0);
        String[] columns = {"Thời gian", "Số đơn", "Tiền mặt", "Chuyển khoản", "Tổng doanh thu"};

        for (int i = 0; i < columns.length; i++) {
            header.createCell(i).setCellValue(columns[i]);
        }

        int rowIndex = 1;
        for (Object[] rowData : detailRows) {
            double tienMatValue = parseDouble(rowData.length > 2 ? rowData[2] : 0);
            double chuyenKhoanValue = parseDouble(rowData.length > 3 ? rowData[3] : 0);

            Row row = sheet.createRow(rowIndex++);
            row.createCell(0).setCellValue(rowData[0] == null ? "" : rowData[0].toString());
            row.createCell(1).setCellValue(parseDouble(rowData[1]));
            row.createCell(2).setCellValue(tienMatValue);
            row.createCell(3).setCellValue(chuyenKhoanValue);
            row.createCell(4).setCellValue(tienMatValue + chuyenKhoanValue);
        }

        for (int i = 0; i < columns.length; i++) {
            sheet.autoSizeColumn(i);
        }
    }

    private void writeTopProductsSheet(Workbook workbook, List<Object[]> topProducts) {
        Sheet sheet = workbook.createSheet("TopSanPham");
        Row header = sheet.createRow(0);
        String[] columns = {"Top", "Tên sản phẩm", "Số lượng bán", "Doanh thu"};

        for (int i = 0; i < columns.length; i++) {
            header.createCell(i).setCellValue(columns[i]);
        }

        int rowIndex = 1;
        for (Object[] product : topProducts) {
            Row row = sheet.createRow(rowIndex);
            row.createCell(0).setCellValue(rowIndex);
            row.createCell(1).setCellValue(product[0] == null ? "" : product[0].toString());
            row.createCell(2).setCellValue(parseDouble(product[1]));
            row.createCell(3).setCellValue(parseDouble(product[2]));
            rowIndex++;
        }

        for (int i = 0; i < columns.length; i++) {
            sheet.autoSizeColumn(i);
        }
    }

    private String formatDate(Date date) {
        if (date == null) {
            return "";
        }
        return new SimpleDateFormat("dd/MM/yyyy").format(date);
    }

    private double parseDouble(Object value) {
        if (value == null) {
            return 0;
        }
        return Double.parseDouble(value.toString());
    }

    private void resetForm() {
        // 1. Đưa ComboBox Lọc về mặc định (Chỉ số 2 là "Lọc theo năm")
        jcbLoc.setSelectedIndex(2);

        // 2. Xóa ngày trong JDateChooser
        jdTuNgay.setDate(null);
        jdDenNgay.setDate(null);

        // 3. Đưa JMonthChooser về tháng hiện tại
        jMonthChooser.setMonth(java.util.Calendar.getInstance().get(java.util.Calendar.MONTH));

        // 4. Chọn năm hiện tại trong cboNam (Ví dụ: 2024 hoặc 2025)
        // Ông có thể set cứng hoặc lấy năm hiện tại
        cboNam.setSelectedItem(String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)));

        // 5. Cập nhật lại giao diện ẩn/hiện các nút (Quan trọng để ẩn Từ ngày/Đến ngày đi)
        refreshData();

        // 6. Vẽ lại biểu đồ theo năm mặc định
        // (Tùy chọn) Hiển thị thông báo nhẹ ở Console để debug
        System.out.println("Giao diện đã được Reset!");
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLamMoi;
    private javax.swing.JButton btnThoat;
    private javax.swing.JButton btnspBanChay;
    private javax.swing.JButton btnxuatEx;
    private javax.swing.JComboBox<String> cboNam;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenu jMenu1;
    private com.toedter.calendar.JMonthChooser jMonthChooser;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JComboBox<String> jcbLoc;
    private com.toedter.calendar.JDateChooser jdDenNgay;
    private com.toedter.calendar.JDateChooser jdNgay;
    private com.toedter.calendar.JDateChooser jdTuNgay;
    private javax.swing.JLabel lblDenNgay;
    private javax.swing.JLabel lblDoanhThu;
    private javax.swing.JLabel lblDoanhThuNam;
    private javax.swing.JLabel lblDoanhThuThang;
    private javax.swing.JLabel lblDonHang;
    private javax.swing.JLabel lblNam;
    private javax.swing.JLabel lblNgay;
    private javax.swing.JLabel lblSoDoanhThuNam;
    private javax.swing.JLabel lblSoDoanhThuThang;
    private javax.swing.JLabel lblSoDonHang;
    private javax.swing.JLabel lblSoDonHuy;
    private javax.swing.JLabel lblSoThanhCong;
    private javax.swing.JLabel lblThang;
    private javax.swing.JLabel lblThanhCong;
    private javax.swing.JLabel lblThanhCong1;
    private javax.swing.JLabel lblTuNgay;
    private javax.swing.JLabel lblsoDoanhThu;
    private java.awt.Panel panel1;
    private java.awt.Panel panel10;
    private java.awt.Panel panel2;
    private java.awt.Panel panel3;
    private java.awt.Panel panel4;
    private java.awt.Panel panel5;
    private java.awt.Panel panel6;
    private java.awt.Panel panel7;
    private java.awt.Panel panel8;
    private java.awt.Panel panel9;
    private javax.swing.JPanel pnlBieuDo;
    private java.awt.Panel pnlHeader;
    private javax.swing.JCheckBoxMenuItem theoNam;
    private javax.swing.JCheckBoxMenuItem theoNgay;
    private javax.swing.JCheckBoxMenuItem theoThang;
    private javax.swing.JCheckBoxMenuItem theoTuan;
    private javax.swing.JButton xemChiTietDoanhThu;
    // End of variables declaration//GEN-END:variables

    private void fillSummaryCards(Integer nam, Date tu, Date den) {
        // Gọi DAO lấy mảng dữ liệu tổng hợp
        Object[] data = dao.getSummaryData(nam, tu, den);

        // Định dạng tiền tệ VNĐ
        java.text.DecimalFormat df = new java.text.DecimalFormat("#,###");

        // Lấy dữ liệu từ mảng Object[]
        double doanhThu = (double) data[0];
        int tongDon = (int) data[1];
        int thanhCong = (int) data[2];
        int huy = (int) data[3];

        // Đẩy dữ liệu lên các Label của Dũng
        lblsoDoanhThu.setText(df.format(doanhThu) + " VNĐ");
        lblSoDonHang.setText(String.valueOf(tongDon));
        lblSoThanhCong.setText(String.valueOf(thanhCong));
        lblSoDonHuy.setText(String.valueOf(huy));

        // Cập nhật 2 ô doanh thu tháng/năm ở góc phải
        lblSoDoanhThuThang.setText(df.format(doanhThu));
        lblSoDoanhThuNam.setText(df.format(doanhThu));
    }

    private void displayData(Object[] summary) {
        if (summary != null) {
            // Giả sử mảng summary trả về theo thứ tự: [Tổng Doanh Thu, Số Đơn, Số Thành Công, Số Hủy]
            lblsoDoanhThu.setText(String.format("%,.0f VNĐ", (Double) summary[0]));
            lblSoDonHang.setText(summary[1].toString());
            lblSoThanhCong.setText(summary[2].toString());
            lblSoDonHuy.setText(summary[3].toString());

            // Cập nhật doanh thu tháng/năm tùy vào ngữ cảnh nếu cần
            lblSoDoanhThuThang.setText(String.format("%,.0f", (Double) summary[0]));
            lblSoDoanhThuNam.setText(String.format("%,.0f", (Double) summary[0]));
        }
    }

    private void updateChart(List<Object[]> data, String par) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        // Đổ dữ liệu vào dataset
        if (data != null && !data.isEmpty()) {
            for (Object[] row : data) {
                double value = Double.parseDouble(row[1].toString());
                String timeLabel = row[0].toString();
                dataset.addValue(value, "Doanh thu", timeLabel);
            }
        }

        // Tạo Chart
        JFreeChart chart = ChartFactory.createBarChart(
                "THỐNG KÊ DOANH THU",
                "Thời gian", "Số tiền (VNĐ)",
                dataset, PlotOrientation.VERTICAL,
                false, true, false
        );

        // Tinh chỉnh hiển thị: Cột không được chiếm quá 5% chiều ngang
        org.jfree.chart.plot.CategoryPlot plot = chart.getCategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer renderer
                = (org.jfree.chart.renderer.category.BarRenderer) plot.getRenderer();
        renderer.setMaximumBarWidth(0.05);

        // Làm mới Panel biểu đồ
        ChartPanel chartPanel = new ChartPanel(chart);
        pnlBieuDo.removeAll();
        pnlBieuDo.add(chartPanel, java.awt.BorderLayout.CENTER);
        pnlBieuDo.validate();
        pnlBieuDo.repaint();
    }

    private void refreshStatistics() {
        try {
            // 1. Xác định chế độ lọc đang chọn (0: Ngày, 1: Tháng, 2: Năm)
            int index = jcbLoc.getSelectedIndex();
            Object[] summary = null;

            if (index == 0) { // Lọc theo ngày
                java.util.Date tu = jdTuNgay.getDate();
                java.util.Date den = jdDenNgay.getDate();
                if (tu != null && den != null) {
                    summary = dao.getSummaryData(null, tu, den);
                }
            } else if (index == 1) { // Lọc theo tháng
                int thang = jMonthChooser.getMonth();
                int nam = Integer.parseInt(cboNam.getSelectedItem().toString());
                summary = dao.getSummaryByMonth(thang, nam);
            } else if (index == 2) { // Lọc theo năm
                int nam = Integer.parseInt(cboNam.getSelectedItem().toString());
                summary = dao.getSummaryData(nam, null, null);
            }

            // 2. Đổ dữ liệu lên Label nếu tìm thấy kết quả
            if (summary != null) {
                java.text.DecimalFormat df = new java.text.DecimalFormat("#,###");
                double doanhThu = Double.parseDouble(summary[0].toString());

                // Cập nhật các Label chính (Dũng nhớ đổi tên đúng theo Navigator của ông nhé)
                lblsoDoanhThu.setText(df.format(doanhThu) + " VNĐ");
                lblSoDonHang.setText(summary[1].toString());
                lblSoThanhCong.setText(summary[2].toString());
                lblSoDonHuy.setText(summary[3].toString());

                // Cập nhật thêm Doanh thu Tháng/Năm để người dùng dễ nhìn
                lblSoDoanhThuThang.setText(df.format(doanhThu));
                lblSoDoanhThuNam.setText(df.format(doanhThu));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateThongKeLabels() {
        // 1. Lấy điều kiện lọc từ giao diện
        int index = jcbLoc.getSelectedIndex();
        int nam = Integer.parseInt(cboNam.getSelectedItem().toString());

        Object[] data = null;

        // 2. Gọi DAO tương ứng với loại lọc
        if (index == 0) { // Lọc theo ngày
            Date tuNgay = jdTuNgay.getDate();
            Date denNgay = jdDenNgay.getDate();
            if (tuNgay != null && denNgay != null) {
                data = dao.getSummaryData(0, tuNgay, denNgay); // Giả sử hàm DAO của bạn nhận Date
            }
        } else if (index == 1) { // Lọc theo tháng
            int thang = jMonthChooser.getMonth() + 1;
            data = dao.getSummaryByMonth(thang, nam);
        } else { // Lọc theo năm
            data = dao.getSummaryData(nam, null, null);
        }

        // 3. Đổ dữ liệu vào Label (Dùng DecimalFormat để số đẹp hơn)
        if (data != null) {
            java.text.DecimalFormat df = new java.text.DecimalFormat("#,###");

            // Giả sử mảng data trả về: [DoanhThu, TongDon, ThanhCong, Huy, DoanhThuThang, DoanhThuNam]
            lblsoDoanhThu.setText(df.format(data[0]) + " VNĐ");
            lblSoDonHang.setText(data[1].toString());
            lblSoThanhCong.setText(data[2].toString());
            lblSoDonHuy.setText(data[3].toString());
            lblSoDoanhThuThang.setText(df.format(data[4]));
            lblSoDoanhThuNam.setText(df.format(data[5]));
        }
    }

    private void fillChartByYear() {
        if (cboNam.getSelectedItem() == null) {
            return;
        }
        int nam = Integer.parseInt(cboNam.getSelectedItem().toString());

        List<Object[]> list = dao.getDoanhThuTheoNam(nam);

        if (list.isEmpty()) {
            // Nếu rỗng thì xóa biểu đồ cũ cho đỡ nhầm
            pnlBieuDo.removeAll();
            pnlBieuDo.revalidate();
            pnlBieuDo.repaint();
            return;
        }

        // PHẢI CÓ DÒNG NÀY BIỂU ĐỒ MỚI VẼ
        updateChart(list, "BIỂU ĐỒ DOANH THU NĂM " + nam);

        // Cập nhật các label số liệu (Xem mục 3 bên dưới)
    }

    private void refreshData() {
        int index = jcbLoc.getSelectedIndex();
        List<Object[]> dataChart = new ArrayList<>();
        Object[] summary = new Object[]{0.0, 0, 0, 0}; // [DoanhThu, TongDon, ThanhCong, Huy]

        try {
            if (index == 0) { // Khoảng ngày
                Date tu = jdTuNgay.getDate();
                Date den = jdDenNgay.getDate();
                dataChart = dao.getDoanhThuTheoKhoangNgay(tu, den);
                summary = dao.getSummaryData(null, tu, den);

            } else if (index == 1) { // Theo ngày đơn lẻ (24h)
                Date ngay = jdNgay.getDate();
                dataChart = dao.getDoanhThuTheo24Gio(ngay);
                summary = dao.getSummaryData(null, ngay, ngay);

            } else if (index == 2) { // Theo tháng
                int thang = jMonthChooser.getMonth() + 1;
                int nam = Integer.parseInt(cboNam.getSelectedItem().toString());
                dataChart = dao.getDoanhThuTheoThang(thang, nam);
                summary = dao.getSummaryByMonth(thang, nam);

            } else if (index == 3) { // Theo năm
                int nam = Integer.parseInt(cboNam.getSelectedItem().toString());
                dataChart = dao.getDoanhThuTheoNam(nam);
                summary = dao.getSummaryData(nam, null, null);
            }

            // Cập nhật các con số lên Label
            updateSummaryLabels(summary);
            updatePaymentSummary();
            // Vẽ biểu đồ
            fillChart(dataChart, index);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void createChart(DefaultCategoryDataset dataset, String title) {
        JFreeChart barChart = ChartFactory.createBarChart(
                title,
                "Thời gian", "Doanh thu (VNĐ)",
                dataset, PlotOrientation.VERTICAL,
                false, true, false);

        // Tùy chỉnh màu sắc (nếu muốn)
        CategoryPlot plot = barChart.getCategoryPlot();
        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, new Color(79, 129, 189));

        ChartPanel chartPanel = new ChartPanel(barChart);

        pnlBieuDo.removeAll(); // Xóa cái cũ
        pnlBieuDo.add(chartPanel, BorderLayout.CENTER);
        pnlBieuDo.validate(); // Vẽ lại
    }

    private void hienThiBieuDo(DefaultCategoryDataset dataset, String title, String xAxis) {
        JFreeChart chart = ChartFactory.createBarChart(
                title, xAxis, "Số tiền (VNĐ)",
                dataset, PlotOrientation.VERTICAL,
                false, true, false
        );

        CategoryPlot plot = chart.getCategoryPlot();
        BarRenderer renderer = (BarRenderer) plot.getRenderer();

        // Khống chế độ rộng cột để không bị "mập"
        renderer.setMaximumBarWidth(0.05);
        renderer.setSeriesPaint(0, new Color(100, 149, 237)); // Màu xanh nhẹ nhàng

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(pnlBieuDo.getWidth(), pnlBieuDo.getHeight()));

        pnlBieuDo.removeAll();
        pnlBieuDo.add(chartPanel, BorderLayout.CENTER); // Phải có BorderLayout.CENTER
        pnlBieuDo.validate();
        pnlBieuDo.repaint();
    }

    private void updateSummaryLabels(Object[] data) {
        lblsoDoanhThu.setText(formatMoney((Double) data[0]));
        lblSoDonHang.setText(String.valueOf(data[1]));
        lblSoThanhCong.setText(String.valueOf(data[2]));
        lblSoDonHuy.setText(String.valueOf(data[3]));
        updateMonthYearRevenueLabels();
    }

    private void updateMonthYearRevenueLabels() {
        try {
            Calendar cal = Calendar.getInstance();
            int index = jcbLoc.getSelectedIndex();
            int thang;
            int nam;

            if (index == 2 && cboNam.getSelectedItem() != null) {
                thang = jMonthChooser.getMonth() + 1;
                nam = Integer.parseInt(cboNam.getSelectedItem().toString().trim());
            } else if (index == 3 && cboNam.getSelectedItem() != null) {
                thang = jMonthChooser.getMonth() + 1;
                nam = Integer.parseInt(cboNam.getSelectedItem().toString().trim());
            } else {
                Date[] range = getCurrentDateRange();
                Date mocThamChieu = range[0] != null ? range[0] : new Date();
                cal.setTime(mocThamChieu);
                thang = cal.get(Calendar.MONTH) + 1;
                nam = cal.get(Calendar.YEAR);
            }

            Object[] doanhThuThang = dao.getSummaryByMonth(thang, nam);
            Object[] doanhThuNam = dao.getSummaryData(nam, null, null);

            lblSoDoanhThuThang.setText(formatMoney((Double) doanhThuThang[0]));
            lblSoDoanhThuNam.setText(formatMoney((Double) doanhThuNam[0]));
        } catch (Exception e) {
            lblSoDoanhThuThang.setText("0 VNĐ");
            lblSoDoanhThuNam.setText("0 VNĐ");
        }
    }

    private void updateSummary(Integer nam, Date tu, Date den) {
        Object[] data = dao.getSummaryData(nam, tu, den);
        lblsoDoanhThu.setText(formatMoney((Double) data[0]));
        lblSoDonHang.setText(data[1].toString());
        lblSoThanhCong.setText(data[2].toString());
        lblSoDonHuy.setText(data[3].toString());

        // Cập nhật mấy ô label phụ nếu ông muốn hiện
        lblSoDoanhThuThang.setText(formatMoney((Double) data[0]));
        lblSoDoanhThuNam.setText(formatMoney((Double) data[0]));
    }

    private void updateSummaryByMonth(int thang, int nam) {
        Object[] data = dao.getSummaryByMonth(thang, nam);
        displaySummary(data);
    }

    private void displaySummary(Object[] data) {
        if (data == null) {
            data = new Object[]{0.0, 0, 0, 0};
        }
        // Dùng đúng tên biến label trong initComponents của ông
        lblsoDoanhThu.setText(formatMoney(Double.parseDouble(data[0].toString())));
        lblSoDonHang.setText(data[1].toString());
        lblSoThanhCong.setText(data[2].toString());
        lblSoDonHuy.setText(data[3].toString());

        // Cập nhật 2 cái nhãn phụ bên phải
        lblSoDoanhThuThang.setText(lblsoDoanhThu.getText());
        lblSoDoanhThuNam.setText(lblsoDoanhThu.getText());
    }

    private void drawChart(List<Object[]> list) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        for (Object[] row : list) {
            String label = row[0].toString();
            Double value = (Double) row[1];
            dataset.addValue(value, "Doanh thu", label);
        }

        JFreeChart barChart = ChartFactory.createBarChart(
                "BIỂU ĐỒ DOANH THU", "Thời gian", "Doanh thu (VNĐ)",
                dataset, PlotOrientation.VERTICAL, false, true, false);

        // --- PHẦN FIX CỘT NHỎ LẠI ---
        CategoryPlot plot = barChart.getCategoryPlot();
        BarRenderer renderer = (BarRenderer) plot.getRenderer();

        // Chỉnh độ rộng tối đa của cột (0.05 = 5% chiều rộng biểu đồ)
        // Số càng nhỏ cột càng gầy
        renderer.setMaximumBarWidth(0.05);

        // Thêm màu sắc cho chuyên nghiệp
        renderer.setSeriesPaint(0, new java.awt.Color(31, 119, 180));
        // ----------------------------

        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setDisplayToolTips(true); // Hiện con số khi di chuột vào

        pnlBieuDo.removeAll();
        pnlBieuDo.add(chartPanel, java.awt.BorderLayout.CENTER);
        pnlBieuDo.validate();
        pnlBieuDo.repaint();
    }

    private void setupEventListeners() {
        // Sự kiện khi đổi kiểu lọc trong ComboBox
        jcbLoc.addActionListener(e -> {
            updateFilterUI();
            refreshData();
        });

        // Sự kiện khi đổi ngày trong các JDateChooser
        java.beans.PropertyChangeListener dateChange = evt -> {
            if ("date".equals(evt.getPropertyName())) {
                refreshData();
            }
        };
        jdTuNgay.addPropertyChangeListener(dateChange);
        jdDenNgay.addPropertyChangeListener(dateChange);
        jdNgay.addPropertyChangeListener(dateChange);

        // Sự kiện khi đổi tháng/năm
        jMonthChooser.addPropertyChangeListener("month", evt -> refreshData());
        cboNam.addActionListener(e -> refreshData());
    }

    private void updateChart(DefaultCategoryDataset dataset, String title) {
        JFreeChart chart = ChartFactory.createBarChart(
                title, "Thời gian", "Số tiền (VNĐ)",
                dataset, PlotOrientation.VERTICAL, false, true, false);

        ChartPanel chartPanel = new ChartPanel(chart);
        pnlBieuDo.removeAll();
        pnlBieuDo.add(chartPanel, BorderLayout.CENTER);
        pnlBieuDo.validate();
    }

    private void updateSummaryLabels(Integer nam, Date tu, Date den) {
        // Gọi DAO lấy mảng Object[]
        Object[] data = dao.getSummaryData(nam, tu, den);
        // Truyền mảng đó vào hàm hiển thị
        displaySummary(data);
    }

    private void updateSummaryByMonthLabels(int thang, int nam) {
        // Gọi DAO lấy mảng Object[] dành riêng cho tháng
        Object[] data = dao.getSummaryByMonth(thang, nam);
        // Truyền mảng đó vào hàm hiển thị
        displaySummary(data);
    }

    private void fillChart(List<Object[]> data, int type) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        String xAxisLabel = "";

        // 1. Đổ dữ liệu vào Dataset
        for (Object[] row : data) {
            String key = "";
            if (type == 0) { // Khoảng ngày -> row[0] là Date
                key = new java.text.SimpleDateFormat("dd/MM").format((java.util.Date) row[0]);
                xAxisLabel = "Ngày";
            } else if (type == 1) { // 24h -> row[0] là int (Giờ)
                key = row[0].toString() + "h";
                xAxisLabel = "Giờ";
            } else if (type == 2) { // Tháng -> row[0] là int (Ngày)
                key = "Ngày " + row[0].toString();
                xAxisLabel = "Ngày trong tháng";
            } else if (type == 3) { // Năm -> row[0] là int (Tháng)
                key = "Tháng " + row[0].toString();
                xAxisLabel = "Tháng trong năm";
            }

            Double value = (Double) row[1];
            dataset.addValue(value, "Doanh thu", key);
        }

        // 2. Tạo biểu đồ
        JFreeChart barChart = ChartFactory.createBarChart(
                "THỐNG KÊ DOANH THU",
                xAxisLabel, "Số tiền (VNĐ)",
                dataset, PlotOrientation.VERTICAL, false, true, false);

        // 3. Cấu hình giao diện (Renderer) - ĐÂY LÀ PHẦN FIX CỘT PHÌNH
        CategoryPlot plot = barChart.getCategoryPlot();
        BarRenderer renderer = (BarRenderer) plot.getRenderer();

        // Khống chế độ rộng tối đa của cột là 5% chiều ngang biểu đồ (không bị phình)
        renderer.setMaximumBarWidth(0.05);
        // Khoảng cách giữa các cột
        renderer.setItemMargin(0.1);

        // Màu cam thương hiệu Poly (như trong ảnh của ông)
        renderer.setSeriesPaint(0, new Color(255, 102, 0));

        // Hiển thị lưới ngang cho chuyên nghiệp
        plot.setRangeGridlinesVisible(true);
        plot.setRangeGridlinePaint(Color.GRAY);

        // 4. Hiển thị lên Panel
        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new java.awt.Dimension(pnlBieuDo.getWidth(), pnlBieuDo.getHeight()));

        pnlBieuDo.removeAll();
        pnlBieuDo.add(chartPanel, java.awt.BorderLayout.CENTER);
        pnlBieuDo.validate();
        pnlBieuDo.repaint();
    }

}
