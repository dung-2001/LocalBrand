/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package local.brand.ui.manager;

import java.util.List;
import javax.swing.ButtonGroup;
import javax.swing.table.DefaultTableModel;
import local.brand.dao.KhachHangDAO;
import local.brand.dao.impl.KhachHangDAOImpl;
import local.brand.entity.KhachHang;
import local.brand.ulti.XDialog;

/**
 *
 * @author ASUS
 */
public class KhachHangManagerJDialog extends javax.swing.JDialog {

    private KhachHangDAO dao = new KhachHangDAOImpl();
    private DefaultTableModel tblModel;
    private int row = -1;
    private BanHangJDialog banHangForm;

    /**
     * Creates new form KhachHangManagerJDialog
     */
    public KhachHangManagerJDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        setTitle("Quản lý khách hàng");

        tblModel = (DefaultTableModel) tblKhachHang.getModel();

        tblKhachHang.setDefaultEditor(Object.class, null);
        tblKhachHang.setRowSelectionAllowed(true);
        tblKhachHang.setColumnSelectionAllowed(false);
        tblKhachHang.setCellSelectionEnabled(false);

        ButtonGroup bgGioiTinh = new ButtonGroup();
        bgGioiTinh.add(rdoNam);
        bgGioiTinh.add(rdoNu);

        ButtonGroup bgTrangThai = new ButtonGroup();
        bgTrangThai.add(rdoHoatDong1);
        bgTrangThai.add(rdoNgung);

        txtMaKH.setEnabled(false);
        rdoNam.setSelected(true);
        rdoHoatDong1.setSelected(true);

        fillTable();
        clearForm();
    }

    void fillTable() {
        tblModel.setRowCount(0);
        List<KhachHang> list = dao.selectAll();

        for (KhachHang kh : list) {
            tblModel.addRow(new Object[]{
                kh.getMaKH(),
                kh.getTenKH(),
                kh.getSdt(),
                kh.getEmail(),
                kh.getGioiTinh(),
                kh.getTrangThai() == 1 ? "Hoạt động" : "Ngừng hoạt động"
            });
        }
    }

    void clearForm() {
        txtMaKH.setText(dao.getNextMaKH());
        txtTenKH.setText("");
        txtSDT.setText("");
        txtEmail.setText("");

        rdoNam.setSelected(true);
        rdoHoatDong1.setSelected(true);

        row = -1;
        tblKhachHang.clearSelection();
    }

    KhachHang getForm() {
        String ma = txtMaKH.getText().trim();
        String ten = txtTenKH.getText().trim();
        String sdt = txtSDT.getText().trim();
        String email = txtEmail.getText().trim();
        String gioiTinh = rdoNam.isSelected() ? "Nam" : "Nữ";
        int trangThai = rdoHoatDong1.isSelected() ? 1 : 0;

        if (ma.isEmpty()) {
            XDialog.alert("Mã khách hàng không được để trống!");
            txtMaKH.requestFocus();
            return null;
        }

        if (ten.isEmpty()) {
            XDialog.alert("Tên khách hàng không được để trống!");
            txtTenKH.requestFocus();
            return null;
        }

        if (ten.length() < 2) {
            XDialog.alert("Tên khách hàng phải có ít nhất 2 ký tự!");
            txtTenKH.requestFocus();
            return null;
        }

        if (sdt.isEmpty()) {
            XDialog.alert("Số điện thoại không được để trống!");
            txtSDT.requestFocus();
            return null;
        }

        if (!sdt.matches("0\\d{9}")) {
            XDialog.alert("Số điện thoại không hợp lệ!\nSĐT phải gồm 10 số và bắt đầu bằng 0.");
            txtSDT.requestFocus();
            return null;
        }

        if (!email.isEmpty() && !email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,6}$")) {
            XDialog.alert("Email không hợp lệ!\nVí dụ đúng: ten@gmail.com");
            txtEmail.requestFocus();
            return null;
        }

        return new KhachHang(null, ma, ten, sdt, email, gioiTinh, trangThai);
    }

    void edit() {
        row = tblKhachHang.getSelectedRow();
        if (row < 0) {
            return;
        }

        txtMaKH.setText(tblKhachHang.getValueAt(row, 0).toString());
        txtTenKH.setText(tblKhachHang.getValueAt(row, 1).toString());
        txtSDT.setText(tblKhachHang.getValueAt(row, 2).toString());
        txtEmail.setText(tblKhachHang.getValueAt(row, 3).toString());

        String gioiTinh = tblKhachHang.getValueAt(row, 4).toString();
        if ("Nam".equalsIgnoreCase(gioiTinh)) {
            rdoNam.setSelected(true);
        } else {
            rdoNu.setSelected(true);
        }

        String trangThai = tblKhachHang.getValueAt(row, 5).toString();
        if ("Hoạt động".equalsIgnoreCase(trangThai)) {
            rdoHoatDong1.setSelected(true);
        } else {
            rdoNgung.setSelected(true);
        }
    }

    void insert() {
        KhachHang kh = getForm();
        if (kh == null) {
            return;
        }

        try {
            dao.insert(kh);
            XDialog.alert("Thêm khách hàng thành công!");
            fillTable();
            clearForm();
        } catch (Exception e) {
            e.printStackTrace();

            String msg = e.getMessage();

            if (msg != null && msg.toLowerCase().contains("duplicate")) {
                XDialog.alert("Mã khách hàng đã tồn tại!");
            } else {
                XDialog.alert("Không thể thêm khách hàng!\nLý do: " + msg);
            }
        }
    }

    void updateKH() {
        KhachHang kh = getForm();
        if (kh == null) {
            return;
        }

        try {
            dao.update(kh);
            XDialog.alert("Cập nhật thành công!");
            fillTable();
            clearForm();
        } catch (Exception e) {
            XDialog.alert("Cập nhật thất bại!");
            e.printStackTrace();
        }
    }

    void deleteKH() {
        String maKH = txtMaKH.getText().trim();

        if (maKH.isEmpty()) {
            XDialog.alert("Bạn chưa chọn khách hàng cần xóa!");
            return;
        }

        if (!XDialog.confirm("Bạn có chắc muốn xóa khách hàng này không?")) {
            return;
        }

        try {
            // nếu đã có hóa đơn thì không cho xóa cứng
            if (dao.hasInvoice(maKH)) {
                dao.softDelete(maKH);
                XDialog.alert("Khách hàng đã phát sinh hóa đơn, không thể xóa.\nHệ thống đã chuyển sang trạng thái ngừng hoạt động.");
            } else {
                dao.delete(maKH);
                XDialog.alert("Xóa khách hàng thành công!");
            }

            fillTable();
            clearForm();

        } catch (Exception e) {
            e.printStackTrace();
            XDialog.alert("Không thể xóa khách hàng.\nLý do: " + e.getMessage());
        }
    }

    void timKiem() {
        String key = txtTimKiem.getText().trim();
        tblModel.setRowCount(0);

        List<KhachHang> list;
        if (key.isEmpty()) {
            list = dao.selectAll();
        } else {
            list = dao.search(key);
        }

        for (KhachHang kh : list) {
            tblModel.addRow(new Object[]{
                kh.getMaKH(),
                kh.getTenKH(),
                kh.getSdt(),
                kh.getEmail(),
                kh.getGioiTinh(),
                kh.getTrangThai() == 1 ? "Hoạt động" : "Ngừng hoạt động"
            });
        }
    }

    public void setBanHangForm(BanHangJDialog banHangForm) {
        this.banHangForm = banHangForm;
    }

    void chonKhachChoBanHang() {
        int selectedRow = tblKhachHang.getSelectedRow();
        if (selectedRow < 0) {
            XDialog.alert("Vui lòng chọn khách hàng!");
            return;
        }

        if (banHangForm == null) {
            XDialog.alert("Form bán hàng chưa được truyền sang!");
            return;
        }

        try {
            String maKH = tblKhachHang.getValueAt(selectedRow, 0).toString();
            String tenKH = tblKhachHang.getValueAt(selectedRow, 1).toString();
            String sdt = tblKhachHang.getValueAt(selectedRow, 2) == null
                    ? ""
                    : tblKhachHang.getValueAt(selectedRow, 2).toString();
            String email = tblKhachHang.getValueAt(selectedRow, 3) == null
                    ? ""
                    : tblKhachHang.getValueAt(selectedRow, 3).toString();
            String gioiTinh = tblKhachHang.getValueAt(selectedRow, 4) == null
                    ? "Nam"
                    : tblKhachHang.getValueAt(selectedRow, 4).toString();
            int trangThai = "Hoạt động".equalsIgnoreCase(tblKhachHang.getValueAt(selectedRow, 5).toString()) ? 1 : 0;

            Object idValue = local.brand.ulti.XJdbc.getValue(
                    "SELECT id FROM khach_hang WHERE ma_kh = ?",
                    maKH
            );

            Integer id = idValue == null ? null : Integer.valueOf(idValue.toString());
            KhachHang kh = new KhachHang(id, maKH, tenKH, sdt, email, gioiTinh, trangThai);

            banHangForm.setKhachHangDuocChon(kh);
            this.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            XDialog.alert("Không thể chọn khách hàng!\nLý do: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rdoHoatDong = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtMaKH = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtTenKH = new javax.swing.JTextField();
        txtSDT = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        rdoNam = new javax.swing.JRadioButton();
        rdoNu = new javax.swing.JRadioButton();
        rdoHoatDong1 = new javax.swing.JRadioButton();
        rdoNgung = new javax.swing.JRadioButton();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        Xoa = new javax.swing.JButton();
        btnMoi = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        btnTimKiem = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblKhachHang = new javax.swing.JTable();

        rdoHoatDong.setText("Hoạt động");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 0, 24)); // NOI18N
        jLabel1.setText("Quản lý khách hàng");

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabel2.setText("Mã khách hàng:");

        jLabel3.setText("SĐT:");

        jLabel4.setText("Tên khách hàng:");

        jLabel5.setText("Email:");

        jLabel6.setText("Giới tính:");

        jLabel7.setText("Trạng thái:");

        rdoNam.setText("Nam");

        rdoNu.setText("Nữ");

        rdoHoatDong1.setText("Hoạt động");

        rdoNgung.setText("Ngừng hoạt động");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtMaKH, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(txtSDT, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rdoNam)
                        .addGap(18, 18, 18)
                        .addComponent(rdoNu)))
                .addGap(131, 131, 131)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rdoHoatDong1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rdoNgung))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTenKH, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtMaKH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(txtTenKH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5)
                    .addComponent(txtSDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(rdoNam)
                    .addComponent(rdoNu)
                    .addComponent(rdoHoatDong1)
                    .addComponent(rdoNgung))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        btnThem.setText("Thêm");
        btnThem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnThemMouseClicked(evt);
            }
        });
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setText("Sửa");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        Xoa.setText("Xóa");
        Xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                XoaActionPerformed(evt);
            }
        });

        btnMoi.setText("Làm mới");
        btnMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoiActionPerformed(evt);
            }
        });

        jLabel9.setText("Tìm kiếm:");

        btnTimKiem.setText("Tìm kiếm");
        btnTimKiem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnTimKiemMouseClicked(evt);
            }
        });
        btnTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemActionPerformed(evt);
            }
        });

        tblKhachHang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Mã khách hàng", "Tên khách hàng", "SDT", "Email", "Giới tính", "Trạng thái"
            }
        ));
        tblKhachHang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblKhachHangMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblKhachHang);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 679, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnThem)
                                .addGap(18, 18, 18)
                                .addComponent(btnSua)
                                .addGap(18, 18, 18)
                                .addComponent(Xoa)
                                .addGap(36, 36, 36)
                                .addComponent(btnMoi)
                                .addGap(30, 30, 30)
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnTimKiem)))))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThem)
                    .addComponent(btnSua)
                    .addComponent(Xoa)
                    .addComponent(btnMoi)
                    .addComponent(jLabel9)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiem))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 263, Short.MAX_VALUE)
                .addGap(9, 9, 9))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        // TODO add your handling code here:
        insert();
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        // TODO add your handling code here:
        updateKH();
    }//GEN-LAST:event_btnSuaActionPerformed

    private void XoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_XoaActionPerformed
        // TODO add your handling code here:
        deleteKH();
    }//GEN-LAST:event_XoaActionPerformed

    private void btnMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoiActionPerformed
        // TODO add your handling code here:
        clearForm();
        fillTable();
    }//GEN-LAST:event_btnMoiActionPerformed

    private void btnTimKiemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTimKiemMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnTimKiemMouseClicked

    private void btnTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemActionPerformed
        // TODO add your handling code here:
        timKiem();
    }//GEN-LAST:event_btnTimKiemActionPerformed

    private void tblKhachHangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblKhachHangMouseClicked
        row = tblKhachHang.getSelectedRow();
        if (row >= 0) {
            edit();
        }

        if (evt.getClickCount() == 2) {
            chonKhachChoBanHang();
        }
    }//GEN-LAST:event_tblKhachHangMouseClicked

    private void btnThemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnThemMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnThemMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(KhachHangManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(KhachHangManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(KhachHangManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(KhachHangManagerJDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                KhachHangManagerJDialog dialog = new KhachHangManagerJDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Xoa;
    private javax.swing.JButton btnMoi;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnTimKiem;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JRadioButton rdoHoatDong;
    private javax.swing.JRadioButton rdoHoatDong1;
    private javax.swing.JRadioButton rdoNam;
    private javax.swing.JRadioButton rdoNgung;
    private javax.swing.JRadioButton rdoNu;
    private javax.swing.JTable tblKhachHang;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtMaKH;
    private javax.swing.JTextField txtSDT;
    private javax.swing.JTextField txtTenKH;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables
}
