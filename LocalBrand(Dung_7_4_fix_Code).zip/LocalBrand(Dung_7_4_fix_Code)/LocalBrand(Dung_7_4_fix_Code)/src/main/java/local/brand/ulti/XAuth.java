/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local.brand.ulti;

import local.brand.entity.NhanVien;
import local.brand.ulti.*;


/**
 *
 * @author ASUS
 */
public class XAuth {
     public static NhanVien user = null;
    public static void clear() {
        user = null;
    }

    public static boolean isLogin() {
        return user != null;
    }

    public static boolean isAdmin() {
        if (user == null) {
            return false;
        }
        return user.getTenChucVu() != null
                && user.getTenChucVu().equalsIgnoreCase("Quản lý");
    }
}
