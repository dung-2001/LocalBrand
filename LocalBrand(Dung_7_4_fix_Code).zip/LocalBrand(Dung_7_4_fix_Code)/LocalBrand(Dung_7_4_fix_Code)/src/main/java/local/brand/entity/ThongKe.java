package local.brand.entity;

import java.util.Date;

/**
 * Class ThongKe dùng để chứa dữ liệu tổng hợp phục vụ báo cáo và biểu đồ
 * @author CAU DIEN
 */
public class ThongKe {
    private int thang;
    private int nam;
    private double doanhThu;
    private int soHoaDon;
    private int soKhachHang;
    private int soSanPhamDaBan;
    private String tenSanPham;

    // Constructor không đối số
    public ThongKe() {
    }

    // Constructor dùng cho Thống kê Doanh thu theo thời gian
    public ThongKe(int thang, double doanhThu) {
        this.thang = thang;
        this.doanhThu = doanhThu;
    }

    // Constructor đầy đủ (tùy chọn khi cần báo cáo chi tiết)
    public ThongKe(int thang, int nam, double doanhThu, int soHoaDon, int soKhachHang) {
        this.thang = thang;
        this.nam = nam;
        this.doanhThu = doanhThu;
        this.soHoaDon = soHoaDon;
        this.soKhachHang = soKhachHang;
    }

    // Getter và Setter
    public int getThang() {
        return thang;
    }

    public void setThang(int thang) {
        this.thang = thang;
    }

    public int getNam() {
        return nam;
    }

    public void setNam(int nam) {
        this.nam = nam;
    }

    public double getDoanhThu() {
        return doanhThu;
    }

    public void setDoanhThu(double doanhThu) {
        this.doanhThu = doanhThu;
    }

    public int getSoHoaDon() {
        return soHoaDon;
    }

    public void setSoHoaDon(int soHoaDon) {
        this.soHoaDon = soHoaDon;
    }

    public int getSoKhachHang() {
        return soKhachHang;
    }

    public void setSoKhachHang(int soKhachHang) {
        this.soKhachHang = soKhachHang;
    }

    public int getSoSanPhamDaBan() {
        return soSanPhamDaBan;
    }

    public void setSoSanPhamDaBan(int soSanPhamDaBan) {
        this.soSanPhamDaBan = soSanPhamDaBan;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }
}